# GesStock — Guide de déploiement complet

Application de gestion de stock pour pièces détachées.
Stack : React + TypeScript (Vercel) · Node.js + Express (Render) · Supabase · Upstash Redis · Resend

---

## Prérequis

- Compte GitHub (pour déployer sur Render et Vercel)
- Compte Supabase : https://supabase.com (gratuit, sans CB)
- Compte Render : https://render.com (gratuit, sans CB)
- Compte Vercel : https://vercel.com (gratuit, sans CB)
- Compte Upstash : https://upstash.com (gratuit, sans CB)
- Compte Resend : https://resend.com (gratuit, sans CB)
- Compte UptimeRobot : https://uptimerobot.com (gratuit, sans CB)

---

## Étape 1 — Création du projet Supabase

1. Connectez-vous sur https://supabase.com
2. Cliquez **New project**
3. Choisissez un nom de projet (ex: `gesstock`)
4. Choisissez un mot de passe fort pour la base de données — **conservez-le**
5. Sélectionnez la région la plus proche (ex: `West EU`)
6. Cliquez **Create new project** et attendez ~2 minutes

Notez les informations suivantes (disponibles dans **Settings > API**) :
- **Project URL** → `VITE_SUPABASE_URL` et `SUPABASE_URL`
- **anon public key** → `VITE_SUPABASE_ANON_KEY`
- **service_role key** → `SUPABASE_SERVICE_ROLE_KEY` ⚠️ gardez-la secrète

---

## Étape 2 — Exécution du script SQL schema.sql

1. Dans Supabase, allez dans **SQL Editor**
2. Cliquez **New query**
3. Copiez-collez intégralement le contenu de `backend/src/db/schema.sql`
4. Cliquez **Run** (▶)
5. Vérifiez que toutes les tables sont créées sans erreur dans **Table Editor**

Tables créées : `magasins`, `employes`, `pieces`, `transactions`, `audit_logs`, `alertes`

---

## Étape 3 — Exécution du script SQL rpc.sql

1. Dans **SQL Editor**, créez une nouvelle query
2. Copiez-collez intégralement le contenu de `backend/src/db/rpc.sql`
3. Cliquez **Run**
4. Vérifiez que la fonction `sortie_stock_atomique` et le trigger `verifier_seuil_alerte` sont créés

---

## Étape 4 — Activation du Realtime

1. Dans Supabase, allez dans **Database > Replication**
2. Dans la section **Tables**, activez le Realtime pour :
   - `pieces`
   - `transactions`
   - `alertes`
3. Vérifiez que les sliders sont en position **ON** pour chaque table

---

## Étape 5 — Création du bucket Storage

1. Dans Supabase, allez dans **Storage**
2. Cliquez **New bucket**
3. Nom du bucket : `pieces-photos`
4. Laissez **Public bucket** désactivé (bucket privé)
5. Cliquez **Save**

Ajout des politiques RLS pour le bucket :

```sql
-- Dans SQL Editor, exécutez ces politiques :

-- Autoriser la lecture (via service_role uniquement — le backend gère les URLs signées)
CREATE POLICY "Service role can read photos"
ON storage.objects FOR SELECT
TO service_role
USING (bucket_id = 'pieces-photos');

-- Autoriser l'upload (via service_role uniquement)
CREATE POLICY "Service role can insert photos"
ON storage.objects FOR INSERT
TO service_role
WITH CHECK (bucket_id = 'pieces-photos');

-- Autoriser la suppression (via service_role uniquement)
CREATE POLICY "Service role can delete photos"
ON storage.objects FOR DELETE
TO service_role
USING (bucket_id = 'pieces-photos');
```

---

## Étape 6 — Configuration Upstash Redis

1. Connectez-vous sur https://upstash.com
2. Cliquez **Create Database**
3. Nom : `gesstock-redis`
4. Type : **Regional**, région la plus proche
5. Cliquez **Create**
6. Notez les informations suivantes :
   - **UPSTASH_REDIS_REST_URL** → disponible dans le dashboard
   - **UPSTASH_REDIS_REST_TOKEN** → disponible dans le dashboard

---

## Étape 7 — Configuration Resend

1. Connectez-vous sur https://resend.com
2. Allez dans **API Keys > Create API Key**
3. Nom : `gesstock`, permissions : **Full access**
4. Notez la clé API → `RESEND_API_KEY`
5. Dans **Domains**, ajoutez votre domaine ou utilisez le domaine sandbox Resend pour les tests
6. Notez l'email expéditeur (ex: `noreply@votredomaine.com`) → `RESEND_FROM_EMAIL`

---

## Étape 8 — Déploiement backend sur Render.com

1. Poussez votre code sur un dépôt GitHub
2. Connectez-vous sur https://render.com
3. Cliquez **New > Web Service**
4. Connectez votre dépôt GitHub
5. Configuration :
   - **Name** : `gesstock-api`
   - **Root Directory** : `backend`
   - **Runtime** : `Node`
   - **Build Command** : `npm install && npm run build`
   - **Start Command** : `npm start`
   - **Instance Type** : `Free`
6. Dans **Environment Variables**, ajoutez toutes les variables du fichier `backend/.env.example`

Variables obligatoires à renseigner :

| Variable | Description |
|----------|-------------|
| `NODE_ENV` | `production` |
| `PORT` | `3000` |
| `DATABASE_URL` | URL PostgreSQL Supabase (Settings > Database > Connection string) |
| `SUPABASE_URL` | URL de votre projet Supabase |
| `SUPABASE_SERVICE_ROLE_KEY` | Clé service_role Supabase |
| `JWT_SECRET` | Chaîne aléatoire de 64 caractères minimum |
| `REFRESH_TOKEN_SECRET` | Autre chaîne aléatoire de 64 caractères minimum |
| `UPSTASH_REDIS_REST_URL` | URL REST Upstash |
| `UPSTASH_REDIS_REST_TOKEN` | Token REST Upstash |
| `RESEND_API_KEY` | Clé API Resend |
| `RESEND_FROM_EMAIL` | Email expéditeur vérifié |
| `FRONTEND_URL` | URL Vercel de votre frontend (ex: https://gesstock.vercel.app) |
| `RESET_TOKEN` | Token secret pour le reset d'urgence (min 32 caractères aléatoires) |

Générer des secrets sécurisés :
```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

7. Cliquez **Create Web Service**
8. Attendez le déploiement (~3-5 minutes)
9. Notez l'URL de votre service (ex: `https://gesstock-api.onrender.com`)

---

## Étape 9 — Configuration UptimeRobot (anti-mise en veille)

Le plan gratuit de Render met les services en veille après 15 minutes d'inactivité.
UptimeRobot envoie un ping toutes les 5 minutes pour maintenir le service actif.

1. Connectez-vous sur https://uptimerobot.com
2. Cliquez **Add New Monitor**
3. Configuration :
   - **Monitor Type** : `HTTP(s)`
   - **Friendly Name** : `GesStock API`
   - **URL** : `https://gesstock-api.onrender.com/health`
   - **Monitoring Interval** : `5 minutes`
4. Cliquez **Create Monitor**

L'endpoint `/health` répond `{ status: "ok" }` et suffit à maintenir le service éveillé.

---

## Étape 10 — Déploiement frontend sur Vercel

1. Connectez-vous sur https://vercel.com
2. Cliquez **Add New > Project**
3. Importez votre dépôt GitHub
4. Configuration :
   - **Root Directory** : `frontend`
   - **Framework Preset** : `Vite`
   - **Build Command** : `npm run build`
   - **Output Directory** : `dist`
5. Dans **Environment Variables**, ajoutez :

| Variable | Valeur |
|----------|--------|
| `VITE_API_URL` | URL de votre backend Render |
| `VITE_SUPABASE_URL` | URL de votre projet Supabase |
| `VITE_SUPABASE_ANON_KEY` | Clé anon Supabase |

6. Cliquez **Deploy**
7. Notez l'URL de votre frontend (ex: `https://gesstock.vercel.app`)

⚠️ **Important** : Mettez à jour la variable `FRONTEND_URL` dans Render avec cette URL exacte.

---

## Étape 11 — Test de l'installation

1. Ouvrez votre URL Vercel dans un navigateur
2. Créez votre premier magasin :
   - Saisissez le nom du magasin
   - Choisissez **Employeur**
   - Entrez votre code à 6 chiffres (il sera hashé en bcrypt lors de la première connexion)
3. Vérifiez que le point vert de connexion temps réel s'affiche
4. Ajoutez quelques pièces depuis l'onglet Stock
5. Testez une entrée et une sortie de stock

---

## Procédure de reset d'urgence du code employeur

Si l'employeur a perdu son code à 6 chiffres :

1. Accédez à l'URL : `https://votre-frontend.vercel.app`
2. Connectez-vous avec n'importe quel accès
3. Allez dans **Paramètres > Zone dangereuse**
4. Cliquez **Reset d'urgence**
5. Saisissez le `RESET_TOKEN` défini dans vos variables d'environnement Render
6. Confirmez avec le code actuel (si vous le connaissez encore) ou contactez le support

**Alternative via API directe** (si vous n'avez aucun accès) :

```bash
curl -X POST https://gesstock-api.onrender.com/api/auth/reset \
  -H "Content-Type: application/json" \
  -d '{
    "nom_magasin": "Nom de votre magasin",
    "reset_token": "VOTRE_RESET_TOKEN",
    "nouveau_code": "123456"
  }'
```

Un email de confirmation est envoyé via Resend après chaque reset.

---

## Procédure de réinitialisation globale des données

⚠️ **Attention : irréversible. Toutes les données seront supprimées.**

### Option 1 : Via l'interface (recommandé)

1. Allez dans **Paramètres > Zone dangereuse**
2. Remplissez le formulaire de reset complet
3. Confirmez avec le RESET_TOKEN et le code employeur actuel

### Option 2 : Via Supabase SQL Editor

```sql
-- ATTENTION : Ces commandes suppriment TOUTES les données
-- Exécuter dans cet ordre pour respecter les clés étrangères

DELETE FROM audit_logs;
DELETE FROM alertes;
DELETE FROM transactions;
DELETE FROM pieces;
DELETE FROM employes;
DELETE FROM magasins;

-- Vider le bucket Storage
-- À faire manuellement dans Supabase > Storage > pieces-photos > Sélectionner tout > Supprimer
```

### Option 3 : Réinitialisation complète (nouveau départ)

1. Dans Supabase SQL Editor, exécutez les commandes de l'Option 2
2. Re-exécutez `schema.sql` puis `rpc.sql`
3. Dans Upstash, videz la base Redis (Dashboard > Flush Database)
4. Redémarrez le service Render (Dashboard > Manual Deploy)

---

## Dépannage fréquent

**Le service Render est en veille au premier accès**
→ Normal, le premier démarrage prend ~30 secondes. UptimeRobot évite ce problème après configuration.

**Erreur CORS au login**
→ Vérifiez que `FRONTEND_URL` dans Render correspond exactement à votre URL Vercel (sans slash final).

**Les photos ne s'affichent pas**
→ Vérifiez les politiques RLS du bucket `pieces-photos` et que `SUPABASE_SERVICE_ROLE_KEY` est correcte.

**Les alertes temps réel ne fonctionnent pas**
→ Vérifiez que le Realtime est activé sur les tables `pieces`, `transactions`, `alertes` dans Supabase > Database > Replication.

**Erreur "relation does not exist"**
→ Re-exécutez `schema.sql` et `rpc.sql` dans cet ordre depuis Supabase SQL Editor.

**Rate limit atteint (429)**
→ Normal si vous testez beaucoup. Attendez 15 minutes. En production, les limites sont : 5 tentatives auth/15 min, 100 req/min sur les routes protégées.

---

## Architecture de sécurité

```
Utilisateur
    │
    ▼
Vercel (HTTPS)
React + Zustand
JWT en mémoire uniquement
    │
    ▼ HTTPS + Cookie HttpOnly
Render (Node.js / Express)
Helmet · CORS · express-validator
Rate Limiting (Upstash Redis)
    │
    ├──► Supabase PostgreSQL
    │    RLS activé sur toutes les tables
    │    Requêtes paramétrées uniquement
    │    Fonction RPC atomique (sortie stock)
    │
    ├──► Supabase Storage (bucket privé)
    │    URLs signées côté serveur
    │    Cache Redis 50 minutes
    │
    ├──► Upstash Redis
    │    Rate limiting persistant
    │    Refresh tokens
    │    Cache URLs signées
    │
    └──► Resend
         Emails de notification
         Reset d'urgence
```

---

## Structure des fichiers

```
gesstock/
├── backend/
│   ├── src/
│   │   ├── config/env.ts          # Validation variables env (zod)
│   │   ├── db/
│   │   │   ├── schema.sql         # Schéma complet + RLS
│   │   │   └── rpc.sql            # Fonctions RPC + triggers
│   │   ├── middlewares/
│   │   │   ├── auth.ts            # JWT + refresh token
│   │   │   ├── rateLimit.ts       # Rate limiting Upstash
│   │   │   ├── validate.ts        # express-validator
│   │   │   └── error.ts           # Gestion centralisée erreurs
│   │   ├── services/              # Logique métier
│   │   ├── controllers/           # Handlers HTTP
│   │   ├── routes/                # Définition des routes
│   │   └── app.ts                 # Express app
│   └── .env.example
└── frontend/
    ├── src/
    │   ├── types/index.ts         # Types TypeScript
    │   ├── api/                   # Appels API backend
    │   ├── store/                 # État global Zustand
    │   ├── hooks/                 # Hooks React custom
    │   ├── components/
    │   │   ├── ui/                # Composants réutilisables
    │   │   ├── stock/             # Gestion stock
    │   │   ├── transaction/       # Transactions
    │   │   ├── stats/             # Statistiques
    │   │   ├── employes/          # Gestion employés
    │   │   └── parametres/        # Paramètres
    │   ├── pages/                 # Pages principales
    │   └── App.tsx                # Routing + layout
    └── .env.example
```

---

## Licence

MIT — Utilisation libre pour usage commercial et personnel.
