import { useState } from 'react';
import { Piece, PieceFormData } from '../../types';
import { createPiece, updatePiece } from '../../api/stock.api';
import { useToast } from '../ui/Toast';

interface PieceFormProps {
  piece?: Piece;
  onSuccess: () => void;
  onCancel: () => void;
}

export function PieceForm({ piece, onSuccess, onCancel }: PieceFormProps) {
  const { showToast } = useToast();
  const isEdit = Boolean(piece);

  const [form, setForm] = useState<PieceFormData>({
    reference: piece?.reference ?? '',
    designation: piece?.designation ?? '',
    prix: piece ? Number(piece.prix) : 0,
    quantite: piece?.quantite ?? 0,
    seuil_alerte: piece?.seuil_alerte ?? 0,
  });

  const [errors, setErrors] = useState<Partial<Record<keyof PieceFormData, string>>>({});
  const [loading, setLoading] = useState(false);

  const validate = (): boolean => {
    const newErrors: Partial<Record<keyof PieceFormData, string>> = {};
    if (!form.reference.trim()) newErrors.reference = 'La référence est obligatoire';
    if (!form.designation.trim()) newErrors.designation = 'La désignation est obligatoire';
    if (form.prix < 0) newErrors.prix = 'Le prix ne peut pas être négatif';
    if (form.quantite < 0) newErrors.quantite = 'La quantité ne peut pas être négative';
    if (form.seuil_alerte < 0) newErrors.seuil_alerte = 'Le seuil ne peut pas être négatif';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (field: keyof PieceFormData, value: string | number) => {
    setForm(prev => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors(prev => ({ ...prev, [field]: undefined }));
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      if (isEdit && piece) {
        await updatePiece(piece.id, form);
        showToast('Pièce mise à jour avec succès', 'success');
      } else {
        await createPiece(form);
        showToast('Pièce ajoutée avec succès', 'success');
      }
      onSuccess();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Une erreur est survenue';
      showToast(message, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="piece-form">
      <div className="form-group">
        <label htmlFor="reference">Référence *</label>
        <input
          id="reference"
          type="text"
          value={form.reference}
          onChange={e => handleChange('reference', e.target.value)}
          placeholder="Ex: REF-001"
          className={errors.reference ? 'input-error' : ''}
          disabled={loading}
        />
        {errors.reference && <span className="field-error">{errors.reference}</span>}
      </div>

      <div className="form-group">
        <label htmlFor="designation">Désignation *</label>
        <input
          id="designation"
          type="text"
          value={form.designation}
          onChange={e => handleChange('designation', e.target.value)}
          placeholder="Ex: Filtre à huile"
          className={errors.designation ? 'input-error' : ''}
          disabled={loading}
        />
        {errors.designation && <span className="field-error">{errors.designation}</span>}
      </div>

      <div className="form-row">
        <div className="form-group">
          <label htmlFor="prix">Prix (€) *</label>
          <input
            id="prix"
            type="number"
            min="0"
            step="0.01"
            value={form.prix}
            onChange={e => handleChange('prix', parseFloat(e.target.value) || 0)}
            className={errors.prix ? 'input-error' : ''}
            disabled={loading}
          />
          {errors.prix && <span className="field-error">{errors.prix}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="quantite">Quantité *</label>
          <input
            id="quantite"
            type="number"
            min="0"
            step="1"
            value={form.quantite}
            onChange={e => handleChange('quantite', parseInt(e.target.value, 10) || 0)}
            className={errors.quantite ? 'input-error' : ''}
            disabled={loading}
          />
          {errors.quantite && <span className="field-error">{errors.quantite}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="seuil_alerte">Seuil d'alerte *</label>
          <input
            id="seuil_alerte"
            type="number"
            min="0"
            step="1"
            value={form.seuil_alerte}
            onChange={e => handleChange('seuil_alerte', parseInt(e.target.value, 10) || 0)}
            className={errors.seuil_alerte ? 'input-error' : ''}
            disabled={loading}
          />
          {errors.seuil_alerte && <span className="field-error">{errors.seuil_alerte}</span>}
        </div>
      </div>

      <div className="form-actions">
        <button className="btn-secondary" onClick={onCancel} disabled={loading}>
          Annuler
        </button>
        <button className="btn-primary" onClick={handleSubmit} disabled={loading}>
          {loading ? 'Enregistrement…' : isEdit ? 'Mettre à jour' : 'Ajouter'}
        </button>
      </div>
    </div>
  );
}
