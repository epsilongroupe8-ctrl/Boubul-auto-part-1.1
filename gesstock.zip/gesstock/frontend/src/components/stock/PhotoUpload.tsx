import { useState, useRef } from 'react';
import { uploadPhoto, deletePhoto } from '../../api/photo.api';
import { useToast } from '../ui/Toast';
import { ProgressBar } from '../ui/ProgressBar';

interface PhotoUploadProps {
  pieceId: string;
  onSuccess: () => void;
  onCancel: () => void;
}

const MAX_SIZE_MB = 5;
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

export function PhotoUpload({ pieceId, onSuccess, onCancel }: PhotoUploadProps) {
  const { showToast } = useToast();
  const inputRef = useRef<HTMLInputElement>(null);

  const [preview, setPreview] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [progress, setProgress] = useState(0);
  const [uploading, setUploading] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const handleFileSelect = (file: File) => {
    if (!ALLOWED_TYPES.includes(file.type)) {
      showToast('Format non supporté. Utilisez JPEG, PNG, WEBP ou GIF.', 'error');
      return;
    }
    if (file.size > MAX_SIZE_MB * 1024 * 1024) {
      showToast(`La photo ne doit pas dépasser ${MAX_SIZE_MB} Mo.`, 'error');
      return;
    }
    setSelectedFile(file);
    const reader = new FileReader();
    reader.onload = e => setPreview(e.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  };

  const handleUpload = async () => {
    if (!selectedFile) return;
    setUploading(true);
    setProgress(0);
    try {
      await uploadPhoto(pieceId, selectedFile, (pct) => setProgress(pct));
      showToast('Photo enregistrée avec succès', 'success');
      onSuccess();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Erreur lors de l\'upload';
      showToast(message, 'error');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deletePhoto(pieceId);
      showToast('Photo supprimée', 'success');
      onSuccess();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Erreur lors de la suppression';
      showToast(message, 'error');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="photo-upload">
      <div
        className="drop-zone"
        onDrop={handleDrop}
        onDragOver={e => e.preventDefault()}
        onClick={() => inputRef.current?.click()}
      >
        {preview ? (
          <img src={preview} alt="Aperçu" className="photo-preview" />
        ) : (
          <div className="drop-hint">
            <span className="drop-icon">📷</span>
            <p>Cliquez ou glissez une photo ici</p>
            <p className="drop-sub">JPEG, PNG, WEBP · Max {MAX_SIZE_MB} Mo</p>
          </div>
        )}
      </div>

      <input
        ref={inputRef}
        type="file"
        accept={ALLOWED_TYPES.join(',')}
        style={{ display: 'none' }}
        onChange={e => { const f = e.target.files?.[0]; if (f) handleFileSelect(f); }}
      />

      {uploading && (
        <div className="upload-progress">
          <ProgressBar value={progress} />
          <span>{progress}%</span>
        </div>
      )}

      <div className="photo-actions">
        <button className="btn-secondary" onClick={onCancel} disabled={uploading || deleting}>
          Annuler
        </button>
        <button
          className="btn-danger"
          onClick={handleDelete}
          disabled={uploading || deleting}
        >
          {deleting ? 'Suppression…' : '🗑️ Supprimer la photo'}
        </button>
        <button
          className="btn-primary"
          onClick={handleUpload}
          disabled={!selectedFile || uploading || deleting}
        >
          {uploading ? `Upload… ${progress}%` : '📤 Enregistrer'}
        </button>
      </div>
    </div>
  );
}
