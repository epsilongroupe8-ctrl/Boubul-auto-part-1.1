import { useState, useCallback } from 'react';
import { useStockStore } from '../../store/stock.store';
import { useAuthStore } from '../../store/auth.store';
import { Piece } from '../../types';
import { Loader } from '../ui/Loader';
import { Modal } from '../ui/Modal';
import { PieceForm } from './PieceForm';
import { PhotoUpload } from './PhotoUpload';
import { Lightbox } from '../ui/Lightbox';
import { useStock } from '../../hooks/useStock';
import { getPhotoUrl } from '../../api/photo.api';
import { deletePiece } from '../../api/stock.api';
import { useToast } from '../ui/Toast';

const DEBOUNCE_DELAY = 300;

export function StockTable() {
  const { pieces, total, page, loading, setPage, setSearch, search } = useStockStore();
  const { user } = useAuthStore();
  const { refetch } = useStock();
  const { showToast } = useToast();

  const [editPiece, setEditPiece] = useState<Piece | null>(null);
  const [deletePieceId, setDeletePieceId] = useState<string | null>(null);
  const [lightboxUrl, setLightboxUrl] = useState<string | null>(null);
  const [photoUrls, setPhotoUrls] = useState<Record<string, string>>({});
  const [loadingPhoto, setLoadingPhoto] = useState<Record<string, boolean>>({});
  const [showAddModal, setShowAddModal] = useState(false);
  const [showPhotoModal, setShowPhotoModal] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);

  const isEmployeur = user?.role === 'employeur';
  const totalPages = Math.ceil(total / 50);

  let debounceTimer: ReturnType<typeof setTimeout>;
  const handleSearch = useCallback((value: string) => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      setSearch(value);
    }, DEBOUNCE_DELAY);
  }, [setSearch]);

  const loadPhotoUrl = async (piece: Piece) => {
    if (!piece.photo_path || photoUrls[piece.id]) return;
    setLoadingPhoto(prev => ({ ...prev, [piece.id]: true }));
    try {
      const url = await getPhotoUrl(piece.id);
      setPhotoUrls(prev => ({ ...prev, [piece.id]: url }));
    } catch {
      // no photo
    } finally {
      setLoadingPhoto(prev => ({ ...prev, [piece.id]: false }));
    }
  };

  const handleOpenLightbox = async (piece: Piece) => {
    if (!piece.photo_path) return;
    let url = photoUrls[piece.id];
    if (!url) {
      await loadPhotoUrl(piece);
      url = photoUrls[piece.id];
    }
    if (url) setLightboxUrl(url);
  };

  const handleDelete = async () => {
    if (!deletePieceId) return;
    setDeleting(true);
    try {
      await deletePiece(deletePieceId);
      showToast('Pièce supprimée avec succès', 'success');
      setDeletePieceId(null);
      refetch();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Erreur lors de la suppression';
      showToast(message, 'error');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="stock-table-container">
      <div className="stock-table-header">
        <div className="search-bar">
          <input
            type="text"
            placeholder="Rechercher par référence ou désignation…"
            defaultValue={search}
            onChange={e => handleSearch(e.target.value)}
            className="search-input"
          />
          <span className="search-icon">🔍</span>
        </div>
        {isEmployeur && (
          <button className="btn-primary" onClick={() => setShowAddModal(true)}>
            + Ajouter une pièce
          </button>
        )}
      </div>

      <div className="table-info">
        <span>{total} pièce{total !== 1 ? 's' : ''} au total</span>
      </div>

      {loading ? (
        <Loader text="Chargement du stock…" />
      ) : pieces.length === 0 ? (
        <div className="empty-state">
          <span className="empty-icon">📦</span>
          <p>Aucune pièce trouvée</p>
          {search && <p className="empty-hint">Essayez une autre recherche</p>}
        </div>
      ) : (
        <div className="table-wrapper">
          <table className="stock-table">
            <thead>
              <tr>
                <th>Photo</th>
                <th>Référence</th>
                <th>Désignation</th>
                <th>Prix</th>
                <th>Quantité</th>
                <th>Seuil</th>
                {isEmployeur && <th>Actions</th>}
              </tr>
            </thead>
            <tbody>
              {pieces.map(piece => (
                <tr
                  key={piece.id}
                  className={piece.quantite <= piece.seuil_alerte ? 'row-alert' : ''}
                >
                  <td className="photo-cell">
                    {piece.photo_path ? (
                      loadingPhoto[piece.id] ? (
                        <div className="photo-loading">⏳</div>
                      ) : photoUrls[piece.id] ? (
                        <img
                          src={photoUrls[piece.id]}
                          alt={piece.designation}
                          className="piece-thumb"
                          loading="lazy"
                          onClick={() => handleOpenLightbox(piece)}
                        />
                      ) : (
                        <button
                          className="photo-load-btn"
                          onClick={() => loadPhotoUrl(piece)}
                          title="Charger la photo"
                        >
                          🖼️
                        </button>
                      )
                    ) : (
                      <span className="no-photo">📦</span>
                    )}
                  </td>
                  <td className="ref-cell">{piece.reference}</td>
                  <td>{piece.designation}</td>
                  <td className="price-cell">{Number(piece.prix).toFixed(2)} €</td>
                  <td className={`qty-cell ${piece.quantite <= piece.seuil_alerte ? 'qty-alert' : ''}`}>
                    {piece.quantite <= piece.seuil_alerte && (
                      <span className="alert-badge" title="Stock bas">⚠️</span>
                    )}
                    {piece.quantite}
                  </td>
                  <td>{piece.seuil_alerte}</td>
                  {isEmployeur && (
                    <td className="actions-cell">
                      <button
                        className="btn-icon btn-edit"
                        onClick={() => setEditPiece(piece)}
                        title="Modifier"
                      >
                        ✏️
                      </button>
                      <button
                        className="btn-icon btn-photo"
                        onClick={() => setShowPhotoModal(piece.id)}
                        title="Photo"
                      >
                        📷
                      </button>
                      <button
                        className="btn-icon btn-delete"
                        onClick={() => setDeletePieceId(piece.id)}
                        title="Supprimer"
                      >
                        🗑️
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {totalPages > 1 && (
        <div className="pagination">
          <button
            className="btn-page"
            disabled={page === 1}
            onClick={() => setPage(page - 1)}
          >
            ← Précédent
          </button>
          <span className="page-info">Page {page} / {totalPages}</span>
          <button
            className="btn-page"
            disabled={page === totalPages}
            onClick={() => setPage(page + 1)}
          >
            Suivant →
          </button>
        </div>
      )}

      {showAddModal && (
        <Modal title="Ajouter une pièce" onClose={() => setShowAddModal(false)}>
          <PieceForm
            onSuccess={() => { setShowAddModal(false); refetch(); }}
            onCancel={() => setShowAddModal(false)}
          />
        </Modal>
      )}

      {editPiece && (
        <Modal title="Modifier la pièce" onClose={() => setEditPiece(null)}>
          <PieceForm
            piece={editPiece}
            onSuccess={() => { setEditPiece(null); refetch(); }}
            onCancel={() => setEditPiece(null)}
          />
        </Modal>
      )}

      {showPhotoModal && (
        <Modal title="Gestion de la photo" onClose={() => setShowPhotoModal(null)}>
          <PhotoUpload
            pieceId={showPhotoModal}
            onSuccess={() => {
              setShowPhotoModal(null);
              setPhotoUrls(prev => { const n = { ...prev }; delete n[showPhotoModal]; return n; });
              refetch();
            }}
            onCancel={() => setShowPhotoModal(null)}
          />
        </Modal>
      )}

      {deletePieceId && (
        <Modal title="Confirmer la suppression" onClose={() => setDeletePieceId(null)}>
          <div className="confirm-delete">
            <p>Êtes-vous sûr de vouloir supprimer cette pièce ?</p>
            <p className="confirm-warning">⚠️ Cette action est irréversible. La photo sera également supprimée.</p>
            <div className="confirm-actions">
              <button className="btn-secondary" onClick={() => setDeletePieceId(null)} disabled={deleting}>
                Annuler
              </button>
              <button className="btn-danger" onClick={handleDelete} disabled={deleting}>
                {deleting ? 'Suppression…' : 'Supprimer'}
              </button>
            </div>
          </div>
        </Modal>
      )}

      {lightboxUrl && (
        <Lightbox url={lightboxUrl} onClose={() => setLightboxUrl(null)} />
      )}
    </div>
  );
}
