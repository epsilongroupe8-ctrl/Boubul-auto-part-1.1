import { useState, useEffect } from 'react';
import { getStats } from '../../api/stats.api';
import { Stats } from '../../types';
import { Loader } from '../ui/Loader';
import { VentesChart } from './VentesChart';
import { useToast } from '../ui/Toast';

export function StatsDashboard() {
  const { showToast } = useToast();
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [periode, setPeriode] = useState<'aujourd_hui' | '7_jours' | 'mois' | 'total'>('mois');

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const data = await getStats(periode);
        setStats(data);
      } catch {
        showToast('Erreur lors du chargement des statistiques', 'error');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [periode]);

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);

  const periodLabels: Record<typeof periode, string> = {
    aujourd_hui: "Aujourd'hui",
    '7_jours': '7 derniers jours',
    mois: 'Mois en cours',
    total: 'Depuis le début',
  };

  return (
    <div className="stats-dashboard">
      <div className="periode-selector">
        {(Object.keys(periodLabels) as Array<typeof periode>).map(p => (
          <button
            key={p}
            className={`btn-periode ${periode === p ? 'active' : ''}`}
            onClick={() => setPeriode(p)}
          >
            {periodLabels[p]}
          </button>
        ))}
      </div>

      {loading ? (
        <Loader text="Chargement des statistiques…" />
      ) : stats ? (
        <>
          <div className="stats-cards">
            <div className="stat-card stat-ca">
              <div className="stat-icon">💰</div>
              <div className="stat-content">
                <div className="stat-label">Chiffre d'affaires</div>
                <div className="stat-value">{formatCurrency(stats.chiffre_affaires)}</div>
              </div>
            </div>

            <div className="stat-card stat-transactions">
              <div className="stat-icon">📊</div>
              <div className="stat-content">
                <div className="stat-label">Transactions</div>
                <div className="stat-value">{stats.nombre_transactions}</div>
              </div>
            </div>

            <div className="stat-card stat-sorties">
              <div className="stat-icon">📤</div>
              <div className="stat-content">
                <div className="stat-label">Sorties</div>
                <div className="stat-value">{stats.nombre_sorties}</div>
              </div>
            </div>

            <div className="stat-card stat-entrees">
              <div className="stat-icon">📥</div>
              <div className="stat-content">
                <div className="stat-label">Entrées</div>
                <div className="stat-value">{stats.nombre_entrees}</div>
              </div>
            </div>
          </div>

          <div className="stats-bottom">
            <div className="top-pieces">
              <h3>🏆 Top 5 pièces ce mois</h3>
              {stats.top_pieces.length === 0 ? (
                <p className="no-data">Aucune vente ce mois</p>
              ) : (
                <ol className="top-pieces-list">
                  {stats.top_pieces.map((item, i) => (
                    <li key={item.piece_id} className="top-piece-item">
                      <span className="rank">#{i + 1}</span>
                      <div className="top-piece-info">
                        <span className="top-piece-ref">{item.reference}</span>
                        <span className="top-piece-name">{item.designation}</span>
                      </div>
                      <div className="top-piece-stats">
                        <span className="top-qty">{item.total_vendu} vendus</span>
                        <span className="top-ca">{formatCurrency(item.chiffre_affaires)}</span>
                      </div>
                    </li>
                  ))}
                </ol>
              )}
            </div>

            <div className="ventes-chart-section">
              <h3>📈 Ventes sur 30 jours</h3>
              <VentesChart data={stats.ventes_30_jours} />
            </div>
          </div>
        </>
      ) : (
        <div className="empty-state">Aucune donnée disponible</div>
      )}
    </div>
  );
}
