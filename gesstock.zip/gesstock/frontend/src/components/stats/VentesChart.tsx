import { useEffect, useRef } from 'react';
import { Chart, registerables } from 'chart.js';
import { VenteJour } from '../../types';

Chart.register(...registerables);

interface VentesChartProps {
  data: VenteJour[];
}

export function VentesChart({ data }: VentesChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    if (chartRef.current) {
      chartRef.current.destroy();
    }

    const labels = data.map(d =>
      new Date(d.date).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' })
    );
    const values = data.map(d => d.chiffre_affaires);

    chartRef.current = new Chart(canvasRef.current, {
      type: 'line',
      data: {
        labels,
        datasets: [
          {
            label: 'Chiffre d\'affaires (€)',
            data: values,
            borderColor: '#3b82f6',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            borderWidth: 2,
            pointBackgroundColor: '#3b82f6',
            pointRadius: 3,
            pointHoverRadius: 6,
            fill: true,
            tension: 0.3,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          },
          tooltip: {
            callbacks: {
              label: ctx => {
                const val = ctx.parsed.y;
                return ` ${new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(val)}`;
              },
            },
            backgroundColor: '#1e293b',
            titleColor: '#94a3b8',
            bodyColor: '#f1f5f9',
            borderColor: '#334155',
            borderWidth: 1,
          },
        },
        scales: {
          x: {
            grid: { color: 'rgba(255,255,255,0.05)' },
            ticks: { color: '#94a3b8', font: { size: 11 } },
          },
          y: {
            grid: { color: 'rgba(255,255,255,0.05)' },
            ticks: {
              color: '#94a3b8',
              font: { size: 11 },
              callback: val => `${val} €`,
            },
            beginAtZero: true,
          },
        },
      },
    });

    return () => {
      chartRef.current?.destroy();
    };
  }, [data]);

  if (data.length === 0) {
    return (
      <div className="chart-empty">
        <span>📉</span>
        <p>Aucune donnée sur 30 jours</p>
      </div>
    );
  }

  return (
    <div className="chart-container">
      <canvas ref={canvasRef} />
    </div>
  );
}
