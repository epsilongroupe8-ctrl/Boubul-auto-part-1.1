import { useState, useEffect } from 'react';
import { changeCode, getAuditLogs, resetMagasin } from '../../api/auth.api';
import { AuditLog } from '../../types';
import { Loader } from '../ui/Loader';
import { PinInput } from '../ui/PinInput';
import { useToast } from '../ui/Toast';

export function Parametres() {
  const { showToast } = useToast();

  // Change code
  const [ancienCode, setAncienCode] = useState('');
  const [nouveauCode, setNouveauCode] = useState('');
  const [confirmCode, setConfirmCode] = useState('');
  const [savingCode, setSavingCode] = useState(false);

  // Audit log
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [loadingLogs, setLoadingLogs] = useState(true);

  // Reset
  const [showReset, setShowReset] = useState(false);
  const [resetToken, setResetToken] = useState('');
  const [resetCode, setResetCode] = useState('');
  const [resetting, setResetting] = useState(false);

  useEffect(() => {
    const load = async () => {
      setLoadingLogs(true);
      try {
        const data = await getAuditLogs();
        setAuditLogs(data.logs);
      } catch {
        showToast('Erreur lors du chargement des logs', 'error');
      } finally {
        setLoadingLogs(false);
      }
    };
    load();
  }, []);

  const handleChangeCode = async () => {
    if (ancienCode.length !== 6) { showToast('L\'ancien code doit faire 6 chiffres', 'error'); return; }
    if (nouveauCode.length !== 6) { showToast('Le nouveau code doit faire 6 chiffres', 'error'); return; }
    if (nouveauCode !== confirmCode) { showToast('Les codes ne correspondent pas', 'error'); return; }
    setSavingCode(true);
    try {
      await changeCode({ ancien_code: ancienCode, nouveau_code: nouveauCode });
      showToast('Code modifié avec succès', 'success');
      setAncienCode('');
      setNouveauCode('');
      setConfirmCode('');
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Erreur lors du changement de code';
      showToast(message, 'error');
    } finally {
      setSavingCode(false);
    }
  };

  const handleReset = async () => {
    if (!resetToken.trim()) { showToast('Le token de reset est obligatoire', 'error'); return; }
    if (resetCode.length !== 6) { showToast('Veuillez saisir le code à 6 chiffres', 'error'); return; }
    setResetting(true);
    try {
      await resetMagasin({ reset_token: resetToken, code_confirmation: resetCode });
      showToast('Reset effectué. Un email de confirmation a été envoyé.', 'success');
      setShowReset(false);
      setResetToken('');
      setResetCode('');
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Erreur lors du reset';
      showToast(message, 'error');
    } finally {
      setResetting(false);
    }
  };

  const formatDate = (dateStr: string) =>
    new Date(dateStr).toLocaleString('fr-FR', {
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
    });

  const actionLabel: Record<string, string> = {
    login: '🔑 Connexion',
    logout: '🚪 Déconnexion',
    piece_created: '➕ Pièce créée',
    piece_updated: '✏️ Pièce modifiée',
    piece_deleted: '🗑️ Pièce supprimée',
    transaction_created: '📦 Transaction',
    photo_uploaded: '📷 Photo ajoutée',
    photo_deleted: '🗑️ Photo supprimée',
    code_changed: '🔐 Code modifié',
    employe_created: '👤 Employé ajouté',
    employe_updated: '✏️ Employé modifié',
    employe_toggled: '🔒 Statut employé',
    reset: '⚠️ Reset effectué',
  };

  return (
    <div className="parametres">
      <section className="param-section">
        <h2>🔐 Modifier le code employeur</h2>
        <div className="code-form">
          <div className="form-group">
            <label>Ancien code (6 chiffres)</label>
            <PinInput length={6} value={ancienCode} onChange={setAncienCode} disabled={savingCode} />
          </div>
          <div className="form-group">
            <label>Nouveau code (6 chiffres)</label>
            <PinInput length={6} value={nouveauCode} onChange={setNouveauCode} disabled={savingCode} />
          </div>
          <div className="form-group">
            <label>Confirmer le nouveau code</label>
            <PinInput length={6} value={confirmCode} onChange={setConfirmCode} disabled={savingCode} />
          </div>
          <button className="btn-primary" onClick={handleChangeCode} disabled={savingCode}>
            {savingCode ? 'Modification…' : 'Modifier le code'}
          </button>
        </div>
      </section>

      <section className="param-section">
        <h2>📋 Journal d'audit (50 dernières entrées)</h2>
        {loadingLogs ? (
          <Loader text="Chargement des logs…" />
        ) : auditLogs.length === 0 ? (
          <p className="no-data">Aucun log disponible</p>
        ) : (
          <div className="audit-log-table">
            <table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Action</th>
                  <th>Rôle</th>
                  <th>Détails</th>
                </tr>
              </thead>
              <tbody>
                {auditLogs.map(log => (
                  <tr key={log.id}>
                    <td className="log-date">{formatDate(log.created_at)}</td>
                    <td>
                      <span className="log-action">
                        {actionLabel[log.action] ?? log.action}
                      </span>
                    </td>
                    <td>
                      <span className={`log-role log-role-${log.role}`}>{log.role}</span>
                    </td>
                    <td className="log-payload">
                      {log.payload ? (
                        <code>{JSON.stringify(log.payload).slice(0, 80)}{JSON.stringify(log.payload).length > 80 ? '…' : ''}</code>
                      ) : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <section className="param-section param-danger">
        <h2>⚠️ Zone dangereuse</h2>
        {!showReset ? (
          <button className="btn-danger" onClick={() => setShowReset(true)}>
            🔴 Reset d'urgence du magasin
          </button>
        ) : (
          <div className="reset-form">
            <p className="reset-warning">
              ⚠️ <strong>Attention :</strong> Cette action réinitialisera toutes les données du magasin.
              Un email de confirmation sera envoyé. Cette action est irréversible.
            </p>
            <div className="form-group">
              <label>Token de reset (variable d'environnement RESET_TOKEN)</label>
              <input
                type="password"
                value={resetToken}
                onChange={e => setResetToken(e.target.value)}
                placeholder="Token de reset"
                disabled={resetting}
              />
            </div>
            <div className="form-group">
              <label>Code employeur actuel (confirmation)</label>
              <PinInput length={6} value={resetCode} onChange={setResetCode} disabled={resetting} />
            </div>
            <div className="form-actions">
              <button className="btn-secondary" onClick={() => setShowReset(false)} disabled={resetting}>
                Annuler
              </button>
              <button className="btn-danger" onClick={handleReset} disabled={resetting}>
                {resetting ? 'Reset en cours…' : 'Confirmer le reset'}
              </button>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
