import { useState, useEffect, useCallback } from 'react';
import { getTransactions, downloadQuittance } from '../../api/transaction.api';
import { getEmployes } from '../../api/auth.api';
import { Transaction, Employe } from '../../types';
import { Loader } from '../ui/Loader';
import { useToast } from '../ui/Toast';

const PAGE_SIZE = 50;

export function Historique() {
  const { showToast } = useToast();

  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [employes, setEmployes] = useState<Employe[]>([]);

  const [filters, setFilters] = useState({
    type: '' as '' | 'entree' | 'sortie',
    employe_id: '',
    date_debut: '',
    date_fin: '',
  });

  const totalPages = Math.ceil(total / PAGE_SIZE);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getTransactions({
        page,
        limit: PAGE_SIZE,
        type: filters.type || undefined,
        employe_id: filters.employe_id || undefined,
        date_debut: filters.date_debut || undefined,
        date_fin: filters.date_fin || undefined,
      });
      setTransactions(data.transactions);
      setTotal(data.total);
    } catch {
      showToast('Erreur lors du chargement de l\'historique', 'error');
    } finally {
      setLoading(false);
    }
  }, [page, filters]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    getEmployes()
      .then(data => setEmployes(data.employes))
      .catch(() => {});
  }, []);

  const handleFilter = (key: keyof typeof filters, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setPage(1);
  };

  const handleDownloadQuittance = async (transaction: Transaction) => {
    if (!transaction.quittance_numero) return;
    try {
      await downloadQuittance(transaction.id, transaction.quittance_numero);
    } catch {
      showToast('Erreur lors du téléchargement de la quittance', 'error');
    }
  };

  const formatDate = (dateStr: string) =>
    new Date(dateStr).toLocaleString('fr-FR', {
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit',
    });

  return (
    <div className="historique">
      <div className="historique-filters">
        <select value={filters.type} onChange={e => handleFilter('type', e.target.value)}>
          <option value="">Tous les types</option>
          <option value="entree">Entrées</option>
          <option value="sortie">Sorties</option>
        </select>

        <select value={filters.employe_id} onChange={e => handleFilter('employe_id', e.target.value)}>
          <option value="">Tous les employés</option>
          {employes.map(emp => (
            <option key={emp.id} value={emp.id}>{emp.nom}</option>
          ))}
        </select>

        <div className="date-filters">
          <input
            type="date"
            value={filters.date_debut}
            onChange={e => handleFilter('date_debut', e.target.value)}
            placeholder="Début"
          />
          <span>→</span>
          <input
            type="date"
            value={filters.date_fin}
            onChange={e => handleFilter('date_fin', e.target.value)}
            placeholder="Fin"
          />
        </div>

        <button className="btn-secondary btn-sm" onClick={() => {
          setFilters({ type: '', employe_id: '', date_debut: '', date_fin: '' });
          setPage(1);
        }}>
          Réinitialiser
        </button>
      </div>

      <div className="historique-info">
        <span>{total} transaction{total !== 1 ? 's' : ''}</span>
      </div>

      {loading ? (
        <Loader text="Chargement de l'historique…" />
      ) : transactions.length === 0 ? (
        <div className="empty-state">
          <span className="empty-icon">📋</span>
          <p>Aucune transaction trouvée</p>
        </div>
      ) : (
        <div className="table-wrapper">
          <table className="historique-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Type</th>
                <th>Pièce</th>
                <th>Qté</th>
                <th>Prix unit.</th>
                <th>Total</th>
                <th>Employé</th>
                <th>Quittance</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map(t => (
                <tr key={t.id}>
                  <td className="date-cell">{formatDate(t.created_at)}</td>
                  <td>
                    <span className={`type-badge type-${t.type}`}>
                      {t.type === 'entree' ? '📥 Entrée' : '📤 Sortie'}
                    </span>
                  </td>
                  <td>
                    <div className="piece-info">
                      <span className="piece-ref">{t.piece?.reference ?? '—'}</span>
                      <span className="piece-name">{t.piece?.designation ?? '—'}</span>
                    </div>
                  </td>
                  <td className="qty-cell">{t.quantite}</td>
                  <td className="price-cell">{Number(t.prix_unitaire).toFixed(2)} €</td>
                  <td className="price-cell total-cell">
                    {(Number(t.prix_unitaire) * t.quantite).toFixed(2)} €
                  </td>
                  <td>{t.employe?.nom ?? '—'}</td>
                  <td>
                    {t.quittance_numero ? (
                      <button
                        className="btn-quittance"
                        onClick={() => handleDownloadQuittance(t)}
                        title="Télécharger la quittance PDF"
                      >
                        🧾 {t.quittance_numero}
                      </button>
                    ) : (
                      <span className="no-quittance">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {totalPages > 1 && (
        <div className="pagination">
          <button className="btn-page" disabled={page === 1} onClick={() => setPage(page - 1)}>
            ← Précédent
          </button>
          <span className="page-info">Page {page} / {totalPages}</span>
          <button className="btn-page" disabled={page === totalPages} onClick={() => setPage(page + 1)}>
            Suivant →
          </button>
        </div>
      )}
    </div>
  );
}
