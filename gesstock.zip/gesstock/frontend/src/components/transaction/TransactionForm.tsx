import { useState, useEffect } from 'react';
import { createTransaction } from '../../api/transaction.api';
import { useAuthStore } from '../../store/auth.store';
import { useToast } from '../ui/Toast';
import { Piece, Employe } from '../../types';
import { getPieces } from '../../api/stock.api';
import { getEmployes } from '../../api/auth.api';

interface TransactionFormProps {
  type: 'entree' | 'sortie';
  onSuccess: (quittance?: string) => void;
  onCancel: () => void;
}

export function TransactionForm({ type, onSuccess, onCancel }: TransactionFormProps) {
  const { user } = useAuthStore();
  const { showToast } = useToast();

  const [pieces, setPieces] = useState<Piece[]>([]);
  const [employes, setEmployes] = useState<Employe[]>([]);
  const [pieceId, setPieceId] = useState('');
  const [employeId, setEmployeId] = useState('');
  const [quantite, setQuantite] = useState(1);
  const [loading, setLoading] = useState(false);
  const [loadingData, setLoadingData] = useState(true);
  const [searchPiece, setSearchPiece] = useState('');

  const isEmployeur = user?.role === 'employeur';

  useEffect(() => {
    const load = async () => {
      try {
        const [piecesData, employesData] = await Promise.all([
          getPieces({ page: 1, limit: 200 }),
          isEmployeur || type === 'sortie' ? getEmployes() : Promise.resolve({ employes: [] }),
        ]);
        setPieces(piecesData.pieces);
        if ('employes' in employesData) setEmployes(employesData.employes);
      } catch {
        showToast('Erreur lors du chargement des données', 'error');
      } finally {
        setLoadingData(false);
      }
    };
    load();
  }, []);

  const filteredPieces = pieces.filter(p =>
    p.reference.toLowerCase().includes(searchPiece.toLowerCase()) ||
    p.designation.toLowerCase().includes(searchPiece.toLowerCase())
  );

  const selectedPiece = pieces.find(p => p.id === pieceId);

  const handleSubmit = async () => {
    if (!pieceId) { showToast('Veuillez sélectionner une pièce', 'error'); return; }
    if (type === 'sortie' && !employeId) { showToast('Veuillez sélectionner un employé', 'error'); return; }
    if (quantite <= 0) { showToast('La quantité doit être supérieure à 0', 'error'); return; }
    if (type === 'sortie' && selectedPiece && quantite > selectedPiece.quantite) {
      showToast(`Stock insuffisant. Disponible : ${selectedPiece.quantite}`, 'error');
      return;
    }

    setLoading(true);
    try {
      const result = await createTransaction({
        type,
        piece_id: pieceId,
        employe_id: employeId || undefined,
        quantite,
      });
      showToast(
        type === 'entree' ? 'Entrée enregistrée avec succès' : 'Sortie enregistrée, quittance générée',
        'success'
      );
      onSuccess(result.quittance_numero);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Erreur lors de la transaction';
      showToast(message, 'error');
    } finally {
      setLoading(false);
    }
  };

  if (loadingData) {
    return <div className="loading-data">Chargement des données…</div>;
  }

  return (
    <div className="transaction-form">
      <div className="form-type-badge" data-type={type}>
        {type === 'entree' ? '📥 Entrée de stock' : '📤 Sortie de stock'}
      </div>

      <div className="form-group">
        <label>Rechercher une pièce</label>
        <input
          type="text"
          placeholder="Référence ou désignation…"
          value={searchPiece}
          onChange={e => setSearchPiece(e.target.value)}
          disabled={loading}
        />
      </div>

      <div className="form-group">
        <label>Pièce *</label>
        <select
          value={pieceId}
          onChange={e => setPieceId(e.target.value)}
          disabled={loading}
        >
          <option value="">— Sélectionner une pièce —</option>
          {filteredPieces.map(p => (
            <option key={p.id} value={p.id}>
              [{p.reference}] {p.designation} — Stock: {p.quantite}
            </option>
          ))}
        </select>
      </div>

      {selectedPiece && (
        <div className="piece-summary">
          <span>Prix unitaire : <strong>{Number(selectedPiece.prix).toFixed(2)} €</strong></span>
          <span>Stock actuel : <strong className={selectedPiece.quantite <= selectedPiece.seuil_alerte ? 'text-alert' : ''}>{selectedPiece.quantite}</strong></span>
        </div>
      )}

      <div className="form-group">
        <label>Quantité *</label>
        <input
          type="number"
          min="1"
          step="1"
          value={quantite}
          onChange={e => setQuantite(parseInt(e.target.value, 10) || 1)}
          disabled={loading}
        />
        {type === 'sortie' && selectedPiece && quantite > selectedPiece.quantite && (
          <span className="field-error">⚠️ Stock insuffisant</span>
        )}
      </div>

      {type === 'sortie' && (
        <div className="form-group">
          <label>Employé *</label>
          <select value={employeId} onChange={e => setEmployeId(e.target.value)} disabled={loading}>
            <option value="">— Sélectionner un employé —</option>
            {employes.map(emp => (
              <option key={emp.id} value={emp.id}>{emp.nom}</option>
            ))}
          </select>
        </div>
      )}

      {selectedPiece && (
        <div className="transaction-total">
          Total estimé : <strong>{(Number(selectedPiece.prix) * quantite).toFixed(2)} €</strong>
        </div>
      )}

      <div className="form-actions">
        <button className="btn-secondary" onClick={onCancel} disabled={loading}>Annuler</button>
        <button
          className={`btn-primary ${type === 'sortie' ? 'btn-sortie' : ''}`}
          onClick={handleSubmit}
          disabled={loading}
        >
          {loading ? 'Traitement…' : type === 'entree' ? 'Valider l\'entrée' : 'Valider la sortie'}
        </button>
      </div>
    </div>
  );
}
