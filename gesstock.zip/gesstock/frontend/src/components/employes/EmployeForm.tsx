import { useState, useEffect } from 'react';
import { getEmployes, createEmploye, updateEmploye, toggleEmploye } from '../../api/auth.api';
import { Employe } from '../../types';
import { Loader } from '../ui/Loader';
import { Modal } from '../ui/Modal';
import { useToast } from '../ui/Toast';

export function EmployeForm() {
  const { showToast } = useToast();
  const [employes, setEmployes] = useState<Employe[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [editEmploye, setEditEmploye] = useState<Employe | null>(null);
  const [nom, setNom] = useState('');
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const data = await getEmployes();
      setEmployes(data.employes);
    } catch {
      showToast('Erreur lors du chargement des employés', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleAdd = async () => {
    if (!nom.trim()) { showToast('Le nom est obligatoire', 'error'); return; }
    setSaving(true);
    try {
      await createEmploye({ nom: nom.trim() });
      showToast('Employé ajouté avec succès', 'success');
      setNom('');
      setShowAdd(false);
      load();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Erreur lors de l\'ajout';
      showToast(message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = async () => {
    if (!editEmploye || !nom.trim()) { showToast('Le nom est obligatoire', 'error'); return; }
    setSaving(true);
    try {
      await updateEmploye(editEmploye.id, { nom: nom.trim() });
      showToast('Nom mis à jour', 'success');
      setEditEmploye(null);
      setNom('');
      load();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Erreur lors de la mise à jour';
      showToast(message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleToggle = async (emp: Employe) => {
    try {
      await toggleEmploye(emp.id, !emp.actif);
      showToast(emp.actif ? 'Employé désactivé' : 'Employé réactivé', 'success');
      load();
    } catch {
      showToast('Erreur lors de la modification du statut', 'error');
    }
  };

  const openEdit = (emp: Employe) => {
    setEditEmploye(emp);
    setNom(emp.nom);
  };

  if (loading) return <Loader text="Chargement des employés…" />;

  return (
    <div className="employe-form">
      <div className="employe-header">
        <h2>Gestion des employés</h2>
        <button className="btn-primary" onClick={() => { setShowAdd(true); setNom(''); }}>
          + Ajouter un employé
        </button>
      </div>

      {employes.length === 0 ? (
        <div className="empty-state">
          <span className="empty-icon">👥</span>
          <p>Aucun employé enregistré</p>
        </div>
      ) : (
        <div className="employe-list">
          {employes.map(emp => (
            <div key={emp.id} className={`employe-card ${!emp.actif ? 'employe-inactif' : ''}`}>
              <div className="employe-info">
                <div className="employe-avatar">
                  {emp.nom.charAt(0).toUpperCase()}
                </div>
                <div className="employe-details">
                  <span className="employe-nom">{emp.nom}</span>
                  <span className="employe-ref">{emp.reference}</span>
                </div>
                <span className={`employe-status ${emp.actif ? 'status-actif' : 'status-inactif'}`}>
                  {emp.actif ? '● Actif' : '● Inactif'}
                </span>
              </div>
              <div className="employe-actions">
                <button
                  className="btn-icon btn-edit"
                  onClick={() => openEdit(emp)}
                  title="Modifier le nom"
                >
                  ✏️
                </button>
                <button
                  className={`btn-icon ${emp.actif ? 'btn-deactivate' : 'btn-activate'}`}
                  onClick={() => handleToggle(emp)}
                  title={emp.actif ? 'Désactiver' : 'Réactiver'}
                >
                  {emp.actif ? '🔒' : '🔓'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showAdd && (
        <Modal title="Ajouter un employé" onClose={() => setShowAdd(false)}>
          <div className="employe-modal-form">
            <div className="form-group">
              <label>Nom de l'employé *</label>
              <input
                type="text"
                value={nom}
                onChange={e => setNom(e.target.value)}
                placeholder="Ex: Jean Dupont"
                disabled={saving}
                autoFocus
              />
            </div>
            <div className="form-actions">
              <button className="btn-secondary" onClick={() => setShowAdd(false)} disabled={saving}>Annuler</button>
              <button className="btn-primary" onClick={handleAdd} disabled={saving}>
                {saving ? 'Ajout…' : 'Ajouter'}
              </button>
            </div>
          </div>
        </Modal>
      )}

      {editEmploye && (
        <Modal title="Modifier l'employé" onClose={() => setEditEmploye(null)}>
          <div className="employe-modal-form">
            <div className="form-group">
              <label>Nouveau nom *</label>
              <input
                type="text"
                value={nom}
                onChange={e => setNom(e.target.value)}
                placeholder="Nouveau nom"
                disabled={saving}
                autoFocus
              />
            </div>
            <div className="form-actions">
              <button className="btn-secondary" onClick={() => setEditEmploye(null)} disabled={saving}>Annuler</button>
              <button className="btn-primary" onClick={handleEdit} disabled={saving}>
                {saving ? 'Mise à jour…' : 'Enregistrer'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
