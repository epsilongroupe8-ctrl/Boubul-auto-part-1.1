interface ProgressBarProps {
  value: number; // 0–100
  label?: string;
  color?: string;
  height?: number;
}

export function ProgressBar({
  value,
  label,
  color = '#3b82f6',
  height = 8,
}: ProgressBarProps) {
  const clamped = Math.min(100, Math.max(0, value));

  return (
    <div style={{ width: '100%' }}>
      {label && (
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            marginBottom: '0.25rem',
          }}
        >
          <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{label}</span>
          <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{clamped}%</span>
        </div>
      )}
      <div
        style={{
          width: '100%',
          height,
          backgroundColor: '#1e293b',
          borderRadius: height / 2,
          overflow: 'hidden',
          border: '1px solid #334155',
        }}
      >
        <div
          style={{
            height: '100%',
            width: `${clamped}%`,
            backgroundColor: color,
            borderRadius: height / 2,
            transition: 'width 0.3s ease',
          }}
        />
      </div>
    </div>
  );
}
