interface LoaderProps {
  size?: number;
  color?: string;
  fullScreen?: boolean;
}

export function Loader({ size = 32, color = '#3b82f6', fullScreen = false }: LoaderProps) {
  const spinner = (
    <div
      style={{
        width: size,
        height: size,
        border: `3px solid ${color}30`,
        borderTop: `3px solid ${color}`,
        borderRadius: '50%',
        animation: 'spin 0.7s linear infinite',
      }}
    />
  );

  if (fullScreen) {
    return (
      <div
        style={{
          position: 'fixed',
          inset: 0,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: 'rgba(0,0,0,0.5)',
          zIndex: 2000,
        }}
      >
        {spinner}
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  return (
    <>
      {spinner}
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </>
  );
}

interface InlineLoaderProps {
  text?: string;
}

export function InlineLoader({ text = 'Chargement...' }: InlineLoaderProps) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '2rem', justifyContent: 'center' }}>
      <Loader size={24} />
      <span style={{ color: '#94a3b8', fontSize: '0.875rem' }}>{text}</span>
    </div>
  );
}
