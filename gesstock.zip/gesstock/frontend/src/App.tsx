import { useEffect, useState } from 'react';
import { useAuthStore } from './store/auth.store';
import { Login } from './pages/Login';
import { Stock } from './pages/Stock';
import { Transactions } from './pages/Transactions';
import { Stats } from './pages/Stats';
import { Employes } from './pages/Employes';
import { Parametres } from './pages/Parametres';
import { ToastProvider, useToast } from './components/ui/Toast';
import { useRealtime } from './hooks/useRealtime';
import { refreshToken } from './api/auth.api';

type Page = 'stock' | 'transactions' | 'stats' | 'employes' | 'parametres';

function AppContent() {
  const { token, user, setAuth, clearAuth } = useAuthStore();
  const { showToast } = useToast();
  const [page, setPage] = useState<Page>('stock');
  const [menuOpen, setMenuOpen] = useState(false);

  const { connected } = useRealtime(token ?? null);

  const isEmployeur = user?.role === 'employeur';

  // Silent token refresh
  useEffect(() => {
    if (!token) return;
    const interval = setInterval(async () => {
      try {
        const data = await refreshToken();
        setAuth(data.token, data.user);
      } catch {
        clearAuth();
        showToast('Session expirée. Veuillez vous reconnecter.', 'error');
      }
    }, 25 * 60 * 1000); // every 25 minutes (JWT expires in 8h, refresh token 7 days)
    return () => clearInterval(interval);
  }, [token]);

  if (!token || !user) {
    return <Login />;
  }

  const navItems: { page: Page; label: string; icon: string; employeurOnly?: boolean }[] = [
    { page: 'stock', label: 'Stock', icon: '📦' },
    { page: 'transactions', label: 'Transactions', icon: '📋' },
    { page: 'stats', label: 'Statistiques', icon: '📊', employeurOnly: true },
    { page: 'employes', label: 'Employés', icon: '👥', employeurOnly: true },
    { page: 'parametres', label: 'Paramètres', icon: '⚙️', employeurOnly: true },
  ];

  const visibleNav = navItems.filter(n => !n.employeurOnly || isEmployeur);

  const handleLogout = async () => {
    try {
      const { logout } = await import('./api/auth.api');
      await logout();
    } catch {
      // ignore
    } finally {
      clearAuth();
    }
  };

  return (
    <div className="app">
      <nav className="sidebar">
        <div className="sidebar-logo">
          <span className="logo-icon">🔧</span>
          <span className="logo-text">GesStock</span>
        </div>

        <div className="sidebar-user">
          <div className="user-avatar">{user.nom?.charAt(0)?.toUpperCase() ?? 'U'}</div>
          <div className="user-info">
            <span className="user-name">{user.nom}</span>
            <span className="user-role">{isEmployeur ? 'Employeur' : 'Employé'}</span>
          </div>
          <div className={`realtime-dot ${connected ? 'connected' : 'disconnected'}`}
            title={connected ? 'Connecté en temps réel' : 'Déconnecté'} />
        </div>

        <ul className="nav-list">
          {visibleNav.map(item => (
            <li key={item.page}>
              <button
                className={`nav-item ${page === item.page ? 'active' : ''}`}
                onClick={() => { setPage(item.page); setMenuOpen(false); }}
              >
                <span className="nav-icon">{item.icon}</span>
                <span className="nav-label">{item.label}</span>
              </button>
            </li>
          ))}
        </ul>

        <div className="sidebar-footer">
          <button className="btn-logout" onClick={handleLogout}>
            🚪 Déconnexion
          </button>
        </div>
      </nav>

      {/* Mobile header */}
      <header className="mobile-header">
        <button className="hamburger" onClick={() => setMenuOpen(v => !v)}>☰</button>
        <span className="mobile-title">🔧 GesStock</span>
        <div className={`realtime-dot ${connected ? 'connected' : 'disconnected'}`} />
      </header>

      {menuOpen && (
        <div className="mobile-nav-overlay" onClick={() => setMenuOpen(false)}>
          <div className="mobile-nav" onClick={e => e.stopPropagation()}>
            <div className="mobile-user">
              <strong>{user.nom}</strong>
              <span>{isEmployeur ? 'Employeur' : 'Employé'}</span>
            </div>
            {visibleNav.map(item => (
              <button
                key={item.page}
                className={`mobile-nav-item ${page === item.page ? 'active' : ''}`}
                onClick={() => { setPage(item.page); setMenuOpen(false); }}
              >
                {item.icon} {item.label}
              </button>
            ))}
            <button className="btn-logout-mobile" onClick={handleLogout}>
              🚪 Déconnexion
            </button>
          </div>
        </div>
      )}

      <main className="main-content">
        {page === 'stock' && <Stock />}
        {page === 'transactions' && <Transactions />}
        {page === 'stats' && isEmployeur && <Stats />}
        {page === 'employes' && isEmployeur && <Employes />}
        {page === 'parametres' && isEmployeur && <Parametres />}
      </main>

      <style>{`
        :root {
          --bg-primary: #0f172a;
          --bg-secondary: #1e293b;
          --bg-tertiary: #334155;
          --text-primary: #f1f5f9;
          --text-secondary: #94a3b8;
          --accent: #3b82f6;
          --accent-hover: #2563eb;
          --success: #22c55e;
          --warning: #f59e0b;
          --danger: #ef4444;
          --danger-hover: #dc2626;
          --border: #334155;
          --radius: 8px;
          --shadow: 0 4px 6px -1px rgba(0,0,0,0.4);
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
          font-family: 'Inter', system-ui, sans-serif;
          background: var(--bg-primary);
          color: var(--text-primary);
          min-height: 100vh;
        }

        .app {
          display: flex;
          min-height: 100vh;
        }

        /* SIDEBAR */
        .sidebar {
          width: 240px;
          background: var(--bg-secondary);
          border-right: 1px solid var(--border);
          display: flex;
          flex-direction: column;
          position: fixed;
          top: 0; left: 0; bottom: 0;
          z-index: 100;
          overflow-y: auto;
        }
        .sidebar-logo {
          padding: 24px 20px 16px;
          display: flex;
          align-items: center;
          gap: 10px;
          border-bottom: 1px solid var(--border);
        }
        .logo-icon { font-size: 24px; }
        .logo-text { font-size: 18px; font-weight: 700; color: var(--accent); }
        .sidebar-user {
          padding: 16px 20px;
          display: flex;
          align-items: center;
          gap: 10px;
          border-bottom: 1px solid var(--border);
        }
        .user-avatar {
          width: 36px; height: 36px;
          background: var(--accent);
          border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
          font-weight: 700; font-size: 14px;
          flex-shrink: 0;
        }
        .user-info { flex: 1; min-width: 0; }
        .user-name { display: block; font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .user-role { display: block; font-size: 11px; color: var(--text-secondary); }
        .realtime-dot {
          width: 10px; height: 10px;
          border-radius: 50%;
          flex-shrink: 0;
        }
        .realtime-dot.connected { background: var(--success); box-shadow: 0 0 6px var(--success); }
        .realtime-dot.disconnected { background: var(--danger); }
        .nav-list { list-style: none; padding: 12px 0; flex: 1; }
        .nav-item {
          display: flex; align-items: center; gap: 12px;
          width: 100%; padding: 10px 20px;
          background: none; border: none; cursor: pointer;
          color: var(--text-secondary); font-size: 14px;
          border-radius: 0; transition: all 0.15s;
          text-align: left;
        }
        .nav-item:hover { background: var(--bg-tertiary); color: var(--text-primary); }
        .nav-item.active { background: rgba(59,130,246,0.15); color: var(--accent); border-right: 3px solid var(--accent); }
        .nav-icon { font-size: 18px; }
        .sidebar-footer { padding: 16px 20px; border-top: 1px solid var(--border); }
        .btn-logout {
          width: 100%; padding: 8px; background: none; border: 1px solid var(--border);
          color: var(--text-secondary); border-radius: var(--radius); cursor: pointer;
          font-size: 13px; transition: all 0.15s;
        }
        .btn-logout:hover { border-color: var(--danger); color: var(--danger); }

        /* MAIN */
        .main-content { margin-left: 240px; flex: 1; padding: 0; min-width: 0; }
        .mobile-header { display: none; }

        /* PAGE */
        .page { padding: 24px; }
        .page-header {
          display: flex; align-items: flex-start; justify-content: space-between;
          margin-bottom: 24px; gap: 16px; flex-wrap: wrap;
        }
        .page-title h1 { font-size: 24px; font-weight: 700; }
        .page-title p { color: var(--text-secondary); font-size: 14px; margin-top: 2px; }
        .page-actions { display: flex; gap: 8px; flex-wrap: wrap; }

        /* BUTTONS */
        .btn-primary {
          background: var(--accent); color: white; border: none;
          padding: 10px 20px; border-radius: var(--radius); cursor: pointer;
          font-size: 14px; font-weight: 500; transition: background 0.15s;
        }
        .btn-primary:hover:not(:disabled) { background: var(--accent-hover); }
        .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-secondary {
          background: var(--bg-tertiary); color: var(--text-primary); border: 1px solid var(--border);
          padding: 10px 20px; border-radius: var(--radius); cursor: pointer;
          font-size: 14px; font-weight: 500; transition: all 0.15s;
        }
        .btn-secondary:hover:not(:disabled) { background: var(--bg-secondary); }
        .btn-secondary:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-danger {
          background: var(--danger); color: white; border: none;
          padding: 10px 20px; border-radius: var(--radius); cursor: pointer;
          font-size: 14px; font-weight: 500; transition: background 0.15s;
        }
        .btn-danger:hover:not(:disabled) { background: var(--danger-hover); }
        .btn-danger:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-success { background: var(--success); color: white; border: none; padding: 10px 20px; border-radius: var(--radius); cursor: pointer; font-size: 14px; font-weight: 500; }
        .btn-warning { background: var(--warning); color: #0f172a; border: none; padding: 10px 20px; border-radius: var(--radius); cursor: pointer; font-size: 14px; font-weight: 500; }
        .btn-sm { padding: 7px 14px; font-size: 13px; }
        .btn-full { width: 100%; }
        .btn-icon {
          background: none; border: none; cursor: pointer;
          padding: 6px; border-radius: 4px; font-size: 16px;
          transition: background 0.15s;
        }
        .btn-icon:hover { background: var(--bg-tertiary); }

        /* FORMS */
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 13px; color: var(--text-secondary); margin-bottom: 6px; }
        .form-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
        input, select, textarea {
          width: 100%; padding: 10px 12px;
          background: var(--bg-primary); border: 1px solid var(--border);
          color: var(--text-primary); border-radius: var(--radius);
          font-size: 14px; transition: border-color 0.15s;
        }
        input:focus, select:focus { outline: none; border-color: var(--accent); }
        input.input-error { border-color: var(--danger); }
        .field-error { display: block; color: var(--danger); font-size: 12px; margin-top: 4px; }
        .form-actions { display: flex; gap: 8px; justify-content: flex-end; margin-top: 20px; }

        /* TABLE */
        .table-wrapper { overflow-x: auto; border-radius: var(--radius); border: 1px solid var(--border); }
        table { width: 100%; border-collapse: collapse; }
        thead { background: var(--bg-tertiary); }
        th { padding: 12px 14px; text-align: left; font-size: 12px; color: var(--text-secondary); font-weight: 600; white-space: nowrap; }
        td { padding: 12px 14px; font-size: 14px; border-top: 1px solid var(--border); }
        tr:hover td { background: rgba(255,255,255,0.02); }
        .row-alert td { background: rgba(239,68,68,0.05); }
        .qty-alert { color: var(--danger); font-weight: 600; }
        .alert-badge { margin-right: 4px; }
        .price-cell { font-variant-numeric: tabular-nums; }
        .ref-cell { font-family: monospace; font-size: 13px; color: var(--accent); }
        .actions-cell { white-space: nowrap; }
        .photo-cell { width: 70px; }
        .piece-thumb { width: 60px; height: 60px; object-fit: cover; border-radius: 6px; cursor: pointer; transition: opacity 0.15s; }
        .piece-thumb:hover { opacity: 0.8; }
        .no-photo { font-size: 24px; display: block; text-align: center; color: var(--text-secondary); }

        /* SEARCH */
        .stock-table-container { }
        .stock-table-header { display: flex; gap: 12px; margin-bottom: 16px; align-items: center; }
        .search-bar { position: relative; flex: 1; max-width: 400px; }
        .search-input { padding-left: 36px; }
        .search-icon { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--text-secondary); }
        .table-info { font-size: 13px; color: var(--text-secondary); margin-bottom: 12px; }

        /* PAGINATION */
        .pagination { display: flex; align-items: center; justify-content: center; gap: 16px; padding: 16px 0; }
        .btn-page { background: var(--bg-secondary); border: 1px solid var(--border); color: var(--text-primary); padding: 8px 16px; border-radius: var(--radius); cursor: pointer; font-size: 13px; }
        .btn-page:disabled { opacity: 0.4; cursor: not-allowed; }
        .page-info { font-size: 13px; color: var(--text-secondary); }

        /* EMPTY STATE */
        .empty-state { text-align: center; padding: 48px 24px; color: var(--text-secondary); }
        .empty-icon { font-size: 48px; display: block; margin-bottom: 12px; }
        .empty-hint { font-size: 13px; margin-top: 8px; }

        /* LOGIN */
        .login-page {
          min-height: 100vh; display: flex; align-items: center; justify-content: center;
          background: var(--bg-primary); padding: 16px;
        }
        .login-card {
          background: var(--bg-secondary); border: 1px solid var(--border);
          border-radius: 16px; padding: 40px 32px; width: 100%; max-width: 420px;
          box-shadow: var(--shadow);
        }
        .login-logo { text-align: center; margin-bottom: 32px; }
        .login-logo .logo-icon { font-size: 48px; display: block; margin-bottom: 8px; }
        .login-logo h1 { font-size: 28px; font-weight: 800; color: var(--accent); }
        .login-logo p { color: var(--text-secondary); font-size: 14px; margin-top: 4px; }
        .login-step h2 { font-size: 18px; font-weight: 600; margin-bottom: 20px; }
        .login-sub { color: var(--text-secondary); font-size: 14px; margin-bottom: 20px; }
        .login-input { font-size: 16px; }
        .profil-cards { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .profil-card {
          background: var(--bg-primary); border: 2px solid var(--border);
          border-radius: var(--radius); padding: 20px 12px; cursor: pointer;
          text-align: center; transition: all 0.15s; display: flex;
          flex-direction: column; align-items: center; gap: 6px;
        }
        .profil-card:hover { border-color: var(--accent); background: rgba(59,130,246,0.05); }
        .profil-employeur:hover { border-color: var(--warning); background: rgba(245,158,11,0.05); }
        .profil-icon { font-size: 32px; }
        .profil-label { font-size: 14px; font-weight: 600; }
        .profil-desc { font-size: 11px; color: var(--text-secondary); }
        .employe-select-list { display: flex; flex-direction: column; gap: 8px; max-height: 300px; overflow-y: auto; }
        .employe-select-btn {
          display: flex; align-items: center; gap: 10px;
          padding: 12px 16px; background: var(--bg-primary);
          border: 1px solid var(--border); border-radius: var(--radius);
          color: var(--text-primary); cursor: pointer; font-size: 14px;
          transition: all 0.15s;
        }
        .employe-select-btn:hover { border-color: var(--accent); background: rgba(59,130,246,0.05); }
        .employe-avatar-sm {
          width: 32px; height: 32px; background: var(--accent);
          border-radius: 50%; display: flex; align-items: center; justify-content: center;
          font-weight: 700; font-size: 13px; flex-shrink: 0;
        }
        .pin-wrapper { display: flex; justify-content: center; margin: 20px 0; }
        .btn-back { background: none; border: none; color: var(--text-secondary); cursor: pointer; font-size: 13px; margin-bottom: 16px; padding: 0; }
        .btn-back:hover { color: var(--text-primary); }
        .no-employes { color: var(--text-secondary); text-align: center; padding: 20px; }

        /* MODALS (placeholder - see Modal component) */
        .confirm-delete p { color: var(--text-secondary); font-size: 14px; margin-bottom: 8px; }
        .confirm-warning { color: var(--warning) !important; }
        .confirm-actions { display: flex; gap: 8px; justify-content: flex-end; margin-top: 20px; }

        /* TRANSACTION */
        .transaction-form { }
        .form-type-badge { padding: 8px 14px; border-radius: var(--radius); font-size: 14px; font-weight: 600; margin-bottom: 20px; display: inline-block; }
        .form-type-badge[data-type="entree"] { background: rgba(34,197,94,0.15); color: var(--success); }
        .form-type-badge[data-type="sortie"] { background: rgba(239,68,68,0.15); color: var(--danger); }
        .piece-summary { display: flex; gap: 20px; padding: 10px 14px; background: var(--bg-primary); border-radius: var(--radius); margin-bottom: 16px; font-size: 13px; }
        .text-alert { color: var(--danger); }
        .transaction-total { text-align: right; font-size: 16px; color: var(--text-secondary); margin-bottom: 4px; }
        .transaction-total strong { color: var(--text-primary); }

        /* HISTORIQUE */
        .historique-filters { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 16px; }
        .date-filters { display: flex; align-items: center; gap: 6px; }
        .date-filters input { width: 140px; }
        .type-badge { padding: 3px 8px; border-radius: 12px; font-size: 12px; font-weight: 500; }
        .type-entree { background: rgba(34,197,94,0.15); color: var(--success); }
        .type-sortie { background: rgba(239,68,68,0.15); color: var(--danger); }
        .piece-info { display: flex; flex-direction: column; }
        .piece-ref { font-size: 12px; color: var(--accent); font-family: monospace; }
        .piece-name { font-size: 13px; }
        .total-cell { font-weight: 600; }
        .btn-quittance { background: none; border: none; color: var(--accent); cursor: pointer; font-size: 13px; font-family: monospace; text-decoration: underline; }
        .quittance-toast { position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); background: var(--bg-secondary); border: 1px solid var(--accent); padding: 12px 20px; border-radius: var(--radius); display: flex; align-items: center; gap: 12px; z-index: 9999; }
        .quittance-toast button { background: none; border: none; color: var(--text-secondary); cursor: pointer; }

        /* STATS */
        .stats-dashboard { }
        .periode-selector { display: flex; gap: 8px; margin-bottom: 24px; flex-wrap: wrap; }
        .btn-periode { padding: 8px 16px; background: var(--bg-secondary); border: 1px solid var(--border); color: var(--text-secondary); border-radius: 20px; cursor: pointer; font-size: 13px; transition: all 0.15s; }
        .btn-periode.active { background: var(--accent); border-color: var(--accent); color: white; }
        .stats-cards { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px; }
        .stat-card { background: var(--bg-secondary); border: 1px solid var(--border); border-radius: var(--radius); padding: 20px; display: flex; align-items: center; gap: 16px; }
        .stat-icon { font-size: 32px; }
        .stat-label { font-size: 12px; color: var(--text-secondary); margin-bottom: 4px; }
        .stat-value { font-size: 22px; font-weight: 700; font-variant-numeric: tabular-nums; }
        .stats-bottom { display: grid; grid-template-columns: 360px 1fr; gap: 20px; }
        .top-pieces { background: var(--bg-secondary); border: 1px solid var(--border); border-radius: var(--radius); padding: 20px; }
        .top-pieces h3, .ventes-chart-section h3 { font-size: 15px; font-weight: 600; margin-bottom: 16px; }
        .top-pieces-list { list-style: none; display: flex; flex-direction: column; gap: 10px; }
        .top-piece-item { display: flex; align-items: center; gap: 10px; padding: 10px; background: var(--bg-primary); border-radius: var(--radius); }
        .rank { font-size: 16px; font-weight: 700; color: var(--warning); min-width: 28px; }
        .top-piece-info { flex: 1; min-width: 0; }
        .top-piece-ref { display: block; font-size: 11px; color: var(--accent); font-family: monospace; }
        .top-piece-name { display: block; font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .top-piece-stats { text-align: right; }
        .top-qty { display: block; font-size: 12px; color: var(--text-secondary); }
        .top-ca { display: block; font-size: 13px; font-weight: 600; }
        .ventes-chart-section { background: var(--bg-secondary); border: 1px solid var(--border); border-radius: var(--radius); padding: 20px; }
        .chart-container { height: 260px; }
        .chart-empty { text-align: center; padding: 40px; color: var(--text-secondary); }
        .no-data { color: var(--text-secondary); font-size: 13px; text-align: center; padding: 20px; }

        /* EMPLOYES */
        .employe-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
        .employe-header h2 { font-size: 18px; }
        .employe-list { display: flex; flex-direction: column; gap: 10px; }
        .employe-card { background: var(--bg-secondary); border: 1px solid var(--border); border-radius: var(--radius); padding: 16px; display: flex; align-items: center; justify-content: space-between; }
        .employe-inactif { opacity: 0.5; }
        .employe-info { display: flex; align-items: center; gap: 12px; flex: 1; }
        .employe-avatar { width: 40px; height: 40px; background: var(--accent); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 16px; flex-shrink: 0; }
        .employe-nom { display: block; font-size: 15px; font-weight: 600; }
        .employe-ref { display: block; font-size: 12px; font-family: monospace; color: var(--text-secondary); }
        .employe-status { font-size: 12px; font-weight: 500; }
        .status-actif { color: var(--success); }
        .status-inactif { color: var(--danger); }
        .employe-actions { display: flex; gap: 4px; }
        .employe-modal-form { min-width: 300px; }

        /* PARAMETRES */
        .parametres { display: flex; flex-direction: column; gap: 28px; }
        .param-section { background: var(--bg-secondary); border: 1px solid var(--border); border-radius: var(--radius); padding: 24px; }
        .param-section h2 { font-size: 17px; font-weight: 600; margin-bottom: 20px; }
        .param-danger { border-color: var(--danger); }
        .code-form { max-width: 360px; }
        .audit-log-table { overflow-x: auto; }
        .audit-log-table table { font-size: 13px; }
        .log-date { font-size: 12px; color: var(--text-secondary); white-space: nowrap; }
        .log-action { font-size: 13px; }
        .log-role { padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: 600; }
        .log-role-employeur { background: rgba(245,158,11,0.15); color: var(--warning); }
        .log-role-employe { background: rgba(59,130,246,0.15); color: var(--accent); }
        .log-payload code { font-size: 11px; color: var(--text-secondary); }
        .reset-warning { background: rgba(239,68,68,0.1); border: 1px solid var(--danger); border-radius: var(--radius); padding: 12px; font-size: 13px; margin-bottom: 16px; }
        .reset-form { max-width: 440px; }

        /* PHOTO UPLOAD */
        .photo-upload { }
        .drop-zone {
          border: 2px dashed var(--border); border-radius: var(--radius);
          padding: 24px; text-align: center; cursor: pointer;
          transition: border-color 0.15s; min-height: 180px;
          display: flex; align-items: center; justify-content: center; margin-bottom: 16px;
        }
        .drop-zone:hover { border-color: var(--accent); }
        .drop-hint { color: var(--text-secondary); }
        .drop-icon { font-size: 40px; display: block; margin-bottom: 8px; }
        .drop-sub { font-size: 12px; margin-top: 4px; }
        .photo-preview { max-width: 100%; max-height: 300px; border-radius: var(--radius); }
        .upload-progress { display: flex; align-items: center; gap: 10px; margin-bottom: 12px; }
        .photo-actions { display: flex; gap: 8px; flex-wrap: wrap; justify-content: flex-end; }

        /* MOBILE */
        .mobile-header { display: none; position: fixed; top: 0; left: 0; right: 0; z-index: 200; background: var(--bg-secondary); border-bottom: 1px solid var(--border); padding: 12px 16px; align-items: center; justify-content: space-between; }
        .hamburger { background: none; border: none; color: var(--text-primary); font-size: 22px; cursor: pointer; }
        .mobile-title { font-size: 16px; font-weight: 700; color: var(--accent); }
        .mobile-nav-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 300; }
        .mobile-nav { position: fixed; top: 0; left: 0; bottom: 0; width: 260px; background: var(--bg-secondary); z-index: 310; padding: 20px; display: flex; flex-direction: column; gap: 4px; overflow-y: auto; }
        .mobile-user { padding: 12px 0 16px; border-bottom: 1px solid var(--border); margin-bottom: 8px; }
        .mobile-user strong { display: block; font-size: 15px; }
        .mobile-user span { font-size: 12px; color: var(--text-secondary); }
        .mobile-nav-item { display: flex; align-items: center; gap: 10px; padding: 12px; background: none; border: none; color: var(--text-secondary); font-size: 14px; border-radius: var(--radius); cursor: pointer; width: 100%; text-align: left; }
        .mobile-nav-item.active { background: rgba(59,130,246,0.15); color: var(--accent); }
        .btn-logout-mobile { margin-top: auto; padding: 12px; background: none; border: 1px solid var(--border); color: var(--text-secondary); border-radius: var(--radius); cursor: pointer; font-size: 14px; width: 100%; }

        @media (max-width: 768px) {
          .sidebar { display: none; }
          .main-content { margin-left: 0; padding-top: 56px; }
          .mobile-header { display: flex; }
          .stats-cards { grid-template-columns: 1fr 1fr; }
          .stats-bottom { grid-template-columns: 1fr; }
          .form-row { grid-template-columns: 1fr; }
          .page { padding: 16px; }
          .login-card { padding: 28px 20px; }
        }

        @media (max-width: 480px) {
          .stats-cards { grid-template-columns: 1fr; }
          .stock-table-header { flex-direction: column; align-items: stretch; }
          .historique-filters { flex-direction: column; }
        }
      `}</style>
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AppContent />
    </ToastProvider>
  );
}
