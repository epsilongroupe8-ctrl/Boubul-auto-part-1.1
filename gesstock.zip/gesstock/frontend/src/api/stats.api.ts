import api from './auth.api';
import type { StatsResponse, AuditLog, Employe, CreateEmployeRequest, UpdateEmployeRequest } from '../types';

// ─── Statistiques ─────────────────────────────────────────────────────────────

export async function getStats(): Promise<StatsResponse> {
  const { data } = await api.get<StatsResponse>('/stats');
  return data;
}

// ─── Audit log ────────────────────────────────────────────────────────────────

export async function getAuditLogs(): Promise<AuditLog[]> {
  const { data } = await api.get<AuditLog[]>('/stats/audit');
  return data;
}

// ─── Employés (CRUD complet) ─────────────────────────────────────────────────

export async function getEmployes(): Promise<Employe[]> {
  const { data } = await api.get<Employe[]>('/employes');
  return data;
}

export async function createEmploye(payload: CreateEmployeRequest): Promise<Employe> {
  const { data } = await api.post<Employe>('/employes', payload);
  return data;
}

export async function updateEmploye(id: string, payload: UpdateEmployeRequest): Promise<Employe> {
  const { data } = await api.put<Employe>(`/employes/${id}`, payload);
  return data;
}

// ─── Paramètres ───────────────────────────────────────────────────────────────

export async function changeCode(ancien_code: string, nouveau_code: string): Promise<void> {
  await api.post('/parametres/code', { ancien_code, nouveau_code });
}

export async function resetMagasin(reset_token: string, code: string): Promise<void> {
  await api.post('/parametres/reset', { reset_token, code });
}
