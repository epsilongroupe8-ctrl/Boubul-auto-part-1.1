import api from './auth.api';
import type {
  Piece,
  PiecesListResponse,
  PiecesQueryParams,
  CreatePieceRequest,
  UpdatePieceRequest,
  ImportCsvResult,
} from '../types';

// ─── Pièces ──────────────────────────────────────────────────────────────────

export async function getPieces(params: PiecesQueryParams = {}): Promise<PiecesListResponse> {
  const { data } = await api.get<PiecesListResponse>('/stock/pieces', { params });
  return data;
}

export async function getPieceById(id: string): Promise<Piece> {
  const { data } = await api.get<Piece>(`/stock/pieces/${id}`);
  return data;
}

export async function createPiece(payload: CreatePieceRequest): Promise<Piece> {
  const { data } = await api.post<Piece>('/stock/pieces', payload);
  return data;
}

export async function updatePiece(id: string, payload: UpdatePieceRequest): Promise<Piece> {
  const { data } = await api.put<Piece>(`/stock/pieces/${id}`, payload);
  return data;
}

export async function deletePiece(id: string): Promise<void> {
  await api.delete(`/stock/pieces/${id}`);
}

// ─── Import / Export CSV ─────────────────────────────────────────────────────

export async function importCsv(
  file: File,
  onDoublon: 'ignorer' | 'ecraser'
): Promise<ImportCsvResult> {
  const form = new FormData();
  form.append('file', file);
  form.append('on_doublon', onDoublon);
  const { data } = await api.post<ImportCsvResult>('/stock/import', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return data;
}

export async function exportCsv(): Promise<Blob> {
  const { data } = await api.get('/stock/export', { responseType: 'blob' });
  return data as Blob;
}
