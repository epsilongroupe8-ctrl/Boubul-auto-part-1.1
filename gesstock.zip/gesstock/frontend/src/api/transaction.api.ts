import api from './auth.api';
import type {
  Transaction,
  TransactionsListResponse,
  TransactionsQueryParams,
  EntreeStockRequest,
  SortieStockRequest,
  Employe,
} from '../types';

// ─── Transactions ────────────────────────────────────────────────────────────

export async function getTransactions(
  params: TransactionsQueryParams = {}
): Promise<TransactionsListResponse> {
  const { data } = await api.get<TransactionsListResponse>('/transactions', { params });
  return data;
}

export async function getTransactionById(id: string): Promise<Transaction> {
  const { data } = await api.get<Transaction>(`/transactions/${id}`);
  return data;
}

export async function entreeStock(payload: EntreeStockRequest): Promise<Transaction> {
  const { data } = await api.post<Transaction>('/transactions/entree', payload);
  return data;
}

export async function sortieStock(payload: SortieStockRequest): Promise<Transaction> {
  const { data } = await api.post<Transaction>('/transactions/sortie', payload);
  return data;
}

// ─── Quittance PDF ───────────────────────────────────────────────────────────

export async function downloadQuittance(transactionId: string): Promise<Blob> {
  const { data } = await api.get(`/transactions/${transactionId}/quittance`, {
    responseType: 'blob',
  });
  return data as Blob;
}

// ─── Employés pour le formulaire de sortie ───────────────────────────────────

export async function getEmployesActifs(): Promise<Employe[]> {
  const { data } = await api.get<Employe[]>('/employes', { params: { actif: true } });
  return data;
}

// ─── Export CSV transactions ─────────────────────────────────────────────────

export async function exportTransactionsCsv(params: TransactionsQueryParams = {}): Promise<Blob> {
  const { data } = await api.get('/transactions/export', {
    params,
    responseType: 'blob',
  });
  return data as Blob;
}
