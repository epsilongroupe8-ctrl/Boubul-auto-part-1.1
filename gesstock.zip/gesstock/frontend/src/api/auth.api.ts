import axios from 'axios';
import type {
  AuthPayload,
  LoginEmployeRequest,
  LoginEmployeurRequest,
  Employe,
  Magasin,
} from '../types';

const BASE = import.meta.env.VITE_API_URL;

const api = axios.create({
  baseURL: BASE,
  withCredentials: true,
});

// ─── Intercepteur refresh silencieux ─────────────────────────────────────────

let isRefreshing = false;
let refreshQueue: Array<(token: string) => void> = [];

api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config;
    if (
      error.response?.status === 401 &&
      !original._retry &&
      !original.url?.includes('/auth/')
    ) {
      if (isRefreshing) {
        return new Promise((resolve) => {
          refreshQueue.push((token: string) => {
            original.headers['Authorization'] = `Bearer ${token}`;
            resolve(api(original));
          });
        });
      }
      original._retry = true;
      isRefreshing = true;
      try {
        const { data } = await api.post<{ token: string }>('/auth/refresh');
        const newToken = data.token;
        // Mettre à jour le store Zustand via événement custom
        window.dispatchEvent(new CustomEvent('token:refresh', { detail: { token: newToken } }));
        refreshQueue.forEach((cb) => cb(newToken));
        refreshQueue = [];
        original.headers['Authorization'] = `Bearer ${newToken}`;
        return api(original);
      } catch {
        window.dispatchEvent(new CustomEvent('auth:logout'));
        return Promise.reject(error);
      } finally {
        isRefreshing = false;
      }
    }
    return Promise.reject(error);
  }
);

export function setAuthToken(token: string | null) {
  if (token) {
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  } else {
    delete api.defaults.headers.common['Authorization'];
  }
}

// ─── Requêtes auth ───────────────────────────────────────────────────────────

export async function getMagasinByNom(nom: string): Promise<Magasin> {
  const { data } = await api.get<Magasin>('/auth/magasin', {
    params: { nom },
  });
  return data;
}

export async function getEmployesByMagasin(magasin_id: string): Promise<Employe[]> {
  const { data } = await api.get<Employe[]>('/auth/employes', {
    params: { magasin_id },
  });
  return data;
}

export async function loginEmploye(payload: LoginEmployeRequest): Promise<AuthPayload> {
  const { data } = await api.post<AuthPayload>('/auth/login/employe', payload);
  return data;
}

export async function loginEmployeur(payload: LoginEmployeurRequest): Promise<AuthPayload> {
  const { data } = await api.post<AuthPayload>('/auth/login/employeur', payload);
  return data;
}

export async function logout(): Promise<void> {
  await api.post('/auth/logout');
}

export async function refreshToken(): Promise<string> {
  const { data } = await api.post<{ token: string }>('/auth/refresh');
  return data.token;
}

export default api;
