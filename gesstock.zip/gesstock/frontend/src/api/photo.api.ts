import api from './auth.api';

export interface SignedUrlResponse {
  url: string;
}

// ─── URL signée ───────────────────────────────────────────────────────────────

export async function getPhotoUrl(pieceId: string): Promise<string> {
  const { data } = await api.get<SignedUrlResponse>(`/photos/${pieceId}/url`);
  return data.url;
}

// ─── Upload photo ─────────────────────────────────────────────────────────────

export async function uploadPhoto(
  pieceId: string,
  file: File,
  onProgress?: (percent: number) => void
): Promise<void> {
  const form = new FormData();
  form.append('photo', file);
  await api.post(`/photos/${pieceId}`, form, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: (e) => {
      if (onProgress && e.total) {
        onProgress(Math.round((e.loaded / e.total) * 100));
      }
    },
  });
}

// ─── Supprimer photo ──────────────────────────────────────────────────────────

export async function deletePhoto(pieceId: string): Promise<void> {
  await api.delete(`/photos/${pieceId}`);
}
