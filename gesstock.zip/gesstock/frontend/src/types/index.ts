// ─── Auth ───────────────────────────────────────────────────────────────────

export type Role = 'employe' | 'employeur';

export interface AuthPayload {
  token: string;
  role: Role;
  magasin_id: string;
  magasin_nom: string;
  user_id: string;
  user_nom: string;
}

export interface LoginEmployeRequest {
  magasin_nom: string;
  employe_id: string;
}

export interface LoginEmployeurRequest {
  magasin_nom: string;
  code: string;
}

// ─── Magasin ─────────────────────────────────────────────────────────────────

export interface Magasin {
  id: string;
  nom: string;
  created_at: string;
  actif: boolean;
}

// ─── Employé ─────────────────────────────────────────────────────────────────

export interface Employe {
  id: string;
  reference: string;
  nom: string;
  magasin_id: string;
  actif: boolean;
  created_at: string;
}

export interface CreateEmployeRequest {
  nom: string;
}

export interface UpdateEmployeRequest {
  nom?: string;
  actif?: boolean;
}

// ─── Pièce ───────────────────────────────────────────────────────────────────

export interface Piece {
  id: string;
  reference: string;
  designation: string;
  prix: number;
  quantite: number;
  seuil_alerte: number;
  magasin_id: string;
  photo_path: string | null;
  photo_url?: string | null;
  created_at: string;
  updated_at: string;
}

export interface CreatePieceRequest {
  reference: string;
  designation: string;
  prix: number;
  quantite: number;
  seuil_alerte: number;
}

export interface UpdatePieceRequest {
  reference?: string;
  designation?: string;
  prix?: number;
  quantite?: number;
  seuil_alerte?: number;
}

export interface PiecesListResponse {
  data: Piece[];
  total: number;
  page: number;
  limit: number;
}

export interface PiecesQueryParams {
  search?: string;
  page?: number;
  limit?: number;
}

// ─── Transaction ─────────────────────────────────────────────────────────────

export type TransactionType = 'entree' | 'sortie';

export interface Transaction {
  id: string;
  type: TransactionType;
  piece_id: string;
  piece_reference?: string;
  piece_designation?: string;
  magasin_id: string;
  employe_id: string | null;
  employe_nom?: string | null;
  quantite: number;
  prix_unitaire: number;
  quittance: string;
  created_at: string;
}

export interface EntreeStockRequest {
  piece_id: string;
  quantite: number;
  prix_unitaire: number;
}

export interface SortieStockRequest {
  piece_id: string;
  employe_id: string;
  quantite: number;
}

export interface TransactionsListResponse {
  data: Transaction[];
  total: number;
  page: number;
  limit: number;
}

export interface TransactionsQueryParams {
  type?: TransactionType;
  employe_id?: string;
  date_debut?: string;
  date_fin?: string;
  page?: number;
  limit?: number;
}

// ─── Alerte ──────────────────────────────────────────────────────────────────

export interface Alerte {
  id: string;
  piece_id: string;
  piece_reference?: string;
  piece_designation?: string;
  magasin_id: string;
  quantite: number;
  seuil: number;
  vue: boolean;
  created_at: string;
}

// ─── Stats ───────────────────────────────────────────────────────────────────

export interface ChiffreAffaires {
  aujourd_hui: number;
  sept_jours: number;
  mois_en_cours: number;
  depuis_debut: number;
}

export interface TopPiece {
  piece_id: string;
  reference: string;
  designation: string;
  total_vendu: number;
  chiffre_affaires: number;
}

export interface VenteJour {
  date: string;
  total: number;
  nb_transactions: number;
}

export interface StatsResponse {
  chiffre_affaires: ChiffreAffaires;
  top_pieces: TopPiece[];
  ventes_30j: VenteJour[];
  nb_transactions: {
    aujourd_hui: number;
    sept_jours: number;
    mois_en_cours: number;
  };
}

// ─── Audit Log ───────────────────────────────────────────────────────────────

export interface AuditLog {
  id: string;
  action: string;
  magasin_id: string;
  user_id: string;
  role: Role;
  ip_hash: string;
  user_agent: string;
  payload: Record<string, unknown>;
  created_at: string;
}

// ─── CSV ──────────────────────────────────────────────────────────────────────

export interface ImportCsvResult {
  imported: number;
  skipped: number;
  errors: Array<{ line: number; message: string }>;
}

// ─── API Response ────────────────────────────────────────────────────────────

export interface ApiError {
  code: string;
  message: string;
}

export interface ApiResponse<T> {
  data?: T;
  error?: ApiError;
}

// ─── Realtime ────────────────────────────────────────────────────────────────

export type RealtimeStatus = 'connected' | 'disconnected' | 'reconnecting';
