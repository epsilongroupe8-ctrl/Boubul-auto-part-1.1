import { create } from 'zustand';
import type { Piece, Alerte } from '../types';

interface StockState {
  pieces: Piece[];
  total: number;
  page: number;
  search: string;
  loading: boolean;
  alertes: Alerte[];
  alertesNonVues: number;

  setPieces: (pieces: Piece[], total: number) => void;
  setPage: (page: number) => void;
  setSearch: (search: string) => void;
  setLoading: (loading: boolean) => void;

  // Mises à jour temps réel
  upsertPiece: (piece: Piece) => void;
  removePiece: (id: string) => void;

  // Alertes
  addAlerte: (alerte: Alerte) => void;
  setAlertes: (alertes: Alerte[]) => void;
  marquerAlertesVues: () => void;
}

export const useStockStore = create<StockState>((set) => ({
  pieces: [],
  total: 0,
  page: 1,
  search: '',
  loading: false,
  alertes: [],
  alertesNonVues: 0,

  setPieces: (pieces, total) => set({ pieces, total }),
  setPage: (page) => set({ page }),
  setSearch: (search) => set({ search, page: 1 }),
  setLoading: (loading) => set({ loading }),

  upsertPiece: (piece) =>
    set((state) => {
      const idx = state.pieces.findIndex((p) => p.id === piece.id);
      if (idx >= 0) {
        const updated = [...state.pieces];
        updated[idx] = piece;
        return { pieces: updated };
      }
      return { pieces: [piece, ...state.pieces], total: state.total + 1 };
    }),

  removePiece: (id) =>
    set((state) => ({
      pieces: state.pieces.filter((p) => p.id !== id),
      total: Math.max(0, state.total - 1),
    })),

  addAlerte: (alerte) =>
    set((state) => ({
      alertes: [alerte, ...state.alertes],
      alertesNonVues: state.alertesNonVues + 1,
    })),

  setAlertes: (alertes) =>
    set({
      alertes,
      alertesNonVues: alertes.filter((a) => !a.vue).length,
    }),

  marquerAlertesVues: () =>
    set((state) => ({
      alertes: state.alertes.map((a) => ({ ...a, vue: true })),
      alertesNonVues: 0,
    })),
}));
