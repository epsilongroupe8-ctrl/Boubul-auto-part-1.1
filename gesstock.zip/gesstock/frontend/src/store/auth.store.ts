import { create } from 'zustand';
import { setAuthToken } from '../api/auth.api';
import type { Role } from '../types';

interface AuthState {
  token: string | null;
  role: Role | null;
  magasin_id: string | null;
  magasin_nom: string | null;
  user_id: string | null;
  user_nom: string | null;
  isAuthenticated: boolean;

  setAuth: (payload: {
    token: string;
    role: Role;
    magasin_id: string;
    magasin_nom: string;
    user_id: string;
    user_nom: string;
  }) => void;
  updateToken: (token: string) => void;
  clearAuth: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  token: null,
  role: null,
  magasin_id: null,
  magasin_nom: null,
  user_id: null,
  user_nom: null,
  isAuthenticated: false,

  setAuth: (payload) => {
    setAuthToken(payload.token);
    set({
      token: payload.token,
      role: payload.role,
      magasin_id: payload.magasin_id,
      magasin_nom: payload.magasin_nom,
      user_id: payload.user_id,
      user_nom: payload.user_nom,
      isAuthenticated: true,
    });
  },

  updateToken: (token) => {
    setAuthToken(token);
    set({ token });
  },

  clearAuth: () => {
    setAuthToken(null);
    set({
      token: null,
      role: null,
      magasin_id: null,
      magasin_nom: null,
      user_id: null,
      user_nom: null,
      isAuthenticated: false,
    });
  },
}));

// ─── Écouter les événements du refresh silencieux ────────────────────────────

if (typeof window !== 'undefined') {
  window.addEventListener('token:refresh', (e) => {
    const detail = (e as CustomEvent<{ token: string }>).detail;
    useAuthStore.getState().updateToken(detail.token);
  });

  window.addEventListener('auth:logout', () => {
    useAuthStore.getState().clearAuth();
  });
}
