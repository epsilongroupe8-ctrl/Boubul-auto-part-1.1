import { useState } from 'react';
import { loginEmployeur, loginEmploye, getMagasinEmployes } from '../api/auth.api';
import { useAuthStore } from '../store/auth.store';
import { PinInput } from '../components/ui/PinInput';
import { Loader } from '../components/ui/Loader';
import { useToast } from '../components/ui/Toast';
import { Employe } from '../types';

type Step = 'magasin' | 'profil' | 'employe_list' | 'employe_pin';

export function Login() {
  const { setAuth } = useAuthStore();
  const { showToast } = useToast();

  const [step, setStep] = useState<Step>('magasin');
  const [nomMagasin, setNomMagasin] = useState('');
  const [profil, setProfil] = useState<'employe' | 'employeur' | null>(null);
  const [pin, setPin] = useState('');
  const [employes, setEmployes] = useState<Employe[]>([]);
  const [selectedEmploye, setSelectedEmploye] = useState<Employe | null>(null);
  const [loading, setLoading] = useState(false);

  const handleMagasinSubmit = async () => {
    if (!nomMagasin.trim()) { showToast('Veuillez saisir le nom du magasin', 'error'); return; }
    setLoading(true);
    try {
      const data = await getMagasinEmployes(nomMagasin.trim());
      setEmployes(data.employes);
      setStep('profil');
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Magasin introuvable';
      showToast(message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleProfilSelect = (p: 'employe' | 'employeur') => {
    setProfil(p);
    if (p === 'employe') {
      setStep('employe_list');
    } else {
      setStep('employe_pin');
    }
  };

  const handleEmployeSelect = (emp: Employe) => {
    setSelectedEmploye(emp);
    setStep('employe_pin');
  };

  const handlePinSubmit = async () => {
    if (pin.length !== 6) { showToast('Veuillez saisir un code à 6 chiffres', 'error'); return; }
    setLoading(true);
    try {
      if (profil === 'employeur') {
        const data = await loginEmployeur({ nom_magasin: nomMagasin.trim(), code: pin });
        setAuth(data.token, data.user);
        showToast('Connexion réussie', 'success');
      } else if (profil === 'employe' && selectedEmploye) {
        const data = await loginEmploye({
          nom_magasin: nomMagasin.trim(),
          employe_id: selectedEmploye.id,
          code: pin,
        });
        setAuth(data.token, data.user);
        showToast('Connexion réussie', 'success');
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Code incorrect';
      showToast(message, 'error');
      setPin('');
    } finally {
      setLoading(false);
    }
  };

  const goBack = () => {
    setPin('');
    if (step === 'employe_pin') {
      if (profil === 'employe') setStep('employe_list');
      else setStep('profil');
    } else if (step === 'employe_list') {
      setStep('profil');
    } else if (step === 'profil') {
      setStep('magasin');
    }
  };

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-logo">
          <span className="logo-icon">🔧</span>
          <h1>GesStock</h1>
          <p>Gestion de stock pour pièces détachées</p>
        </div>

        {loading && <Loader text="Connexion en cours…" />}

        {!loading && step === 'magasin' && (
          <div className="login-step">
            <h2>Nom du magasin</h2>
            <div className="form-group">
              <input
                type="text"
                value={nomMagasin}
                onChange={e => setNomMagasin(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleMagasinSubmit()}
                placeholder="Ex: Garage Central"
                autoFocus
                className="login-input"
              />
            </div>
            <button className="btn-primary btn-full" onClick={handleMagasinSubmit}>
              Continuer →
            </button>
          </div>
        )}

        {!loading && step === 'profil' && (
          <div className="login-step">
            <button className="btn-back" onClick={goBack}>← Retour</button>
            <h2>Choisissez votre profil</h2>
            <p className="login-sub">Magasin : <strong>{nomMagasin}</strong></p>
            <div className="profil-cards">
              <button className="profil-card" onClick={() => handleProfilSelect('employe')}>
                <span className="profil-icon">👷</span>
                <span className="profil-label">Employé</span>
                <span className="profil-desc">Accès stock et transactions</span>
              </button>
              <button className="profil-card profil-employeur" onClick={() => handleProfilSelect('employeur')}>
                <span className="profil-icon">👔</span>
                <span className="profil-label">Employeur</span>
                <span className="profil-desc">Accès complet + statistiques</span>
              </button>
            </div>
          </div>
        )}

        {!loading && step === 'employe_list' && (
          <div className="login-step">
            <button className="btn-back" onClick={goBack}>← Retour</button>
            <h2>Qui êtes-vous ?</h2>
            <div className="employe-select-list">
              {employes.length === 0 ? (
                <p className="no-employes">Aucun employé actif dans ce magasin</p>
              ) : (
                employes.map(emp => (
                  <button
                    key={emp.id}
                    className="employe-select-btn"
                    onClick={() => handleEmployeSelect(emp)}
                  >
                    <span className="employe-avatar-sm">{emp.nom.charAt(0).toUpperCase()}</span>
                    {emp.nom}
                  </button>
                ))
              )}
            </div>
          </div>
        )}

        {!loading && step === 'employe_pin' && (
          <div className="login-step">
            <button className="btn-back" onClick={goBack}>← Retour</button>
            <h2>Code à 6 chiffres</h2>
            {profil === 'employe' && selectedEmploye && (
              <p className="login-sub">Bonjour, <strong>{selectedEmploye.nom}</strong></p>
            )}
            <div className="pin-wrapper">
              <PinInput length={6} value={pin} onChange={setPin} autoFocus />
            </div>
            <button
              className="btn-primary btn-full"
              onClick={handlePinSubmit}
              disabled={pin.length !== 6}
            >
              Se connecter
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
