import { EmployeForm } from '../components/employes/EmployeForm';

export function Employes() {
  return (
    <div className="page">
      <div className="page-header">
        <div className="page-title">
          <h1>👥 Employés</h1>
          <p>Gestion du personnel</p>
        </div>
      </div>
      <EmployeForm />
    </div>
  );
}
