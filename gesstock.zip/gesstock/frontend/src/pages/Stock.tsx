import { useEffect } from 'react';
import { useAuthStore } from '../store/auth.store';
import { StockTable } from '../components/stock/StockTable';
import { useStock } from '../hooks/useStock';
import { exportStock } from '../api/stock.api';
import { importCsv } from '../api/stock.api';
import { useToast } from '../components/ui/Toast';
import { useRef } from 'react';

export function Stock() {
  const { user } = useAuthStore();
  const { refetch } = useStock();
  const { showToast } = useToast();
  const csvInputRef = useRef<HTMLInputElement>(null);

  const isEmployeur = user?.role === 'employeur';

  useEffect(() => {
    refetch();
  }, []);

  const handleExport = async () => {
    try {
      await exportStock();
      showToast('Export CSV téléchargé', 'success');
    } catch {
      showToast('Erreur lors de l\'export', 'error');
    }
  };

  const handleImport = async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    try {
      const result = await importCsv(formData);
      if (result.errors && result.errors.length > 0) {
        showToast(`Import refusé. Erreurs sur les lignes : ${result.errors.map((e: { ligne: number }) => e.ligne).join(', ')}`, 'error');
      } else {
        showToast(`Import réussi : ${result.inserted} pièces importées`, 'success');
        refetch();
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Erreur lors de l\'import';
      showToast(message, 'error');
    }
  };

  return (
    <div className="page">
      <div className="page-header">
        <div className="page-title">
          <h1>📦 Stock</h1>
          <p>Gestion des pièces détachées</p>
        </div>
        {isEmployeur && (
          <div className="page-actions">
            <button className="btn-secondary btn-sm" onClick={handleExport}>
              ⬇️ Exporter CSV
            </button>
            <button
              className="btn-secondary btn-sm"
              onClick={() => csvInputRef.current?.click()}
            >
              ⬆️ Importer CSV
            </button>
            <input
              ref={csvInputRef}
              type="file"
              accept=".csv"
              style={{ display: 'none' }}
              onChange={e => { const f = e.target.files?.[0]; if (f) handleImport(f); e.target.value = ''; }}
            />
          </div>
        )}
      </div>
      <StockTable />
    </div>
  );
}
