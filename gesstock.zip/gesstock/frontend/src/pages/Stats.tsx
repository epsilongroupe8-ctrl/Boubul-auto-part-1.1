import { StatsDashboard } from '../components/stats/StatsDashboard';

export function Stats() {
  return (
    <div className="page">
      <div className="page-header">
        <div className="page-title">
          <h1>📊 Statistiques</h1>
          <p>Chiffre d'affaires et performances</p>
        </div>
      </div>
      <StatsDashboard />
    </div>
  );
}
