import { useState } from 'react';
import { TransactionForm } from '../components/transaction/TransactionForm';
import { Historique } from '../components/transaction/Historique';
import { Modal } from '../components/ui/Modal';
import { exportTransactions } from '../api/transaction.api';
import { useToast } from '../components/ui/Toast';

type ActiveTab = 'entree' | 'sortie' | 'historique';

export function Transactions() {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<ActiveTab>('historique');
  const [showEntreeModal, setShowEntreeModal] = useState(false);
  const [showSortieModal, setShowSortieModal] = useState(false);
  const [lastQuittance, setLastQuittance] = useState<string | null>(null);

  const handleExport = async () => {
    try {
      await exportTransactions();
      showToast('Export CSV téléchargé', 'success');
    } catch {
      showToast('Erreur lors de l\'export', 'error');
    }
  };

  return (
    <div className="page">
      <div className="page-header">
        <div className="page-title">
          <h1>📋 Transactions</h1>
          <p>Entrées et sorties de stock</p>
        </div>
        <div className="page-actions">
          <button className="btn-success btn-sm" onClick={() => setShowEntreeModal(true)}>
            📥 Nouvelle entrée
          </button>
          <button className="btn-warning btn-sm" onClick={() => setShowSortieModal(true)}>
            📤 Nouvelle sortie
          </button>
          <button className="btn-secondary btn-sm" onClick={handleExport}>
            ⬇️ Exporter CSV
          </button>
        </div>
      </div>

      <div className="tab-bar">
        <button
          className={`tab-btn ${activeTab === 'historique' ? 'active' : ''}`}
          onClick={() => setActiveTab('historique')}
        >
          Historique
        </button>
      </div>

      <Historique />

      {showEntreeModal && (
        <Modal title="Entrée de stock" onClose={() => setShowEntreeModal(false)}>
          <TransactionForm
            type="entree"
            onSuccess={() => { setShowEntreeModal(false); }}
            onCancel={() => setShowEntreeModal(false)}
          />
        </Modal>
      )}

      {showSortieModal && (
        <Modal title="Sortie de stock" onClose={() => setShowSortieModal(false)}>
          <TransactionForm
            type="sortie"
            onSuccess={(quittance) => {
              setShowSortieModal(false);
              if (quittance) setLastQuittance(quittance);
            }}
            onCancel={() => setShowSortieModal(false)}
          />
        </Modal>
      )}

      {lastQuittance && (
        <div className="quittance-toast">
          <span>🧾 Quittance : <strong>{lastQuittance}</strong></span>
          <button onClick={() => setLastQuittance(null)}>✕</button>
        </div>
      )}
    </div>
  );
}
