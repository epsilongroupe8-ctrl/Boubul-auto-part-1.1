import { Parametres as ParametresComponent } from '../components/parametres/Parametres';

export function Parametres() {
  return (
    <div className="page">
      <div className="page-header">
        <div className="page-title">
          <h1>⚙️ Paramètres</h1>
          <p>Configuration et sécurité</p>
        </div>
      </div>
      <ParametresComponent />
    </div>
  );
}
