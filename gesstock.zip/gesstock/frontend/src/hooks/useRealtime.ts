import { useEffect, useRef, useState, useCallback } from 'react';
import { createClient } from '@supabase/supabase-js';
import { useAuthStore } from '../store/auth.store';
import { useStockStore } from '../store/stock.store';
import { getPieces } from '../api/stock.api';
import type { Piece, Alerte, RealtimeStatus } from '../types';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

export function useRealtime() {
  const { magasin_id, isAuthenticated } = useAuthStore();
  const { upsertPiece, removePiece, addAlerte, setPieces, setPage } = useStockStore();
  const [status, setStatus] = useState<RealtimeStatus>('disconnected');
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  const refetchStock = useCallback(async () => {
    if (!magasin_id) return;
    try {
      const res = await getPieces({ page: 1, limit: 50 });
      setPieces(res.data, res.total);
      setPage(1);
    } catch {
      // silencieux
    }
  }, [magasin_id, setPieces, setPage]);

  const subscribe = useCallback(() => {
    if (!magasin_id) return;

    const channel = supabase
      .channel(`magasin_${magasin_id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'pieces',
          filter: `magasin_id=eq.${magasin_id}`,
        },
        (payload) => {
          if (payload.eventType === 'DELETE') {
            removePiece(payload.old.id as string);
          } else {
            upsertPiece(payload.new as Piece);
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'alertes',
          filter: `magasin_id=eq.${magasin_id}`,
        },
        (payload) => {
          addAlerte(payload.new as Alerte);
        }
      )
      .subscribe((s) => {
        if (s === 'SUBSCRIBED') setStatus('connected');
        else if (s === 'CLOSED' || s === 'CHANNEL_ERROR') setStatus('disconnected');
        else setStatus('reconnecting');
      });

    channelRef.current = channel;
  }, [magasin_id, upsertPiece, removePiece, addAlerte]);

  // Reconnexion automatique au focus ou retour réseau
  useEffect(() => {
    const handleVisibility = async () => {
      if (document.visibilityState === 'visible' && isAuthenticated) {
        await refetchStock();
        if (channelRef.current) {
          await supabase.removeChannel(channelRef.current);
        }
        subscribe();
      }
    };

    const handleOnline = async () => {
      if (isAuthenticated) {
        setStatus('reconnecting');
        await refetchStock();
        if (channelRef.current) {
          await supabase.removeChannel(channelRef.current);
        }
        subscribe();
      }
    };

    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('online', handleOnline);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('online', handleOnline);
    };
  }, [isAuthenticated, refetchStock, subscribe]);

  // Démarrage/arrêt selon authentification
  useEffect(() => {
    if (isAuthenticated && magasin_id) {
      subscribe();
    }
    return () => {
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }
      setStatus('disconnected');
    };
  }, [isAuthenticated, magasin_id, subscribe]);

  return { status };
}
