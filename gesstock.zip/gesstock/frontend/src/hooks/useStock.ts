import { useEffect, useCallback, useRef } from 'react';
import { useStockStore } from '../store/stock.store';
import { getPieces } from '../api/stock.api';

const DEBOUNCE_MS = 300;

export function useStock() {
  const { page, search, setLoading, setPieces, setPage, setSearch } = useStockStore();
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const fetch = useCallback(
    async (p: number, s: string) => {
      setLoading(true);
      try {
        const res = await getPieces({ page: p, limit: 50, search: s || undefined });
        setPieces(res.data, res.total);
      } catch {
        // géré par le middleware d'erreur global
      } finally {
        setLoading(false);
      }
    },
    [setLoading, setPieces]
  );

  // Debounce sur la recherche
  useEffect(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      fetch(page, search);
    }, DEBOUNCE_MS);
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [page, search, fetch]);

  const handleSearch = useCallback(
    (value: string) => {
      setSearch(value);
    },
    [setSearch]
  );

  const handlePageChange = useCallback(
    (newPage: number) => {
      setPage(newPage);
    },
    [setPage]
  );

  const reload = useCallback(() => {
    fetch(page, search);
  }, [fetch, page, search]);

  return {
    handleSearch,
    handlePageChange,
    reload,
  };
}
