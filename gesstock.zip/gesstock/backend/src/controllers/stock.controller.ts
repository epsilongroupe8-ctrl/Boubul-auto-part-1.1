import { Request, Response, NextFunction } from 'express';
import { body, query } from 'express-validator';
import * as stockService from '../services/stock.service';

export const createPieceValidators = [
  body('reference').trim().notEmpty().isLength({ max: 50 }).withMessage('Référence requise (max 50 chars)'),
  body('designation').trim().notEmpty().isLength({ max: 200 }).withMessage('Désignation requise (max 200 chars)'),
  body('prix').isFloat({ min: 0 }).withMessage('Prix invalide (doit être un nombre positif)'),
  body('quantite').isInt({ min: 0 }).withMessage('Quantité invalide (entier positif)'),
  body('seuil_alerte').isInt({ min: 0 }).withMessage('Seuil d\'alerte invalide'),
];

export const updatePieceValidators = [
  body('reference').optional().trim().isLength({ max: 50 }).withMessage('Référence trop longue'),
  body('designation').optional().trim().isLength({ max: 200 }).withMessage('Désignation trop longue'),
  body('prix').optional().isFloat({ min: 0 }).withMessage('Prix invalide'),
  body('quantite').optional().isInt({ min: 0 }).withMessage('Quantité invalide'),
  body('seuil_alerte').optional().isInt({ min: 0 }).withMessage('Seuil d\'alerte invalide'),
];

export async function getPieces(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const search = (req.query.search as string) || '';
    const limit = Math.min(parseInt(req.query.limit as string) || 50, 100);

    const result = await stockService.getPieces(req.user!.magasinId, page, search, limit);
    res.json({ success: true, ...result });
  } catch (error) {
    next(error);
  }
}

export async function getPieceById(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const piece = await stockService.getPieceById(req.params.id, req.user!.magasinId);
    res.json({ success: true, piece });
  } catch (error) {
    next(error);
  }
}

export async function createPiece(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const { reference, designation, prix, quantite, seuil_alerte } = req.body;

    const piece = await stockService.createPiece(
      req.user!.magasinId,
      req.user!.userId,
      req.user!.role,
      require('../services/auth.service').hashIp(ip),
      req.headers['user-agent'] || 'unknown',
      { reference, designation, prix: parseFloat(prix), quantite: parseInt(quantite), seuil_alerte: parseInt(seuil_alerte) }
    );

    res.status(201).json({ success: true, piece });
  } catch (error) {
    next(error);
  }
}

export async function updatePiece(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const updates: Record<string, unknown> = {};

    const allowedFields = ['reference', 'designation', 'prix', 'quantite', 'seuil_alerte'];
    allowedFields.forEach((field) => {
      if (req.body[field] !== undefined) {
        if (field === 'prix') updates[field] = parseFloat(req.body[field]);
        else if (['quantite', 'seuil_alerte'].includes(field)) updates[field] = parseInt(req.body[field]);
        else updates[field] = req.body[field];
      }
    });

    const piece = await stockService.updatePiece(
      req.params.id,
      req.user!.magasinId,
      req.user!.userId,
      req.user!.role,
      require('../services/auth.service').hashIp(ip),
      req.headers['user-agent'] || 'unknown',
      updates as Parameters<typeof stockService.updatePiece>[6]
    );

    res.json({ success: true, piece });
  } catch (error) {
    next(error);
  }
}

export async function deletePiece(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';

    const { photoPath } = await stockService.deletePiece(
      req.params.id,
      req.user!.magasinId,
      req.user!.userId,
      req.user!.role,
      require('../services/auth.service').hashIp(ip),
      req.headers['user-agent'] || 'unknown'
    );

    // Suppression de la photo si elle existe (importé depuis photo.service)
    if (photoPath) {
      try {
        const { deletePhotoFromStorage, invalidateSignedUrlCache } = await import('../services/photo.service');
        await deletePhotoFromStorage(photoPath);
        await invalidateSignedUrlCache(photoPath);
      } catch {
        // Log mais ne pas bloquer (la pièce est déjà supprimée)
        console.error('Impossible de supprimer la photo du storage');
      }
    }

    res.json({ success: true, message: 'Pièce supprimée avec succès' });
  } catch (error) {
    next(error);
  }
}

export async function getAlertes(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const alertes = await stockService.getAlertes(req.user!.magasinId);
    res.json({ success: true, alertes });
  } catch (error) {
    next(error);
  }
}

export async function marquerAlertesVues(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    await stockService.marquerAlertesVues(req.user!.magasinId);
    res.json({ success: true });
  } catch (error) {
    next(error);
  }
}

export async function exportCsv(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const csv = await stockService.exportCsv(req.user!.magasinId);
    const filename = `stock_${new Date().toISOString().split('T')[0]}.csv`;

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(csv);
  } catch (error) {
    next(error);
  }
}

export async function importCsv(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!req.file) {
      res.status(400).json({
        success: false,
        code: 'FICHIER_MANQUANT',
        message: 'Aucun fichier CSV fourni',
      });
      return;
    }

    const mode = (req.body.mode as 'ignorer' | 'ecraser') || 'ignorer';
    if (!['ignorer', 'ecraser'].includes(mode)) {
      res.status(400).json({
        success: false,
        code: 'MODE_INVALIDE',
        message: 'Mode invalide. Utilisez "ignorer" ou "ecraser"',
      });
      return;
    }

    const ip = req.ip || req.socket.remoteAddress || 'unknown';

    const result = await stockService.importCsv(
      req.user!.magasinId,
      req.file.buffer,
      mode,
      req.user!.userId,
      req.user!.role,
      require('../services/auth.service').hashIp(ip),
      req.headers['user-agent'] || 'unknown'
    );

    res.json({ success: true, ...result });
  } catch (error: unknown) {
    const err = error as { validationErrors?: unknown; code?: string; message?: string; statusCode?: number };
    if (err.validationErrors) {
      res.status(400).json({
        success: false,
        code: err.code || 'CSV_VALIDATION_ERREUR',
        message: err.message,
        validationErrors: err.validationErrors,
      });
      return;
    }
    next(error);
  }
}
