import { Request, Response, NextFunction } from 'express';
import * as photoService from '../services/photo.service';
import { hashIp } from '../services/auth.service';

export async function uploadPhoto(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!req.file) {
      res.status(400).json({
        success: false,
        code: 'FICHIER_MANQUANT',
        message: 'Aucun fichier fourni',
      });
      return;
    }

    const ip = req.ip || req.socket.remoteAddress || 'unknown';

    const photoPath = await photoService.uploadPhoto(
      req.params.pieceId,
      req.user!.magasinId,
      req.file.buffer,
      req.file.originalname,
      req.user!.userId,
      req.user!.role,
      hashIp(ip),
      req.headers['user-agent'] || 'unknown'
    );

    res.json({ success: true, photoPath });
  } catch (error) {
    next(error);
  }
}

export async function getSignedUrl(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { photoPath } = req.query;

    if (!photoPath || typeof photoPath !== 'string') {
      res.status(400).json({
        success: false,
        code: 'VALIDATION_ERREUR',
        message: 'Paramètre photoPath requis',
      });
      return;
    }

    const url = await photoService.getSignedUrl(photoPath, req.user!.magasinId);
    res.json({ success: true, url });
  } catch (error) {
    next(error);
  }
}

export async function deletePhoto(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';

    await photoService.deletePhoto(
      req.params.pieceId,
      req.user!.magasinId,
      req.user!.userId,
      req.user!.role,
      hashIp(ip),
      req.headers['user-agent'] || 'unknown'
    );

    res.json({ success: true, message: 'Photo supprimée avec succès' });
  } catch (error) {
    next(error);
  }
}
