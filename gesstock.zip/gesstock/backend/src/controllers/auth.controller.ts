import { Request, Response, NextFunction } from 'express';
import { body } from 'express-validator';
import * as authService from '../services/auth.service';

export const loginEmployeValidators = [
  body('magasinNom').trim().notEmpty().withMessage('Nom du magasin requis'),
  body('employeId').isUUID().withMessage('ID employé invalide'),
];

export const loginEmployeurValidators = [
  body('magasinNom').trim().notEmpty().withMessage('Nom du magasin requis'),
  body('code')
    .isLength({ min: 6, max: 6 })
    .isNumeric()
    .withMessage('Le code doit être exactement 6 chiffres'),
];

export const changerCodeValidators = [
  body('ancienCode')
    .isLength({ min: 6, max: 6 })
    .isNumeric()
    .withMessage('Ancien code invalide'),
  body('nouveauCode')
    .isLength({ min: 6, max: 6 })
    .isNumeric()
    .withMessage('Nouveau code invalide'),
];

export async function loginEmploye(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { magasinNom, employeId } = req.body;
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const ipHash = authService.hashIp(ip);
    const userAgent = req.headers['user-agent'] || 'unknown';

    const result = await authService.loginEmploye(magasinNom, employeId, ipHash, userAgent);

    res.cookie('refreshToken', result.refreshToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      maxAge: 7 * 24 * 60 * 60 * 1000,
      path: '/api/auth',
    });

    res.json({ success: true, accessToken: result.accessToken, user: result.user });
  } catch (error) {
    next(error);
  }
}

export async function loginEmployeur(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { magasinNom, code } = req.body;
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const ipHash = authService.hashIp(ip);
    const userAgent = req.headers['user-agent'] || 'unknown';

    const result = await authService.loginEmployeur(magasinNom, code, ipHash, userAgent);

    res.cookie('refreshToken', result.refreshToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      maxAge: 7 * 24 * 60 * 60 * 1000,
      path: '/api/auth',
    });

    res.json({ success: true, accessToken: result.accessToken, user: result.user });
  } catch (error) {
    next(error);
  }
}

export async function refresh(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const refreshToken = req.cookies.refreshToken;
    if (!refreshToken) {
      res.status(401).json({
        success: false,
        code: 'REFRESH_TOKEN_MANQUANT',
        message: 'Refresh token manquant',
      });
      return;
    }

    const result = await authService.refreshAccessToken(refreshToken);
    res.json({ success: true, accessToken: result.accessToken });
  } catch (error) {
    next(error);
  }
}

export async function logout(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const refreshToken = req.cookies.refreshToken;
    const ip = req.ip || req.socket.remoteAddress || 'unknown';

    if (refreshToken && req.user) {
      await authService.logout(
        refreshToken,
        req.user.userId,
        req.user.magasinId,
        req.user.role,
        authService.hashIp(ip),
        req.headers['user-agent'] || 'unknown'
      );
    }

    res.clearCookie('refreshToken', { path: '/api/auth' });
    res.json({ success: true, message: 'Déconnexion réussie' });
  } catch (error) {
    next(error);
  }
}

export async function getMagasins(
  _req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const magasins = await authService.getMagasinsList();
    res.json({ success: true, magasins });
  } catch (error) {
    next(error);
  }
}

export async function getEmployes(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { magasinNom } = req.query;
    if (!magasinNom || typeof magasinNom !== 'string') {
      res.status(400).json({
        success: false,
        code: 'VALIDATION_ERREUR',
        message: 'Paramètre magasinNom requis',
      });
      return;
    }
    const employes = await authService.getEmployesList(magasinNom);
    res.json({ success: true, employes });
  } catch (error) {
    next(error);
  }
}

export async function changerCode(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { ancienCode, nouveauCode } = req.body;
    const ip = req.ip || req.socket.remoteAddress || 'unknown';

    await authService.changerCode(
      req.user!.magasinId,
      ancienCode,
      nouveauCode,
      req.user!.userId,
      authService.hashIp(ip),
      req.headers['user-agent'] || 'unknown'
    );

    res.json({ success: true, message: 'Code modifié avec succès' });
  } catch (error) {
    next(error);
  }
}

export async function resetUrgence(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { resetToken, codeActuel, nouveauCode } = req.body;
    const ip = req.ip || req.socket.remoteAddress || 'unknown';

    await authService.resetUrgence(
      req.user!.magasinId,
      resetToken,
      codeActuel,
      nouveauCode,
      req.user!.userId,
      authService.hashIp(ip),
      req.headers['user-agent'] || 'unknown'
    );

    res.json({ success: true, message: 'Reset effectué avec succès. Un email de confirmation a été envoyé.' });
  } catch (error) {
    next(error);
  }
}
