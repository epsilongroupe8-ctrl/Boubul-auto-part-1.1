import { Request, Response, NextFunction } from 'express';
import { body } from 'express-validator';
import * as transactionService from '../services/transaction.service';
import { hashIp } from '../services/auth.service';

export const sortieValidators = [
  body('pieceId').isUUID().withMessage('ID pièce invalide'),
  body('employeId').isUUID().withMessage('ID employé invalide'),
  body('quantite').isInt({ min: 1 }).withMessage('Quantité invalide (minimum 1)'),
];

export const entreeValidators = [
  body('pieceId').isUUID().withMessage('ID pièce invalide'),
  body('quantite').isInt({ min: 1 }).withMessage('Quantité invalide (minimum 1)'),
  body('employeId').optional().isUUID().withMessage('ID employé invalide'),
];

export async function sortieStock(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { pieceId, employeId, quantite } = req.body;
    const ip = req.ip || req.socket.remoteAddress || 'unknown';

    const result = await transactionService.sortieStock(
      req.user!.magasinId,
      pieceId,
      employeId,
      parseInt(quantite),
      req.user!.userId,
      req.user!.role,
      hashIp(ip),
      req.headers['user-agent'] || 'unknown'
    );

    res.json({ success: true, ...result });
  } catch (error) {
    next(error);
  }
}

export async function entreeStock(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { pieceId, employeId, quantite } = req.body;
    const ip = req.ip || req.socket.remoteAddress || 'unknown';

    const result = await transactionService.entreeStock(
      req.user!.magasinId,
      pieceId,
      employeId || null,
      parseInt(quantite),
      req.user!.userId,
      req.user!.role,
      hashIp(ip),
      req.headers['user-agent'] || 'unknown'
    );

    res.json({ success: true, ...result });
  } catch (error) {
    next(error);
  }
}

export async function getHistorique(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = Math.min(parseInt(req.query.limit as string) || 50, 100);
    const filters = {
      type: req.query.type as string | undefined,
      dateDebut: req.query.dateDebut as string | undefined,
      dateFin: req.query.dateFin as string | undefined,
      employeId: req.query.employeId as string | undefined,
    };

    const result = await transactionService.getHistorique(
      req.user!.magasinId,
      page,
      limit,
      filters
    );

    res.json({ success: true, ...result });
  } catch (error) {
    next(error);
  }
}

export async function getQuittance(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const pdfBuffer = await transactionService.generateQuittancePdf(
      req.params.id,
      req.user!.magasinId
    );

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="quittance_${req.params.id}.pdf"`
    );
    res.setHeader('Content-Length', pdfBuffer.length);
    res.end(pdfBuffer);
  } catch (error) {
    next(error);
  }
}

export async function exportHistorique(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const filters = {
      type: req.query.type as string | undefined,
      dateDebut: req.query.dateDebut as string | undefined,
      dateFin: req.query.dateFin as string | undefined,
      employeId: req.query.employeId as string | undefined,
    };

    const csv = await transactionService.exportHistoriqueCsv(req.user!.magasinId, filters);
    const filename = `historique_${new Date().toISOString().split('T')[0]}.csv`;

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(csv);
  } catch (error) {
    next(error);
  }
}
