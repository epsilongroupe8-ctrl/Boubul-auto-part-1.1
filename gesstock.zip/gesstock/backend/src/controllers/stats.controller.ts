import { Request, Response, NextFunction } from 'express';
import { body } from 'express-validator';
import * as statsService from '../services/stats.service';

export async function getStatistiques(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const periode = (req.query.periode as string) || 'mois';
    const validPeriodes = ['aujourd_hui', '7_jours', 'mois', 'total'];

    if (!validPeriodes.includes(periode)) {
      res.status(400).json({
        success: false,
        code: 'PERIODE_INVALIDE',
        message: 'Période invalide. Valeurs acceptées : aujourd_hui, 7_jours, mois, total',
      });
      return;
    }

    const stats = await statsService.getStatistiques(
      req.user!.magasinId,
      periode as 'aujourd_hui' | '7_jours' | 'mois' | 'total'
    );

    res.json({ success: true, stats });
  } catch (error) {
    next(error);
  }
}

export async function getAuditLogs(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const limit = Math.min(parseInt(req.query.limit as string) || 50, 100);
    const logs = await statsService.getAuditLogs(req.user!.magasinId, limit);
    res.json({ success: true, logs });
  } catch (error) {
    next(error);
  }
}

export const createEmployeValidators = [
  body('nom').trim().notEmpty().isLength({ max: 100 }).withMessage('Nom requis (max 100 chars)'),
];

export const updateEmployeValidators = [
  body('nom').optional().trim().isLength({ max: 100 }).withMessage('Nom trop long'),
  body('actif').optional().isBoolean().withMessage('Actif doit être un booléen'),
];

export async function getEmployes(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const employes = await statsService.getEmployes(req.user!.magasinId);
    res.json({ success: true, employes });
  } catch (error) {
    next(error);
  }
}

export async function createEmploye(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const employe = await statsService.createEmploye(req.user!.magasinId, req.body.nom);
    res.status(201).json({ success: true, employe });
  } catch (error) {
    next(error);
  }
}

export async function updateEmploye(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const updates: { nom?: string; actif?: boolean } = {};
    if (req.body.nom !== undefined) updates.nom = req.body.nom;
    if (req.body.actif !== undefined) updates.actif = req.body.actif === true || req.body.actif === 'true';

    const employe = await statsService.updateEmploye(
      req.params.id,
      req.user!.magasinId,
      updates
    );
    res.json({ success: true, employe });
  } catch (error) {
    next(error);
  }
}
