import { Request, Response, NextFunction } from 'express';
import { validationResult, ValidationChain } from 'express-validator';

// Middleware qui exécute les validators et retourne les erreurs
export function validate(validations: ValidationChain[]) {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    // Exécution de toutes les validations
    for (const validation of validations) {
      const result = await validation.run(req);
      if (!result.isEmpty()) break;
    }

    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      res.status(400).json({
        success: false,
        code: 'VALIDATION_ERREUR',
        message: 'Données invalides',
        errors: errors.array().map((err) => ({
          field: err.type === 'field' ? err.path : 'general',
          message: err.msg,
        })),
      });
      return;
    }

    next();
  };
}

// Middleware pour rejeter les champs non autorisés
export function allowOnlyFields(allowedFields: string[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (req.body && typeof req.body === 'object') {
      const extraFields = Object.keys(req.body).filter(
        (key) => !allowedFields.includes(key)
      );

      if (extraFields.length > 0) {
        res.status(400).json({
          success: false,
          code: 'CHAMPS_NON_AUTORISES',
          message: `Champs non autorisés : ${extraFields.join(', ')}`,
        });
        return;
      }
    }
    next();
  };
}
