import { Request, Response, NextFunction } from 'express';
import { env } from '../config/env';

export interface AppError extends Error {
  statusCode?: number;
  code?: string;
  isOperational?: boolean;
}

// Création d'une erreur métier
export function createError(
  message: string,
  code: string,
  statusCode = 400
): AppError {
  const error: AppError = new Error(message);
  error.code = code;
  error.statusCode = statusCode;
  error.isOperational = true;
  return error;
}

// Middleware d'erreur centralisé
export function errorHandler(
  err: AppError,
  req: Request,
  res: Response,
  _next: NextFunction
): void {
  const statusCode = err.statusCode || 500;
  const code = err.code || 'ERREUR_INTERNE';

  // Log complet côté serveur
  console.error({
    timestamp: new Date().toISOString(),
    route: `${req.method} ${req.path}`,
    magasinId: req.user?.magasinId || 'non_authentifie',
    code,
    message: err.message,
    stack: env.NODE_ENV !== 'production' ? err.stack : undefined,
  });

  // Réponse sans stack trace en production
  if (env.NODE_ENV === 'production' && !err.isOperational) {
    res.status(500).json({
      success: false,
      code: 'ERREUR_INTERNE',
      message: 'Une erreur inattendue s\'est produite. Veuillez réessayer.',
    });
    return;
  }

  res.status(statusCode).json({
    success: false,
    code,
    message: err.message,
  });
}

// Handler pour les routes non trouvées
export function notFoundHandler(req: Request, res: Response): void {
  res.status(404).json({
    success: false,
    code: 'ROUTE_INTROUVABLE',
    message: `Route ${req.method} ${req.path} introuvable`,
  });
}
