import rateLimit from 'express-rate-limit';
import { Redis } from '@upstash/redis';
import { env } from '../config/env';
import { Request, Response } from 'express';

const redis = new Redis({
  url: env.UPSTASH_REDIS_REST_URL,
  token: env.UPSTASH_REDIS_REST_TOKEN,
});

// Store Redis pour express-rate-limit (compteurs persistants)
class UpstashStore {
  prefix: string;

  constructor(prefix: string) {
    this.prefix = prefix;
  }

  async increment(key: string): Promise<{ totalHits: number; resetTime: Date | undefined }> {
    const redisKey = `${this.prefix}:${key}`;
    const hits = await redis.incr(redisKey);

    if (hits === 1) {
      // Première incrémentation, définir l'expiration
      await redis.expire(redisKey, 900); // 15 minutes par défaut
    }

    const ttl = await redis.ttl(redisKey);
    const resetTime = ttl > 0 ? new Date(Date.now() + ttl * 1000) : undefined;

    return { totalHits: hits, resetTime };
  }

  async decrement(key: string): Promise<void> {
    const redisKey = `${this.prefix}:${key}`;
    await redis.decr(redisKey);
  }

  async resetKey(key: string): Promise<void> {
    const redisKey = `${this.prefix}:${key}`;
    await redis.del(redisKey);
  }
}

// Rate limiter pour les routes d'authentification (5 tentatives / 15min)
export const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    return `auth:${ip}`;
  },
  handler: (_req: Request, res: Response) => {
    res.status(429).json({
      success: false,
      code: 'TROP_DE_TENTATIVES',
      message: 'Trop de tentatives de connexion. Réessayez dans 15 minutes.',
    });
  },
  skip: () => env.NODE_ENV === 'test',
});

// Rate limiter pour les routes protégées (100 req / minute)
export const apiRateLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => {
    const userId = req.user?.userId || req.ip || 'anonymous';
    return `api:${userId}`;
  },
  handler: (_req: Request, res: Response) => {
    res.status(429).json({
      success: false,
      code: 'LIMITE_DEPASSEE',
      message: 'Trop de requêtes. Réessayez dans une minute.',
    });
  },
  skip: () => env.NODE_ENV === 'test',
});

// Rate limiter pour les uploads photos (10 uploads / heure)
export const uploadRateLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => {
    const userId = req.user?.userId || req.ip || 'anonymous';
    return `upload:${userId}`;
  },
  handler: (_req: Request, res: Response) => {
    res.status(429).json({
      success: false,
      code: 'LIMITE_UPLOAD',
      message: 'Trop d\'uploads. Limite de 10 photos par heure.',
    });
  },
  skip: () => env.NODE_ENV === 'test',
});

// Vérification du verrouillage de compte employeur (Redis)
export async function checkLockout(magasinId: string): Promise<boolean> {
  const key = `lockout:${magasinId}`;
  const locked = await redis.get(key);
  return locked !== null;
}

export async function incrementFailedAttempts(magasinId: string): Promise<number> {
  const key = `failed_attempts:${magasinId}`;
  const attempts = await redis.incr(key);

  if (attempts === 1) {
    await redis.expire(key, 15 * 60); // 15 minutes
  }

  if (attempts >= 5) {
    const lockKey = `lockout:${magasinId}`;
    await redis.set(lockKey, '1', { ex: 15 * 60 }); // Verrouillage 15 minutes
    await redis.del(key);
  }

  return attempts;
}

export async function resetFailedAttempts(magasinId: string): Promise<void> {
  await redis.del(`failed_attempts:${magasinId}`);
  await redis.del(`lockout:${magasinId}`);
}

// Gestion des refresh tokens dans Redis
export async function storeRefreshToken(
  token: string,
  userId: string,
  magasinId: string
): Promise<void> {
  const key = `refresh:${token}`;
  await redis.set(
    key,
    JSON.stringify({ userId, magasinId }),
    { ex: 7 * 24 * 60 * 60 } // 7 jours
  );
}

export async function getRefreshToken(
  token: string
): Promise<{ userId: string; magasinId: string } | null> {
  const key = `refresh:${token}`;
  const data = await redis.get<string>(key);
  if (!data) return null;
  return JSON.parse(data as string);
}

export async function revokeRefreshToken(token: string): Promise<void> {
  await redis.del(`refresh:${token}`);
}

// Cache des URLs signées pour les photos
export async function getSignedUrlCache(photoPath: string): Promise<string | null> {
  const key = `signed_url:${photoPath}`;
  return redis.get<string>(key);
}

export async function setSignedUrlCache(photoPath: string, url: string): Promise<void> {
  const key = `signed_url:${photoPath}`;
  await redis.set(key, url, { ex: 50 * 60 }); // 50 minutes
}

export async function invalidateSignedUrlCache(photoPath: string): Promise<void> {
  const key = `signed_url:${photoPath}`;
  await redis.del(key);
}

export { redis };
