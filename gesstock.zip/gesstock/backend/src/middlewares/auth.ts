import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env';

export interface JwtPayload {
  userId: string;
  magasinId: string;
  role: 'employe' | 'employeur';
  nom: string;
  magasinNom: string;
  iat?: number;
  exp?: number;
}

declare global {
  namespace Express {
    interface Request {
      user?: JwtPayload;
    }
  }
}

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({
      success: false,
      code: 'TOKEN_MANQUANT',
      message: 'Token d\'authentification manquant',
    });
    return;
  }

  const token = authHeader.split(' ')[1];

  try {
    const payload = jwt.verify(token, env.JWT_SECRET) as JwtPayload;
    req.user = payload;
    next();
  } catch (error) {
    if (error instanceof jwt.TokenExpiredError) {
      res.status(401).json({
        success: false,
        code: 'TOKEN_EXPIRE',
        message: 'Session expirée, veuillez vous reconnecter',
      });
      return;
    }

    res.status(401).json({
      success: false,
      code: 'TOKEN_INVALIDE',
      message: 'Token d\'authentification invalide',
    });
  }
}

export function requireEmployeur(req: Request, res: Response, next: NextFunction): void {
  requireAuth(req, res, () => {
    if (req.user?.role !== 'employeur') {
      res.status(403).json({
        success: false,
        code: 'ACCES_REFUSE',
        message: 'Cette action nécessite les droits employeur',
      });
      return;
    }
    next();
  });
}

export function requireSameMagasin(req: Request, res: Response, next: NextFunction): void {
  // Vérification supplémentaire : le magasin_id dans la route correspond au JWT
  const magasinIdParam = req.params.magasinId || req.body.magasin_id;
  if (magasinIdParam && req.user && magasinIdParam !== req.user.magasinId) {
    res.status(403).json({
      success: false,
      code: 'ACCES_REFUSE',
      message: 'Accès interdit à ce magasin',
    });
    return;
  }
  next();
}
