-- ============================================================
-- FONCTIONS RPC POSTGRESQL
-- À exécuter après schema.sql
-- ============================================================

-- ============================================================
-- RPC : sortie_stock_atomique
-- Décrémente le stock et insère la transaction atomiquement
-- Empêche toute vente simultanée au-delà du stock disponible
-- ============================================================
CREATE OR REPLACE FUNCTION sortie_stock_atomique(
  p_piece_id UUID,
  p_magasin_id UUID,
  p_employe_id UUID,
  p_quantite INTEGER,
  p_numero_quittance VARCHAR(50)
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_piece pieces%ROWTYPE;
  v_transaction_id UUID;
BEGIN
  -- Verrouillage exclusif de la ligne pièce pour éviter les races conditions
  SELECT * INTO v_piece
  FROM pieces
  WHERE id = p_piece_id AND magasin_id = p_magasin_id
  FOR UPDATE;

  -- Vérification existence
  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'success', false,
      'code', 'PIECE_INTROUVABLE',
      'message', 'La pièce demandée est introuvable'
    );
  END IF;

  -- Vérification stock suffisant
  IF v_piece.quantite < p_quantite THEN
    RETURN jsonb_build_object(
      'success', false,
      'code', 'STOCK_INSUFFISANT',
      'message', 'Stock insuffisant : ' || v_piece.quantite || ' disponible(s), ' || p_quantite || ' demandé(s)'
    );
  END IF;

  -- Décrémentation du stock
  UPDATE pieces
  SET quantite = quantite - p_quantite
  WHERE id = p_piece_id AND magasin_id = p_magasin_id;

  -- Insertion de la transaction
  INSERT INTO transactions (
    type,
    piece_id,
    magasin_id,
    employe_id,
    quantite,
    prix_unitaire,
    numero_quittance
  )
  VALUES (
    'sortie',
    p_piece_id,
    p_magasin_id,
    p_employe_id,
    p_quantite,
    v_piece.prix,
    p_numero_quittance
  )
  RETURNING id INTO v_transaction_id;

  RETURN jsonb_build_object(
    'success', true,
    'transaction_id', v_transaction_id,
    'numero_quittance', p_numero_quittance,
    'prix_unitaire', v_piece.prix,
    'quantite_restante', v_piece.quantite - p_quantite
  );
END;
$$;

-- ============================================================
-- RPC : entree_stock
-- Incrémente le stock et insère la transaction
-- ============================================================
CREATE OR REPLACE FUNCTION entree_stock(
  p_piece_id UUID,
  p_magasin_id UUID,
  p_employe_id UUID,
  p_quantite INTEGER,
  p_numero_quittance VARCHAR(50)
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_piece pieces%ROWTYPE;
  v_transaction_id UUID;
BEGIN
  SELECT * INTO v_piece
  FROM pieces
  WHERE id = p_piece_id AND magasin_id = p_magasin_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'success', false,
      'code', 'PIECE_INTROUVABLE',
      'message', 'La pièce demandée est introuvable'
    );
  END IF;

  UPDATE pieces
  SET quantite = quantite + p_quantite
  WHERE id = p_piece_id AND magasin_id = p_magasin_id;

  INSERT INTO transactions (
    type,
    piece_id,
    magasin_id,
    employe_id,
    quantite,
    prix_unitaire,
    numero_quittance
  )
  VALUES (
    'entree',
    p_piece_id,
    p_magasin_id,
    p_employe_id,
    p_quantite,
    v_piece.prix,
    p_numero_quittance
  )
  RETURNING id INTO v_transaction_id;

  RETURN jsonb_build_object(
    'success', true,
    'transaction_id', v_transaction_id,
    'numero_quittance', p_numero_quittance,
    'prix_unitaire', v_piece.prix,
    'quantite_nouvelle', v_piece.quantite + p_quantite
  );
END;
$$;

-- ============================================================
-- RPC : import_pieces_csv
-- Import transactionnel : tout ou rien
-- ============================================================
CREATE OR REPLACE FUNCTION import_pieces_csv(
  p_magasin_id UUID,
  p_pieces JSONB,
  p_mode VARCHAR(10)  -- 'ignorer' ou 'ecraser'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_piece JSONB;
  v_count_inserted INTEGER := 0;
  v_count_updated INTEGER := 0;
  v_count_ignored INTEGER := 0;
BEGIN
  FOR v_piece IN SELECT * FROM jsonb_array_elements(p_pieces)
  LOOP
    IF p_mode = 'ecraser' THEN
      INSERT INTO pieces (reference, designation, prix, quantite, seuil_alerte, magasin_id)
      VALUES (
        v_piece->>'reference',
        v_piece->>'designation',
        (v_piece->>'prix')::NUMERIC(12,2),
        (v_piece->>'quantite')::INTEGER,
        (v_piece->>'seuil_alerte')::INTEGER,
        p_magasin_id
      )
      ON CONFLICT (reference, magasin_id)
      DO UPDATE SET
        designation = EXCLUDED.designation,
        prix = EXCLUDED.prix,
        quantite = EXCLUDED.quantite,
        seuil_alerte = EXCLUDED.seuil_alerte,
        updated_at = NOW();

      IF xmax::text::int > 0 THEN
        v_count_updated := v_count_updated + 1;
      ELSE
        v_count_inserted := v_count_inserted + 1;
      END IF;
    ELSE
      -- mode 'ignorer'
      INSERT INTO pieces (reference, designation, prix, quantite, seuil_alerte, magasin_id)
      VALUES (
        v_piece->>'reference',
        v_piece->>'designation',
        (v_piece->>'prix')::NUMERIC(12,2),
        (v_piece->>'quantite')::INTEGER,
        (v_piece->>'seuil_alerte')::INTEGER,
        p_magasin_id
      )
      ON CONFLICT (reference, magasin_id) DO NOTHING;

      IF FOUND THEN
        v_count_inserted := v_count_inserted + 1;
      ELSE
        v_count_ignored := v_count_ignored + 1;
      END IF;
    END IF;
  END LOOP;

  RETURN jsonb_build_object(
    'success', true,
    'inseres', v_count_inserted,
    'mis_a_jour', v_count_updated,
    'ignores', v_count_ignored
  );
END;
$$;

-- ============================================================
-- RPC : get_statistiques
-- Agrégats pour le dashboard employeur
-- ============================================================
CREATE OR REPLACE FUNCTION get_statistiques(
  p_magasin_id UUID,
  p_periode VARCHAR(20)  -- 'aujourd_hui', '7_jours', 'mois', 'total'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_date_debut TIMESTAMPTZ;
  v_ca NUMERIC(12,2);
  v_nb_transactions INTEGER;
  v_top5 JSONB;
  v_ventes_30j JSONB;
BEGIN
  SET LOCAL statement_timeout = '500ms';

  CASE p_periode
    WHEN 'aujourd_hui' THEN
      v_date_debut := CURRENT_DATE;
    WHEN '7_jours' THEN
      v_date_debut := NOW() - INTERVAL '7 days';
    WHEN 'mois' THEN
      v_date_debut := DATE_TRUNC('month', NOW());
    ELSE
      v_date_debut := '2000-01-01'::TIMESTAMPTZ;
  END CASE;

  -- Chiffre d'affaires
  SELECT
    COALESCE(SUM(quantite * prix_unitaire), 0),
    COUNT(*)
  INTO v_ca, v_nb_transactions
  FROM transactions
  WHERE magasin_id = p_magasin_id
    AND type = 'sortie'
    AND created_at >= v_date_debut;

  -- Top 5 pièces du mois
  SELECT jsonb_agg(row_to_json(t)) INTO v_top5
  FROM (
    SELECT
      p.reference,
      p.designation,
      SUM(tr.quantite) AS quantite_vendue,
      SUM(tr.quantite * tr.prix_unitaire) AS ca
    FROM transactions tr
    JOIN pieces p ON p.id = tr.piece_id
    WHERE tr.magasin_id = p_magasin_id
      AND tr.type = 'sortie'
      AND tr.created_at >= DATE_TRUNC('month', NOW())
    GROUP BY p.id, p.reference, p.designation
    ORDER BY quantite_vendue DESC
    LIMIT 5
  ) t;

  -- Ventes sur 30 jours (pour graphique)
  SELECT jsonb_agg(row_to_json(t)) INTO v_ventes_30j
  FROM (
    SELECT
      DATE(created_at) AS jour,
      SUM(quantite * prix_unitaire) AS ca_jour,
      COUNT(*) AS nb_transactions
    FROM transactions
    WHERE magasin_id = p_magasin_id
      AND type = 'sortie'
      AND created_at >= NOW() - INTERVAL '30 days'
    GROUP BY DATE(created_at)
    ORDER BY jour ASC
  ) t;

  RETURN jsonb_build_object(
    'ca', v_ca,
    'nb_transactions', v_nb_transactions,
    'top5', COALESCE(v_top5, '[]'::jsonb),
    'ventes_30j', COALESCE(v_ventes_30j, '[]'::jsonb)
  );
END;
$$;

-- ============================================================
-- RPC : marquer_alertes_vues
-- Marque toutes les alertes non vues d'un magasin comme vues
-- ============================================================
CREATE OR REPLACE FUNCTION marquer_alertes_vues(p_magasin_id UUID)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE alertes
  SET vue = true
  WHERE magasin_id = p_magasin_id AND vue = false;
END;
$$;

-- ============================================================
-- Permissions sur les fonctions RPC
-- ============================================================
REVOKE ALL ON FUNCTION sortie_stock_atomique FROM PUBLIC;
REVOKE ALL ON FUNCTION entree_stock FROM PUBLIC;
REVOKE ALL ON FUNCTION import_pieces_csv FROM PUBLIC;
REVOKE ALL ON FUNCTION get_statistiques FROM PUBLIC;
REVOKE ALL ON FUNCTION marquer_alertes_vues FROM PUBLIC;

GRANT EXECUTE ON FUNCTION sortie_stock_atomique TO service_role;
GRANT EXECUTE ON FUNCTION entree_stock TO service_role;
GRANT EXECUTE ON FUNCTION import_pieces_csv TO service_role;
GRANT EXECUTE ON FUNCTION get_statistiques TO service_role;
GRANT EXECUTE ON FUNCTION marquer_alertes_vues TO service_role;
