-- ============================================================
-- SCHEMA COMPLET - Gestion de stock pièces détachées
-- À exécuter dans Supabase SQL Editor
-- ============================================================

-- Extension UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- TABLE MAGASINS
-- ============================================================
CREATE TABLE IF NOT EXISTS magasins (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nom VARCHAR(100) NOT NULL UNIQUE,
  code_hash VARCHAR(255) NOT NULL,
  actif BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABLE EMPLOYES
-- ============================================================
CREATE TABLE IF NOT EXISTS employes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reference VARCHAR(20) NOT NULL UNIQUE,
  nom VARCHAR(100) NOT NULL,
  magasin_id UUID NOT NULL REFERENCES magasins(id) ON DELETE RESTRICT,
  actif BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Génération automatique de la référence employé
CREATE OR REPLACE FUNCTION generate_employe_reference()
RETURNS TRIGGER AS $$
DECLARE
  v_prefix VARCHAR(3);
  v_seq INT;
  v_reference VARCHAR(20);
BEGIN
  v_prefix := UPPER(SUBSTRING(NEW.nom FROM 1 FOR 3));
  SELECT COUNT(*) + 1 INTO v_seq FROM employes WHERE magasin_id = NEW.magasin_id;
  v_reference := v_prefix || '-' || LPAD(v_seq::TEXT, 4, '0');
  NEW.reference := v_reference;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_generate_employe_reference
  BEFORE INSERT ON employes
  FOR EACH ROW
  WHEN (NEW.reference IS NULL OR NEW.reference = '')
  EXECUTE FUNCTION generate_employe_reference();

-- ============================================================
-- TABLE PIECES
-- ============================================================
CREATE TABLE IF NOT EXISTS pieces (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reference VARCHAR(50) NOT NULL,
  designation VARCHAR(200) NOT NULL,
  prix NUMERIC(12,2) NOT NULL CHECK (prix >= 0),
  quantite INTEGER NOT NULL DEFAULT 0 CHECK (quantite >= 0),
  seuil_alerte INTEGER NOT NULL DEFAULT 0 CHECK (seuil_alerte >= 0),
  magasin_id UUID NOT NULL REFERENCES magasins(id) ON DELETE RESTRICT,
  photo_path VARCHAR(500),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(reference, magasin_id)
);

-- Mise à jour automatique de updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at := NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_pieces_updated_at
  BEFORE UPDATE ON pieces
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- ============================================================
-- TABLE TRANSACTIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  type VARCHAR(10) NOT NULL CHECK (type IN ('entree', 'sortie')),
  piece_id UUID NOT NULL REFERENCES pieces(id) ON DELETE RESTRICT,
  magasin_id UUID NOT NULL REFERENCES magasins(id) ON DELETE RESTRICT,
  employe_id UUID REFERENCES employes(id) ON DELETE RESTRICT,
  quantite INTEGER NOT NULL CHECK (quantite > 0),
  prix_unitaire NUMERIC(12,2) NOT NULL CHECK (prix_unitaire >= 0),
  numero_quittance VARCHAR(50) NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABLE AUDIT_LOGS (immuable)
-- ============================================================
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  action VARCHAR(100) NOT NULL,
  magasin_id UUID REFERENCES magasins(id) ON DELETE SET NULL,
  user_id UUID,
  role VARCHAR(20),
  ip_hash VARCHAR(64),
  user_agent TEXT,
  payload JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABLE ALERTES
-- ============================================================
CREATE TABLE IF NOT EXISTS alertes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  piece_id UUID NOT NULL REFERENCES pieces(id) ON DELETE CASCADE,
  magasin_id UUID NOT NULL REFERENCES magasins(id) ON DELETE CASCADE,
  quantite_actuelle INTEGER NOT NULL,
  seuil INTEGER NOT NULL,
  vue BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TRIGGER ALERTE STOCK BAS
-- ============================================================
CREATE OR REPLACE FUNCTION verifier_seuil_alerte()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.quantite <= NEW.seuil_alerte THEN
    INSERT INTO alertes (piece_id, magasin_id, quantite_actuelle, seuil)
    VALUES (NEW.id, NEW.magasin_id, NEW.quantite, NEW.seuil_alerte);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_verifier_seuil_alerte
  AFTER UPDATE OF quantite ON pieces
  FOR EACH ROW
  EXECUTE FUNCTION verifier_seuil_alerte();

-- ============================================================
-- INDEX
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_pieces_magasin_id ON pieces(magasin_id);
CREATE INDEX IF NOT EXISTS idx_pieces_magasin_reference ON pieces(magasin_id, reference);
CREATE INDEX IF NOT EXISTS idx_pieces_designation ON pieces USING gin(to_tsvector('french', designation));

CREATE INDEX IF NOT EXISTS idx_transactions_magasin_date ON transactions(magasin_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_transactions_magasin_piece ON transactions(magasin_id, piece_id);
CREATE INDEX IF NOT EXISTS idx_transactions_employe ON transactions(employe_id);

CREATE INDEX IF NOT EXISTS idx_audit_logs_magasin_date ON audit_logs(magasin_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_alertes_magasin_date ON alertes(magasin_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_alertes_piece ON alertes(piece_id);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================

ALTER TABLE magasins ENABLE ROW LEVEL SECURITY;
ALTER TABLE employes ENABLE ROW LEVEL SECURITY;
ALTER TABLE pieces ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE alertes ENABLE ROW LEVEL SECURITY;

-- Politiques pour le service role (backend)
-- Le service role bypasse les RLS par défaut dans Supabase

-- Politiques RLS pour les utilisateurs authentifiés via JWT Supabase
-- (utilisées comme 2ème barrière)

-- magasins : lecture publique pour la liste des magasins (login)
CREATE POLICY "magasins_select_public" ON magasins
  FOR SELECT USING (true);

CREATE POLICY "magasins_insert_service" ON magasins
  FOR INSERT WITH CHECK (auth.role() = 'service_role');

CREATE POLICY "magasins_update_service" ON magasins
  FOR UPDATE USING (auth.role() = 'service_role');

-- employes : lecture filtrée par magasin
CREATE POLICY "employes_select_own_magasin" ON employes
  FOR SELECT USING (
    auth.role() = 'service_role' OR
    magasin_id::text = (current_setting('app.current_magasin_id', true))
  );

CREATE POLICY "employes_insert_service" ON employes
  FOR INSERT WITH CHECK (auth.role() = 'service_role');

CREATE POLICY "employes_update_service" ON employes
  FOR UPDATE USING (auth.role() = 'service_role');

-- pieces : filtrée par magasin
CREATE POLICY "pieces_select_own_magasin" ON pieces
  FOR SELECT USING (
    auth.role() = 'service_role' OR
    magasin_id::text = (current_setting('app.current_magasin_id', true))
  );

CREATE POLICY "pieces_insert_service" ON pieces
  FOR INSERT WITH CHECK (auth.role() = 'service_role');

CREATE POLICY "pieces_update_service" ON pieces
  FOR UPDATE USING (auth.role() = 'service_role');

CREATE POLICY "pieces_delete_service" ON pieces
  FOR DELETE USING (auth.role() = 'service_role');

-- transactions : filtrée par magasin
CREATE POLICY "transactions_select_own_magasin" ON transactions
  FOR SELECT USING (
    auth.role() = 'service_role' OR
    magasin_id::text = (current_setting('app.current_magasin_id', true))
  );

CREATE POLICY "transactions_insert_service" ON transactions
  FOR INSERT WITH CHECK (auth.role() = 'service_role');

-- audit_logs : INSERT pour tous, SELECT pour service_role seulement
CREATE POLICY "audit_logs_insert_authenticated" ON audit_logs
  FOR INSERT WITH CHECK (auth.role() IN ('service_role', 'authenticated'));

CREATE POLICY "audit_logs_select_service" ON audit_logs
  FOR SELECT USING (auth.role() = 'service_role');

-- alertes : filtrées par magasin
CREATE POLICY "alertes_select_own_magasin" ON alertes
  FOR SELECT USING (
    auth.role() = 'service_role' OR
    magasin_id::text = (current_setting('app.current_magasin_id', true))
  );

CREATE POLICY "alertes_insert_service" ON alertes
  FOR INSERT WITH CHECK (auth.role() = 'service_role');

CREATE POLICY "alertes_update_service" ON alertes
  FOR UPDATE USING (auth.role() = 'service_role');

-- ============================================================
-- STORAGE BUCKET (à exécuter séparément dans Storage)
-- ============================================================
-- 1. Créer le bucket "pieces-photos" en mode PRIVÉ
-- 2. Activer les politiques suivantes :

-- INSERT : service_role uniquement
-- SELECT : service_role uniquement (URLs signées générées côté backend)
-- DELETE : service_role uniquement
