import { z } from 'zod';

const envSchema = z.object({
  // Serveur
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.string().regex(/^\d+$/, 'PORT doit être un nombre').default('3001'),

  // Supabase
  SUPABASE_URL: z.string().url('SUPABASE_URL doit être une URL valide'),
  SUPABASE_SERVICE_ROLE_KEY: z
    .string()
    .min(20, 'SUPABASE_SERVICE_ROLE_KEY trop courte'),

  // JWT
  JWT_SECRET: z
    .string()
    .min(32, 'JWT_SECRET doit faire au moins 32 caractères'),
  JWT_EXPIRES_IN: z.string().default('8h'),

  // Refresh Token
  REFRESH_TOKEN_SECRET: z
    .string()
    .min(32, 'REFRESH_TOKEN_SECRET doit faire au moins 32 caractères'),

  // Upstash Redis
  UPSTASH_REDIS_REST_URL: z
    .string()
    .url('UPSTASH_REDIS_REST_URL doit être une URL valide'),
  UPSTASH_REDIS_REST_TOKEN: z
    .string()
    .min(10, 'UPSTASH_REDIS_REST_TOKEN trop court'),

  // Resend
  RESEND_API_KEY: z.string().min(10, 'RESEND_API_KEY trop courte'),
  RESEND_FROM_EMAIL: z.string().email('RESEND_FROM_EMAIL doit être un email valide'),

  // CORS
  FRONTEND_URL: z.string().url('FRONTEND_URL doit être une URL valide'),

  // Reset d'urgence
  RESET_TOKEN: z
    .string()
    .min(32, 'RESET_TOKEN doit faire au moins 32 caractères'),
});

type Env = z.infer<typeof envSchema>;

function validateEnv(): Env {
  const result = envSchema.safeParse(process.env);

  if (!result.success) {
    console.error('❌ Variables d\'environnement invalides :');
    result.error.issues.forEach((issue) => {
      console.error(`  - ${issue.path.join('.')}: ${issue.message}`);
    });
    process.exit(1);
  }

  return result.data;
}

export const env = validateEnv();
export type { Env };
