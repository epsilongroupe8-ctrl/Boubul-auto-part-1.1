import './config/env'; // Validation des variables d'environnement au démarrage
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import { env } from './config/env';
import { errorHandler, notFoundHandler } from './middlewares/error';
import authRoutes from './routes/auth.routes';
import stockRoutes from './routes/stock.routes';
import transactionRoutes from './routes/transaction.routes';
import photoRoutes from './routes/photo.routes';
import statsRoutes from './routes/stats.routes';

const app = express();

// ============================================================
// SÉCURITÉ — Headers HTTP
// ============================================================
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:', 'blob:'],
        connectSrc: ["'self'"],
        fontSrc: ["'self'"],
        objectSrc: ["'none'"],
        mediaSrc: ["'self'"],
        frameSrc: ["'none'"],
      },
    },
    hsts: {
      maxAge: 31536000,
      includeSubDomains: true,
      preload: true,
    },
    frameguard: { action: 'deny' },
    referrerPolicy: { policy: 'no-referrer' },
    xssFilter: true,
    noSniff: true,
  })
);

// ============================================================
// CORS — Uniquement l'origine Vercel autorisée
// ============================================================
app.use(
  cors({
    origin: env.FRONTEND_URL,
    credentials: true, // Nécessaire pour les cookies HttpOnly cross-origin
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    exposedHeaders: ['Content-Disposition'],
  })
);

// ============================================================
// PARSING
// ============================================================
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use(cookieParser());

// Confiance au proxy (Render utilise un proxy)
app.set('trust proxy', 1);

// ============================================================
// HEALTHCHECK — Pour UptimeRobot
// ============================================================
app.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

// ============================================================
// ROUTES
// ============================================================
app.use('/api/auth', authRoutes);
app.use('/api/stock', stockRoutes);
app.use('/api/transactions', transactionRoutes);
app.use('/api/photos', photoRoutes);
app.use('/api', statsRoutes);

// ============================================================
// GESTION DES ERREURS
// ============================================================
app.use(notFoundHandler);
app.use(errorHandler);

// ============================================================
// DÉMARRAGE
// ============================================================
const PORT = parseInt(env.PORT, 10);

app.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ Serveur démarré sur le port ${PORT}`);
  console.log(`🌍 Environnement : ${env.NODE_ENV}`);
  console.log(`🔗 Frontend autorisé : ${env.FRONTEND_URL}`);
});

export default app;
