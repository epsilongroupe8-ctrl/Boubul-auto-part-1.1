import { createClient } from '@supabase/supabase-js';
import sharp from 'sharp';
import { env } from '../config/env';
import { createError } from '../middlewares/error';
import { getSignedUrlCache, setSignedUrlCache, invalidateSignedUrlCache } from '../middlewares/rateLimit';
import { logAudit } from './auth.service';

const supabase = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY);
const BUCKET = 'pieces-photos';

// Magic bytes pour la validation du type MIME réel
const MAGIC_BYTES: Record<string, { bytes: number[]; mime: string }[]> = {
  jpeg: [{ bytes: [0xFF, 0xD8, 0xFF], mime: 'image/jpeg' }],
  png: [{ bytes: [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A], mime: 'image/png' }],
  gif: [{ bytes: [0x47, 0x49, 0x46, 0x38], mime: 'image/gif' }],
  webp: [{ bytes: [0x52, 0x49, 0x46, 0x46], mime: 'image/webp' }],
};

function detectMimeType(buffer: Buffer): string | null {
  for (const formats of Object.values(MAGIC_BYTES)) {
    for (const format of formats) {
      const match = format.bytes.every((byte, i) => buffer[i] === byte);
      if (match) return format.mime;
    }
  }
  return null;
}

const ALLOWED_MIMES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB avant traitement

export async function uploadPhoto(
  pieceId: string,
  magasinId: string,
  fileBuffer: Buffer,
  originalFilename: string,
  userId: string,
  role: string,
  ipHash: string,
  userAgent: string
): Promise<string> {
  // Vérification taille
  if (fileBuffer.length > MAX_FILE_SIZE) {
    throw createError('Fichier trop volumineux (max 10MB)', 'FICHIER_TROP_GRAND', 400);
  }

  // Validation du type MIME réel par magic bytes
  const detectedMime = detectMimeType(fileBuffer);
  if (!detectedMime || !ALLOWED_MIMES.includes(detectedMime)) {
    throw createError(
      'Type de fichier non autorisé. Seuls JPEG, PNG, GIF et WEBP sont acceptés.',
      'TYPE_FICHIER_INVALIDE',
      400
    );
  }

  // Vérification existence pièce
  const { data: piece, error: pieceError } = await supabase
    .from('pieces')
    .select('id, photo_path')
    .eq('id', pieceId)
    .eq('magasin_id', magasinId)
    .single();

  if (pieceError || !piece) {
    throw createError('Pièce introuvable', 'PIECE_INTROUVABLE', 404);
  }

  // Suppression ancienne photo si elle existe
  if (piece.photo_path) {
    await deletePhotoFromStorage(piece.photo_path);
    await invalidateSignedUrlCache(piece.photo_path);
  }

  // Redimensionnement et conversion en WEBP avec sharp
  const processedBuffer = await sharp(fileBuffer)
    .resize(800, 800, { fit: 'inside', withoutEnlargement: true })
    .webp({ quality: 85 })
    .toBuffer();

  // Construction du chemin de stockage
  const timestamp = Date.now();
  const photoPath = `${magasinId}/${pieceId}/${timestamp}.webp`;

  // Upload vers Supabase Storage
  const { error: uploadError } = await supabase.storage
    .from(BUCKET)
    .upload(photoPath, processedBuffer, {
      contentType: 'image/webp',
      upsert: false,
    });

  if (uploadError) {
    throw createError('Erreur lors de l\'upload de la photo', 'UPLOAD_ERREUR', 500);
  }

  // Mise à jour du chemin dans la table pieces
  const { error: updateError } = await supabase
    .from('pieces')
    .update({ photo_path: photoPath })
    .eq('id', pieceId)
    .eq('magasin_id', magasinId);

  if (updateError) {
    // Nettoyage du fichier uploadé si la mise à jour échoue
    await deletePhotoFromStorage(photoPath);
    throw createError('Erreur lors de la mise à jour de la pièce', 'DB_ERROR', 500);
  }

  await logAudit('UPLOAD_PHOTO', magasinId, userId, role, ipHash, userAgent, {
    piece_id: pieceId,
    photo_path: photoPath,
  });

  return photoPath;
}

export async function getSignedUrl(
  photoPath: string,
  magasinId: string
): Promise<string> {
  // Vérification que le chemin appartient bien à ce magasin
  if (!photoPath.startsWith(magasinId + '/')) {
    throw createError('Accès non autorisé à cette photo', 'ACCES_REFUSE', 403);
  }

  // Vérification du cache Redis
  const cached = await getSignedUrlCache(photoPath);
  if (cached) return cached;

  // Génération d'une nouvelle URL signée (1 heure)
  const { data, error } = await supabase.storage
    .from(BUCKET)
    .createSignedUrl(photoPath, 3600);

  if (error || !data) {
    throw createError('Erreur lors de la génération de l\'URL', 'STORAGE_ERREUR', 500);
  }

  // Mise en cache pour 50 minutes
  await setSignedUrlCache(photoPath, data.signedUrl);

  return data.signedUrl;
}

export async function deletePhoto(
  pieceId: string,
  magasinId: string,
  userId: string,
  role: string,
  ipHash: string,
  userAgent: string
): Promise<void> {
  const { data: piece, error: pieceError } = await supabase
    .from('pieces')
    .select('photo_path')
    .eq('id', pieceId)
    .eq('magasin_id', magasinId)
    .single();

  if (pieceError || !piece) {
    throw createError('Pièce introuvable', 'PIECE_INTROUVABLE', 404);
  }

  if (!piece.photo_path) {
    throw createError('Cette pièce n\'a pas de photo', 'PHOTO_INTROUVABLE', 404);
  }

  // Suppression du Storage d'abord (cohérence)
  await deletePhotoFromStorage(piece.photo_path);
  await invalidateSignedUrlCache(piece.photo_path);

  // Mise à jour de la pièce
  await supabase
    .from('pieces')
    .update({ photo_path: null })
    .eq('id', pieceId)
    .eq('magasin_id', magasinId);

  await logAudit('SUPPRESSION_PHOTO', magasinId, userId, role, ipHash, userAgent, {
    piece_id: pieceId,
    photo_path: piece.photo_path,
  });
}

export async function deletePhotoFromStorage(photoPath: string): Promise<void> {
  const { error } = await supabase.storage.from(BUCKET).remove([photoPath]);
  if (error) {
    console.error('Erreur suppression Storage:', photoPath, error.message);
    throw createError('Erreur lors de la suppression de la photo du Storage', 'STORAGE_ERREUR', 500);
  }
}
