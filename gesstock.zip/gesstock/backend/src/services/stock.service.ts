import { createClient } from '@supabase/supabase-js';
import { env } from '../config/env';
import { createError } from '../middlewares/error';
import { logAudit } from './auth.service';
import iconv from 'iconv-lite';

const supabase = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY);

export interface Piece {
  id: string;
  reference: string;
  designation: string;
  prix: number;
  quantite: number;
  seuil_alerte: number;
  magasin_id: string;
  photo_path: string | null;
  created_at: string;
  updated_at: string;
}

export interface PiecesResult {
  pieces: Piece[];
  total: number;
  page: number;
  totalPages: number;
}

export async function getPieces(
  magasinId: string,
  page = 1,
  search = '',
  limit = 50
): Promise<PiecesResult> {
  const offset = (page - 1) * limit;

  let query = supabase
    .from('pieces')
    .select('*', { count: 'exact' })
    .eq('magasin_id', magasinId);

  if (search) {
    query = query.or(
      `reference.ilike.%${search}%,designation.ilike.%${search}%`
    );
  }

  const { data, count, error } = await query
    .order('designation', { ascending: true })
    .range(offset, offset + limit - 1);

  if (error) throw createError('Erreur lors de la récupération du stock', 'DB_ERROR', 500);

  return {
    pieces: data || [],
    total: count || 0,
    page,
    totalPages: Math.ceil((count || 0) / limit),
  };
}

export async function getPieceById(id: string, magasinId: string): Promise<Piece> {
  const { data, error } = await supabase
    .from('pieces')
    .select('*')
    .eq('id', id)
    .eq('magasin_id', magasinId)
    .single();

  if (error || !data) throw createError('Pièce introuvable', 'PIECE_INTROUVABLE', 404);
  return data;
}

export async function createPiece(
  magasinId: string,
  userId: string,
  role: string,
  ipHash: string,
  userAgent: string,
  pieceData: {
    reference: string;
    designation: string;
    prix: number;
    quantite: number;
    seuil_alerte: number;
  }
): Promise<Piece> {
  // Vérification doublons de référence dans ce magasin
  const { data: existing } = await supabase
    .from('pieces')
    .select('id')
    .eq('reference', pieceData.reference)
    .eq('magasin_id', magasinId)
    .single();

  if (existing) {
    throw createError(
      `La référence "${pieceData.reference}" existe déjà dans ce magasin`,
      'REFERENCE_DUPLIQUEE',
      409
    );
  }

  const { data, error } = await supabase
    .from('pieces')
    .insert({ ...pieceData, magasin_id: magasinId })
    .select()
    .single();

  if (error || !data) throw createError('Erreur lors de la création de la pièce', 'DB_ERROR', 500);

  await logAudit('CREATION_PIECE', magasinId, userId, role, ipHash, userAgent, {
    piece_id: data.id,
    reference: data.reference,
  });

  return data;
}

export async function updatePiece(
  id: string,
  magasinId: string,
  userId: string,
  role: string,
  ipHash: string,
  userAgent: string,
  updates: Partial<{
    reference: string;
    designation: string;
    prix: number;
    quantite: number;
    seuil_alerte: number;
  }>
): Promise<Piece> {
  // Vérification existence
  const existing = await getPieceById(id, magasinId);

  // Vérification doublons si changement de référence
  if (updates.reference && updates.reference !== existing.reference) {
    const { data: dup } = await supabase
      .from('pieces')
      .select('id')
      .eq('reference', updates.reference)
      .eq('magasin_id', magasinId)
      .neq('id', id)
      .single();

    if (dup) {
      throw createError(
        `La référence "${updates.reference}" existe déjà`,
        'REFERENCE_DUPLIQUEE',
        409
      );
    }
  }

  const { data, error } = await supabase
    .from('pieces')
    .update(updates)
    .eq('id', id)
    .eq('magasin_id', magasinId)
    .select()
    .single();

  if (error || !data) throw createError('Erreur lors de la modification', 'DB_ERROR', 500);

  await logAudit('MODIFICATION_PIECE', magasinId, userId, role, ipHash, userAgent, {
    piece_id: id,
    modifications: updates,
  });

  return data;
}

export async function deletePiece(
  id: string,
  magasinId: string,
  userId: string,
  role: string,
  ipHash: string,
  userAgent: string
): Promise<{ photoPath: string | null }> {
  const piece = await getPieceById(id, magasinId);

  const { error } = await supabase
    .from('pieces')
    .delete()
    .eq('id', id)
    .eq('magasin_id', magasinId);

  if (error) throw createError('Erreur lors de la suppression', 'DB_ERROR', 500);

  await logAudit('SUPPRESSION_PIECE', magasinId, userId, role, ipHash, userAgent, {
    piece_id: id,
    reference: piece.reference,
  });

  return { photoPath: piece.photo_path };
}

export async function getAlertes(magasinId: string): Promise<object[]> {
  const { data, error } = await supabase
    .from('alertes')
    .select(`
      id,
      quantite_actuelle,
      seuil,
      vue,
      created_at,
      pieces (id, reference, designation)
    `)
    .eq('magasin_id', magasinId)
    .eq('vue', false)
    .order('created_at', { ascending: false })
    .limit(50);

  if (error) throw createError('Erreur alertes', 'DB_ERROR', 500);
  return data || [];
}

export async function marquerAlertesVues(magasinId: string): Promise<void> {
  const { error } = await supabase.rpc('marquer_alertes_vues', {
    p_magasin_id: magasinId,
  });
  if (error) throw createError('Erreur lors de la mise à jour des alertes', 'DB_ERROR', 500);
}

export async function exportCsv(magasinId: string): Promise<string> {
  const { data, error } = await supabase
    .from('pieces')
    .select('reference, designation, prix, quantite, seuil_alerte')
    .eq('magasin_id', magasinId)
    .order('designation');

  if (error) throw createError('Erreur export', 'DB_ERROR', 500);

  const BOM = '\uFEFF';
  const headers = 'reference,designation,prix,quantite,seuil_alerte';
  const rows = (data || []).map((p) =>
    `"${p.reference}","${p.designation}",${p.prix},${p.quantite},${p.seuil_alerte}`
  );

  return BOM + [headers, ...rows].join('\n');
}

export interface CsvImportResult {
  inseres: number;
  mis_a_jour: number;
  ignores: number;
}

export interface CsvValidationError {
  ligne: number;
  message: string;
}

export async function importCsv(
  magasinId: string,
  fileBuffer: Buffer,
  mode: 'ignorer' | 'ecraser',
  userId: string,
  role: string,
  ipHash: string,
  userAgent: string
): Promise<CsvImportResult> {
  // Détection de l'encodage
  let content: string;
  try {
    content = iconv.decode(fileBuffer, 'utf8');
    if (content.includes('ï¿½')) {
      content = iconv.decode(fileBuffer, 'latin1');
    }
  } catch {
    content = iconv.decode(fileBuffer, 'latin1');
  }

  // Suppression du BOM si présent
  content = content.replace(/^\uFEFF/, '');

  const lines = content.split(/\r?\n/).filter((l) => l.trim());
  if (lines.length < 2) {
    throw createError('Le fichier CSV est vide ou ne contient que l\'entête', 'CSV_INVALIDE', 400);
  }

  const errors: CsvValidationError[] = [];
  const pieces: object[] = [];

  // Validation des colonnes attendues
  const headerLine = lines[0].toLowerCase().replace(/"/g, '');
  const expectedHeaders = ['reference', 'designation', 'prix', 'quantite', 'seuil_alerte'];
  const missingHeaders = expectedHeaders.filter((h) => !headerLine.includes(h));

  if (missingHeaders.length > 0) {
    throw createError(
      `Colonnes manquantes : ${missingHeaders.join(', ')}`,
      'CSV_COLONNES_MANQUANTES',
      400
    );
  }

  const headers = lines[0].replace(/"/g, '').split(',').map((h) => h.trim().toLowerCase());

  for (let i = 1; i < lines.length; i++) {
    const lineNum = i + 1;
    const values = lines[i].split(',').map((v) => v.trim().replace(/^"|"$/g, ''));

    if (values.length !== headers.length) {
      errors.push({ ligne: lineNum, message: 'Nombre de colonnes incorrect' });
      continue;
    }

    const row: Record<string, string> = {};
    headers.forEach((h, idx) => { row[h] = values[idx]; });

    // Validation
    if (!row.reference || row.reference.length > 50) {
      errors.push({ ligne: lineNum, message: 'Référence manquante ou trop longue (max 50)' });
      continue;
    }

    if (!row.designation || row.designation.length > 200) {
      errors.push({ ligne: lineNum, message: 'Désignation manquante ou trop longue (max 200)' });
      continue;
    }

    const prix = parseFloat(row.prix);
    if (isNaN(prix) || prix < 0) {
      errors.push({ ligne: lineNum, message: 'Prix invalide (doit être un nombre positif)' });
      continue;
    }

    const quantite = parseInt(row.quantite, 10);
    if (isNaN(quantite) || quantite < 0) {
      errors.push({ ligne: lineNum, message: 'Quantité invalide (doit être un entier positif)' });
      continue;
    }

    const seuilAlerte = parseInt(row.seuil_alerte, 10);
    if (isNaN(seuilAlerte) || seuilAlerte < 0) {
      errors.push({ ligne: lineNum, message: 'Seuil d\'alerte invalide' });
      continue;
    }

    pieces.push({
      reference: row.reference,
      designation: row.designation,
      prix: prix.toFixed(2),
      quantite,
      seuil_alerte: seuilAlerte,
    });
  }

  if (errors.length > 0) {
    const error = createError(
      `Import rejeté : ${errors.length} ligne(s) invalide(s)`,
      'CSV_VALIDATION_ERREUR',
      400
    );
    (error as AppError & { validationErrors: CsvValidationError[] }).validationErrors = errors;
    throw error;
  }

  // Import transactionnel via RPC
  const { data, error: rpcError } = await supabase.rpc('import_pieces_csv', {
    p_magasin_id: magasinId,
    p_pieces: pieces,
    p_mode: mode,
  });

  if (rpcError) throw createError('Erreur lors de l\'import', 'DB_ERROR', 500);

  await logAudit('IMPORT_CSV', magasinId, userId, role, ipHash, userAgent, {
    nb_lignes: pieces.length,
    mode,
  });

  return data as CsvImportResult;
}

interface AppError extends Error {
  validationErrors?: CsvValidationError[];
}
