import { createClient } from '@supabase/supabase-js';
import PDFDocument from 'pdfkit';
import { env } from '../config/env';
import { createError } from '../middlewares/error';
import { logAudit } from './auth.service';

const supabase = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY);

export interface Transaction {
  id: string;
  type: 'entree' | 'sortie';
  piece_id: string;
  magasin_id: string;
  employe_id: string | null;
  quantite: number;
  prix_unitaire: number;
  numero_quittance: string;
  created_at: string;
}

export interface TransactionsResult {
  transactions: object[];
  total: number;
  page: number;
  totalPages: number;
}

async function generateNumeroQuittance(magasinId: string): Promise<string> {
  // Récupération du code magasin (3 premières lettres du nom)
  const { data: magasin } = await supabase
    .from('magasins')
    .select('nom')
    .eq('id', magasinId)
    .single();

  const code = magasin
    ? magasin.nom.substring(0, 3).toUpperCase().replace(/\s/g, '_')
    : 'MAG';

  const today = new Date();
  const dateStr =
    today.getFullYear().toString() +
    (today.getMonth() + 1).toString().padStart(2, '0') +
    today.getDate().toString().padStart(2, '0');

  // Compteur du jour pour ce magasin
  const startOfDay = new Date(today.setHours(0, 0, 0, 0)).toISOString();
  const { count } = await supabase
    .from('transactions')
    .select('*', { count: 'exact', head: true })
    .eq('magasin_id', magasinId)
    .gte('created_at', startOfDay);

  const sequence = ((count || 0) + 1).toString().padStart(4, '0');
  return `${code}-${dateStr}-${sequence}`;
}

export async function sortieStock(
  magasinId: string,
  pieceId: string,
  employeId: string,
  quantite: number,
  userId: string,
  role: string,
  ipHash: string,
  userAgent: string
): Promise<object> {
  const numeroQuittance = await generateNumeroQuittance(magasinId);

  const { data, error } = await supabase.rpc('sortie_stock_atomique', {
    p_piece_id: pieceId,
    p_magasin_id: magasinId,
    p_employe_id: employeId,
    p_quantite: quantite,
    p_numero_quittance: numeroQuittance,
  });

  if (error) throw createError('Erreur lors de la sortie de stock', 'DB_ERROR', 500);

  if (!data.success) {
    throw createError(data.message, data.code, 400);
  }

  await logAudit('SORTIE_STOCK', magasinId, userId, role, ipHash, userAgent, {
    piece_id: pieceId,
    quantite,
    numero_quittance: numeroQuittance,
    employe_id: employeId,
  });

  return data;
}

export async function entreeStock(
  magasinId: string,
  pieceId: string,
  employeId: string | null,
  quantite: number,
  userId: string,
  role: string,
  ipHash: string,
  userAgent: string
): Promise<object> {
  const numeroQuittance = await generateNumeroQuittance(magasinId);

  const { data, error } = await supabase.rpc('entree_stock', {
    p_piece_id: pieceId,
    p_magasin_id: magasinId,
    p_employe_id: employeId,
    p_quantite: quantite,
    p_numero_quittance: numeroQuittance,
  });

  if (error) throw createError('Erreur lors de l\'entrée de stock', 'DB_ERROR', 500);
  if (!data.success) throw createError(data.message, data.code, 400);

  await logAudit('ENTREE_STOCK', magasinId, userId, role, ipHash, userAgent, {
    piece_id: pieceId,
    quantite,
    numero_quittance: numeroQuittance,
  });

  return data;
}

export async function getHistorique(
  magasinId: string,
  page = 1,
  limit = 50,
  filters: {
    type?: string;
    dateDebut?: string;
    dateFin?: string;
    employeId?: string;
  } = {}
): Promise<TransactionsResult> {
  const offset = (page - 1) * limit;

  let query = supabase
    .from('transactions')
    .select(
      `
      id,
      type,
      quantite,
      prix_unitaire,
      numero_quittance,
      created_at,
      pieces (id, reference, designation),
      employes (id, nom)
    `,
      { count: 'exact' }
    )
    .eq('magasin_id', magasinId);

  if (filters.type) {
    query = query.eq('type', filters.type);
  }

  if (filters.dateDebut) {
    query = query.gte('created_at', filters.dateDebut);
  }

  if (filters.dateFin) {
    query = query.lte('created_at', filters.dateFin + 'T23:59:59');
  }

  if (filters.employeId) {
    query = query.eq('employe_id', filters.employeId);
  }

  const { data, count, error } = await query
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1);

  if (error) throw createError('Erreur historique', 'DB_ERROR', 500);

  return {
    transactions: data || [],
    total: count || 0,
    page,
    totalPages: Math.ceil((count || 0) / limit),
  };
}

export async function getTransactionById(
  id: string,
  magasinId: string
): Promise<object> {
  const { data, error } = await supabase
    .from('transactions')
    .select(
      `
      id,
      type,
      quantite,
      prix_unitaire,
      numero_quittance,
      created_at,
      pieces (id, reference, designation),
      employes (id, nom),
      magasins (id, nom)
    `
    )
    .eq('id', id)
    .eq('magasin_id', magasinId)
    .single();

  if (error || !data) throw createError('Transaction introuvable', 'TRANSACTION_INTROUVABLE', 404);
  return data;
}

export async function generateQuittancePdf(
  transactionId: string,
  magasinId: string
): Promise<Buffer> {
  const transaction = await getTransactionById(transactionId, magasinId) as Record<string, unknown>;

  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A6', margin: 30 });
    const buffers: Buffer[] = [];

    doc.on('data', (chunk: Buffer) => buffers.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(buffers)));
    doc.on('error', reject);

    const piece = transaction.pieces as Record<string, unknown>;
    const employe = transaction.employes as Record<string, unknown> | null;
    const magasin = transaction.magasins as Record<string, unknown>;
    const date = new Date(transaction.created_at as string);
    const montantTotal = (transaction.quantite as number) * (transaction.prix_unitaire as number);

    // En-tête
    doc.fontSize(16).font('Helvetica-Bold').text('QUITTANCE', { align: 'center' });
    doc.moveDown(0.3);
    doc.fontSize(10).font('Helvetica').text(magasin.nom as string, { align: 'center' });
    doc.moveDown(0.5);

    // Ligne séparatrice
    doc.moveTo(30, doc.y).lineTo(doc.page.width - 30, doc.y).stroke();
    doc.moveDown(0.5);

    // Numéro de quittance
    doc.fontSize(9).font('Helvetica-Bold').text('N° Quittance :');
    doc.font('Helvetica').text(transaction.numero_quittance as string);
    doc.moveDown(0.3);

    // Date
    doc.font('Helvetica-Bold').text('Date :');
    doc.font('Helvetica').text(
      date.toLocaleString('fr-FR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    );
    doc.moveDown(0.3);

    // Type
    doc.font('Helvetica-Bold').text('Type :');
    doc.font('Helvetica').text(
      transaction.type === 'sortie' ? 'Sortie de stock (Vente)' : 'Entrée de stock'
    );
    doc.moveDown(0.3);

    // Pièce
    doc.font('Helvetica-Bold').text('Pièce :');
    doc.font('Helvetica').text(`${piece.reference} - ${piece.designation}`);
    doc.moveDown(0.3);

    // Quantité
    doc.font('Helvetica-Bold').text('Quantité :');
    doc.font('Helvetica').text(String(transaction.quantite));
    doc.moveDown(0.3);

    // Prix unitaire
    doc.font('Helvetica-Bold').text('Prix unitaire :');
    doc.font('Helvetica').text(`${(transaction.prix_unitaire as number).toFixed(2)} €`);
    doc.moveDown(0.3);

    // Montant total
    doc.font('Helvetica-Bold').text('Montant total :');
    doc.fontSize(12).font('Helvetica-Bold').text(`${montantTotal.toFixed(2)} €`);
    doc.moveDown(0.3);

    if (employe) {
      doc.fontSize(9).font('Helvetica-Bold').text('Employé :');
      doc.font('Helvetica').text(employe.nom as string);
    }

    doc.moveDown(0.5);
    doc.moveTo(30, doc.y).lineTo(doc.page.width - 30, doc.y).stroke();
    doc.moveDown(0.3);
    doc.fontSize(7).font('Helvetica').text('Document généré automatiquement', { align: 'center' });

    doc.end();
  });
}

export async function exportHistoriqueCsv(
  magasinId: string,
  filters: {
    type?: string;
    dateDebut?: string;
    dateFin?: string;
    employeId?: string;
  } = {}
): Promise<string> {
  let query = supabase
    .from('transactions')
    .select(
      `
      type,
      quantite,
      prix_unitaire,
      numero_quittance,
      created_at,
      pieces (reference, designation),
      employes (nom)
    `
    )
    .eq('magasin_id', magasinId);

  if (filters.type) query = query.eq('type', filters.type);
  if (filters.dateDebut) query = query.gte('created_at', filters.dateDebut);
  if (filters.dateFin) query = query.lte('created_at', filters.dateFin + 'T23:59:59');
  if (filters.employeId) query = query.eq('employe_id', filters.employeId);

  const { data, error } = await query.order('created_at', { ascending: false });
  if (error) throw createError('Erreur export historique', 'DB_ERROR', 500);

  const BOM = '\uFEFF';
  const headers = 'date,type,reference,designation,quantite,prix_unitaire,montant,quittance,employe';

  const rows = (data || []).map((t) => {
    const piece = t.pieces as Record<string, string>;
    const employe = t.employes as Record<string, string> | null;
    const montant = t.quantite * t.prix_unitaire;
    return [
      new Date(t.created_at).toLocaleString('fr-FR'),
      t.type,
      `"${piece?.reference || ''}"`,
      `"${piece?.designation || ''}"`,
      t.quantite,
      t.prix_unitaire,
      montant.toFixed(2),
      `"${t.numero_quittance}"`,
      `"${employe?.nom || ''}"`,
    ].join(',');
  });

  return BOM + [headers, ...rows].join('\n');
}
