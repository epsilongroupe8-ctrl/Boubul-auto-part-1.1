import { createClient } from '@supabase/supabase-js';
import { env } from '../config/env';
import { createError } from '../middlewares/error';

const supabase = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY);

export interface StatsPeriode {
  ca: number;
  nb_transactions: number;
  top5: Top5Item[];
  ventes_30j: Ventes30jItem[];
}

export interface Top5Item {
  reference: string;
  designation: string;
  quantite_vendue: number;
  ca: number;
}

export interface Ventes30jItem {
  jour: string;
  ca_jour: number;
  nb_transactions: number;
}

export async function getStatistiques(
  magasinId: string,
  periode: 'aujourd_hui' | '7_jours' | 'mois' | 'total'
): Promise<StatsPeriode> {
  const { data, error } = await supabase.rpc('get_statistiques', {
    p_magasin_id: magasinId,
    p_periode: periode,
  });

  if (error) {
    if (error.message?.includes('statement timeout')) {
      throw createError(
        'La requête a pris trop de temps. Veuillez réessayer.',
        'TIMEOUT',
        504
      );
    }
    throw createError('Erreur lors de la récupération des statistiques', 'DB_ERROR', 500);
  }

  return data as StatsPeriode;
}

export async function getAuditLogs(
  magasinId: string,
  limit = 50
): Promise<object[]> {
  const { data, error } = await supabase
    .from('audit_logs')
    .select('*')
    .eq('magasin_id', magasinId)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) throw createError('Erreur lors de la récupération des logs', 'DB_ERROR', 500);
  return data || [];
}

export async function getEmployes(magasinId: string): Promise<object[]> {
  const { data, error } = await supabase
    .from('employes')
    .select('id, reference, nom, actif, created_at')
    .eq('magasin_id', magasinId)
    .order('nom');

  if (error) throw createError('Erreur lors de la récupération des employés', 'DB_ERROR', 500);
  return data || [];
}

export async function createEmploye(
  magasinId: string,
  nom: string
): Promise<object> {
  const { data, error } = await supabase
    .from('employes')
    .insert({ nom, magasin_id: magasinId, reference: '' })
    .select()
    .single();

  if (error) {
    throw createError('Erreur lors de la création de l\'employé', 'DB_ERROR', 500);
  }
  return data;
}

export async function updateEmploye(
  id: string,
  magasinId: string,
  updates: { nom?: string; actif?: boolean }
): Promise<object> {
  const { data: existing } = await supabase
    .from('employes')
    .select('id')
    .eq('id', id)
    .eq('magasin_id', magasinId)
    .single();

  if (!existing) throw createError('Employé introuvable', 'EMPLOYE_INTROUVABLE', 404);

  const { data, error } = await supabase
    .from('employes')
    .update(updates)
    .eq('id', id)
    .eq('magasin_id', magasinId)
    .select()
    .single();

  if (error) throw createError('Erreur lors de la modification', 'DB_ERROR', 500);
  return data;
}
