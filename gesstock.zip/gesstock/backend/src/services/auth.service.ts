import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { createClient } from '@supabase/supabase-js';
import { env } from '../config/env';
import { JwtPayload } from '../middlewares/auth';
import {
  checkLockout,
  incrementFailedAttempts,
  resetFailedAttempts,
  storeRefreshToken,
  revokeRefreshToken,
  getRefreshToken,
} from '../middlewares/rateLimit';
import { createError } from '../middlewares/error';
import { Resend } from 'resend';

const supabase = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY);
const resend = new Resend(env.RESEND_API_KEY);

export async function loginEmploye(
  magasinNom: string,
  employeId: string,
  ipHash: string,
  userAgent: string
): Promise<{ accessToken: string; refreshToken: string; user: object }> {
  // Récupération du magasin
  const { data: magasin, error: magasinError } = await supabase
    .from('magasins')
    .select('id, nom, actif')
    .eq('nom', magasinNom)
    .single();

  if (magasinError || !magasin) {
    throw createError('Magasin introuvable', 'MAGASIN_INTROUVABLE', 404);
  }

  if (!magasin.actif) {
    throw createError('Magasin désactivé', 'MAGASIN_INACTIF', 403);
  }

  // Récupération de l'employé
  const { data: employe, error: employeError } = await supabase
    .from('employes')
    .select('id, nom, actif, magasin_id')
    .eq('id', employeId)
    .eq('magasin_id', magasin.id)
    .single();

  if (employeError || !employe) {
    throw createError('Employé introuvable', 'EMPLOYE_INTROUVABLE', 404);
  }

  if (!employe.actif) {
    throw createError('Compte employé désactivé', 'EMPLOYE_INACTIF', 403);
  }

  // Génération des tokens
  const payload: JwtPayload = {
    userId: employe.id,
    magasinId: magasin.id,
    role: 'employe',
    nom: employe.nom,
    magasinNom: magasin.nom,
  };

  const accessToken = jwt.sign(payload, env.JWT_SECRET, {
    expiresIn: env.JWT_EXPIRES_IN,
  } as jwt.SignOptions);

  const refreshToken = crypto.randomBytes(32).toString('hex');
  await storeRefreshToken(refreshToken, employe.id, magasin.id);

  // Audit log
  await logAudit('LOGIN_EMPLOYE', magasin.id, employe.id, 'employe', ipHash, userAgent, {
    employe_nom: employe.nom,
  });

  return {
    accessToken,
    refreshToken,
    user: {
      id: employe.id,
      nom: employe.nom,
      role: 'employe',
      magasinId: magasin.id,
      magasinNom: magasin.nom,
    },
  };
}

export async function loginEmployeur(
  magasinNom: string,
  code: string,
  ipHash: string,
  userAgent: string
): Promise<{ accessToken: string; refreshToken: string; user: object }> {
  // Récupération du magasin
  const { data: magasin, error } = await supabase
    .from('magasins')
    .select('id, nom, code_hash, actif')
    .eq('nom', magasinNom)
    .single();

  if (error || !magasin) {
    throw createError('Magasin introuvable', 'MAGASIN_INTROUVABLE', 404);
  }

  if (!magasin.actif) {
    throw createError('Magasin désactivé', 'MAGASIN_INACTIF', 403);
  }

  // Vérification du verrouillage
  const locked = await checkLockout(magasin.id);
  if (locked) {
    throw createError(
      'Compte verrouillé suite à trop de tentatives échouées. Réessayez dans 15 minutes.',
      'COMPTE_VERROUILLE',
      423
    );
  }

  // Vérification du code
  const codeValid = await bcrypt.compare(code, magasin.code_hash);
  if (!codeValid) {
    const attempts = await incrementFailedAttempts(magasin.id);
    const remaining = Math.max(0, 5 - attempts);

    await logAudit('LOGIN_ECHEC', magasin.id, null, 'employeur', ipHash, userAgent, {
      tentatives_restantes: remaining,
    });

    throw createError(
      `Code incorrect. ${remaining} tentative(s) restante(s) avant verrouillage.`,
      'CODE_INVALIDE',
      401
    );
  }

  // Réinitialisation des tentatives échouées
  await resetFailedAttempts(magasin.id);

  const payload: JwtPayload = {
    userId: magasin.id,
    magasinId: magasin.id,
    role: 'employeur',
    nom: 'Employeur',
    magasinNom: magasin.nom,
  };

  const accessToken = jwt.sign(payload, env.JWT_SECRET, {
    expiresIn: env.JWT_EXPIRES_IN,
  } as jwt.SignOptions);

  const refreshToken = crypto.randomBytes(32).toString('hex');
  await storeRefreshToken(refreshToken, magasin.id, magasin.id);

  await logAudit('LOGIN_EMPLOYEUR', magasin.id, magasin.id, 'employeur', ipHash, userAgent, {});

  return {
    accessToken,
    refreshToken,
    user: {
      id: magasin.id,
      nom: 'Employeur',
      role: 'employeur',
      magasinId: magasin.id,
      magasinNom: magasin.nom,
    },
  };
}

export async function refreshAccessToken(
  refreshToken: string
): Promise<{ accessToken: string }> {
  const data = await getRefreshToken(refreshToken);

  if (!data) {
    throw createError('Refresh token invalide ou expiré', 'REFRESH_TOKEN_INVALIDE', 401);
  }

  // Récupération des infos utilisateur pour regénérer le JWT
  const { data: magasin } = await supabase
    .from('magasins')
    .select('id, nom')
    .eq('id', data.magasinId)
    .single();

  if (!magasin) {
    throw createError('Magasin introuvable', 'MAGASIN_INTROUVABLE', 404);
  }

  // Détermination du rôle
  let payload: JwtPayload;

  if (data.userId === data.magasinId) {
    // C'est l'employeur
    payload = {
      userId: magasin.id,
      magasinId: magasin.id,
      role: 'employeur',
      nom: 'Employeur',
      magasinNom: magasin.nom,
    };
  } else {
    const { data: employe } = await supabase
      .from('employes')
      .select('id, nom, actif')
      .eq('id', data.userId)
      .single();

    if (!employe || !employe.actif) {
      await revokeRefreshToken(refreshToken);
      throw createError('Employé désactivé', 'EMPLOYE_INACTIF', 403);
    }

    payload = {
      userId: employe.id,
      magasinId: magasin.id,
      role: 'employe',
      nom: employe.nom,
      magasinNom: magasin.nom,
    };
  }

  const accessToken = jwt.sign(payload, env.JWT_SECRET, {
    expiresIn: env.JWT_EXPIRES_IN,
  } as jwt.SignOptions);

  return { accessToken };
}

export async function logout(
  refreshToken: string,
  userId: string,
  magasinId: string,
  role: string,
  ipHash: string,
  userAgent: string
): Promise<void> {
  await revokeRefreshToken(refreshToken);
  await logAudit('LOGOUT', magasinId, userId, role, ipHash, userAgent, {});
}

export async function getMagasinsList(): Promise<{ id: string; nom: string }[]> {
  const { data, error } = await supabase
    .from('magasins')
    .select('id, nom')
    .eq('actif', true)
    .order('nom');

  if (error) throw createError('Erreur lors de la récupération des magasins', 'DB_ERROR', 500);
  return data || [];
}

export async function getEmployesList(
  magasinNom: string
): Promise<{ id: string; nom: string }[]> {
  const { data: magasin } = await supabase
    .from('magasins')
    .select('id')
    .eq('nom', magasinNom)
    .single();

  if (!magasin) throw createError('Magasin introuvable', 'MAGASIN_INTROUVABLE', 404);

  const { data, error } = await supabase
    .from('employes')
    .select('id, nom')
    .eq('magasin_id', magasin.id)
    .eq('actif', true)
    .order('nom');

  if (error) throw createError('Erreur DB', 'DB_ERROR', 500);
  return data || [];
}

export async function changerCode(
  magasinId: string,
  ancienCode: string,
  nouveauCode: string,
  userId: string,
  ipHash: string,
  userAgent: string
): Promise<void> {
  const { data: magasin } = await supabase
    .from('magasins')
    .select('code_hash')
    .eq('id', magasinId)
    .single();

  if (!magasin) throw createError('Magasin introuvable', 'MAGASIN_INTROUVABLE', 404);

  const valid = await bcrypt.compare(ancienCode, magasin.code_hash);
  if (!valid) throw createError('Ancien code incorrect', 'CODE_INVALIDE', 401);

  const nouveauHash = await bcrypt.hash(nouveauCode, 12);

  await supabase
    .from('magasins')
    .update({ code_hash: nouveauHash })
    .eq('id', magasinId);

  await logAudit('CHANGEMENT_CODE', magasinId, userId, 'employeur', ipHash, userAgent, {});
}

export async function resetUrgence(
  magasinId: string,
  resetToken: string,
  codeActuel: string,
  nouveauCode: string,
  userId: string,
  ipHash: string,
  userAgent: string
): Promise<void> {
  if (resetToken !== env.RESET_TOKEN) {
    throw createError('Token de reset invalide', 'RESET_TOKEN_INVALIDE', 401);
  }

  const { data: magasin } = await supabase
    .from('magasins')
    .select('code_hash, nom')
    .eq('id', magasinId)
    .single();

  if (!magasin) throw createError('Magasin introuvable', 'MAGASIN_INTROUVABLE', 404);

  const valid = await bcrypt.compare(codeActuel, magasin.code_hash);
  if (!valid) throw createError('Code actuel incorrect', 'CODE_INVALIDE', 401);

  const nouveauHash = await bcrypt.hash(nouveauCode, 12);
  await supabase.from('magasins').update({ code_hash: nouveauHash }).eq('id', magasinId);

  await logAudit('RESET_URGENCE', magasinId, userId, 'employeur', ipHash, userAgent, {
    magasin_nom: magasin.nom,
  });

  // Notification email
  await resend.emails.send({
    from: env.RESEND_FROM_EMAIL,
    to: env.RESEND_FROM_EMAIL,
    subject: `[ALERTE] Reset d'urgence effectué - ${magasin.nom}`,
    html: `
      <h2>Reset d'urgence effectué</h2>
      <p>Un reset d'urgence du code employeur a été effectué pour le magasin <strong>${magasin.nom}</strong>.</p>
      <p>Date : ${new Date().toLocaleString('fr-FR')}</p>
      <p>IP hashée : ${ipHash}</p>
      <p>Si vous n'êtes pas à l'origine de cette action, contactez immédiatement votre administrateur.</p>
    `,
  });
}

export async function logAudit(
  action: string,
  magasinId: string | null,
  userId: string | null,
  role: string | null,
  ipHash: string,
  userAgent: string,
  payload: object
): Promise<void> {
  try {
    await supabase.from('audit_logs').insert({
      action,
      magasin_id: magasinId,
      user_id: userId,
      role,
      ip_hash: ipHash,
      user_agent: userAgent,
      payload,
    });
  } catch {
    // Ne pas faire échouer la requête principale si l'audit échoue
    console.error('Erreur audit log:', action);
  }
}

export function hashIp(ip: string): string {
  return crypto.createHash('sha256').update(ip + 'salt_audit').digest('hex').substring(0, 16);
}
