import { Router } from 'express';
import multer from 'multer';
import * as stockController from '../controllers/stock.controller';
import { requireAuth, requireEmployeur } from '../middlewares/auth';
import { validate, allowOnlyFields } from '../middlewares/validate';
import { apiRateLimiter } from '../middlewares/rateLimit';

const router = Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB max pour le CSV
});

// Toutes les routes stock nécessitent une authentification
router.use(requireAuth);
router.use(apiRateLimiter);

// Lecture du stock
router.get('/', stockController.getPieces);
router.get('/export', stockController.exportCsv);
router.get('/alertes', stockController.getAlertes);
router.get('/:id', stockController.getPieceById);

// Écriture (employeur uniquement)
router.post(
  '/',
  requireEmployeur,
  allowOnlyFields(['reference', 'designation', 'prix', 'quantite', 'seuil_alerte']),
  validate(stockController.createPieceValidators),
  stockController.createPiece
);

router.put(
  '/:id',
  requireEmployeur,
  allowOnlyFields(['reference', 'designation', 'prix', 'quantite', 'seuil_alerte']),
  validate(stockController.updatePieceValidators),
  stockController.updatePiece
);

router.delete('/:id', requireEmployeur, stockController.deletePiece);

// Alertes
router.patch('/alertes/marquer-vues', stockController.marquerAlertesVues);

// Import CSV (employeur uniquement)
router.post(
  '/import',
  requireEmployeur,
  upload.single('fichier'),
  stockController.importCsv
);

export default router;
