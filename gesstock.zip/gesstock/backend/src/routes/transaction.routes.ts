import { Router } from 'express';
import * as transactionController from '../controllers/transaction.controller';
import { requireAuth } from '../middlewares/auth';
import { validate, allowOnlyFields } from '../middlewares/validate';
import { apiRateLimiter } from '../middlewares/rateLimit';

const router = Router();

router.use(requireAuth);
router.use(apiRateLimiter);

// Historique
router.get('/', transactionController.getHistorique);
router.get('/export', transactionController.exportHistorique);
router.get('/:id/quittance', transactionController.getQuittance);

// Transactions
router.post(
  '/sortie',
  allowOnlyFields(['pieceId', 'employeId', 'quantite']),
  validate(transactionController.sortieValidators),
  transactionController.sortieStock
);

router.post(
  '/entree',
  allowOnlyFields(['pieceId', 'employeId', 'quantite']),
  validate(transactionController.entreeValidators),
  transactionController.entreeStock
);

export default router;
