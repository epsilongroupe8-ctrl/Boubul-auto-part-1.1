import { Router } from 'express';
import * as authController from '../controllers/auth.controller';
import { requireAuth, requireEmployeur } from '../middlewares/auth';
import { validate } from '../middlewares/validate';
import { authRateLimiter } from '../middlewares/rateLimit';

const router = Router();

// Routes publiques
router.get('/magasins', authController.getMagasins);
router.get('/employes', authController.getEmployes);

// Connexion (rate limitées)
router.post(
  '/login/employe',
  authRateLimiter,
  validate(authController.loginEmployeValidators),
  authController.loginEmploye
);

router.post(
  '/login/employeur',
  authRateLimiter,
  validate(authController.loginEmployeurValidators),
  authController.loginEmployeur
);

// Refresh token
router.post('/refresh', authController.refresh);

// Déconnexion (authentifié)
router.post('/logout', requireAuth, authController.logout);

// Changement de code (employeur uniquement)
router.put(
  '/code',
  requireEmployeur,
  validate(authController.changerCodeValidators),
  authController.changerCode
);

// Reset d'urgence (employeur + RESET_TOKEN)
router.post('/reset-urgence', requireEmployeur, authController.resetUrgence);

export default router;
