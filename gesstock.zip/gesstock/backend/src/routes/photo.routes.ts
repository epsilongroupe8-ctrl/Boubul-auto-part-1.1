import { Router } from 'express';
import multer from 'multer';
import * as photoController from '../controllers/photo.controller';
import { requireAuth, requireEmployeur } from '../middlewares/auth';
import { uploadRateLimiter } from '../middlewares/rateLimit';

const router = Router();

// Multer en mémoire — validation du type MIME réel dans le service
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB max
});

router.use(requireAuth);

// Lecture URL signée (tous les utilisateurs authentifiés)
router.get('/signed-url', photoController.getSignedUrl);

// Upload photo (employeur uniquement, rate limité)
router.post(
  '/:pieceId',
  requireEmployeur,
  uploadRateLimiter,
  upload.single('photo'),
  photoController.uploadPhoto
);

// Suppression photo (employeur uniquement)
router.delete('/:pieceId', requireEmployeur, photoController.deletePhoto);

export default router;
