import { Router } from 'express';
import * as statsController from '../controllers/stats.controller';
import { requireAuth, requireEmployeur } from '../middlewares/auth';
import { validate, allowOnlyFields } from '../middlewares/validate';
import { apiRateLimiter } from '../middlewares/rateLimit';

const router = Router();

router.use(requireAuth);
router.use(apiRateLimiter);

// Statistiques (employeur uniquement)
router.get('/stats', requireEmployeur, statsController.getStatistiques);
router.get('/audit-logs', requireEmployeur, statsController.getAuditLogs);

// Gestion des employés (employeur uniquement)
router.get('/employes', requireEmployeur, statsController.getEmployes);

router.post(
  '/employes',
  requireEmployeur,
  allowOnlyFields(['nom']),
  validate(statsController.createEmployeValidators),
  statsController.createEmploye
);

router.put(
  '/employes/:id',
  requireEmployeur,
  allowOnlyFields(['nom', 'actif']),
  validate(statsController.updateEmployeValidators),
  statsController.updateEmploye
);

export default router;
